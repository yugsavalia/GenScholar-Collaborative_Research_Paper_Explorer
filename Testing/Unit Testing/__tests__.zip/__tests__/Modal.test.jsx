import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Modal from '@/components/Modal';
import { vi } from 'vitest';

describe('Modal component', () => {
  const handleClose = vi.fn();

  beforeEach(() => {
    const modalRoot = document.createElement('div');
    modalRoot.setAttribute('id', 'modal-root');
    document.body.appendChild(modalRoot);
  });

  afterEach(() => {
    const modalRoot = document.getElementById('modal-root');
    if (modalRoot) {
      document.body.removeChild(modalRoot);
    }
    handleClose.mockClear();
  });

  test('renders when isOpen is true', () => {
    render(
      <Modal isOpen={true} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

    expect(screen.getByText('Test Modal')).toBeInTheDocument();
    expect(screen.getByText('This is the modal content.')).toBeInTheDocument();
  });

  test('does not render when isOpen is false', () => {
    render(
      <Modal isOpen={false} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

    expect(screen.queryByText('Test Modal')).not.toBeInTheDocument();
  });

  test('calls onClose when the close button is clicked', () => {
    render(
      <Modal isOpen={true} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

    fireEvent.click(screen.getByTestId('button-close-modal'));
    expect(handleClose).toHaveBeenCalledTimes(1);
  });

  test('calls onClose when the overlay is clicked', () => {
    const { container } = render(
      <Modal isOpen={true} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

    // Click the overlay (the fixed inset-0 div that has the bg-black/80)
    const overlay = container.querySelector('.fixed.inset-0');
    fireEvent.click(overlay);
    expect(handleClose).toHaveBeenCalledTimes(1);
  });

  test('does not call onClose when the modal content is clicked', () => {
    render(
      <Modal isOpen={true} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

    fireEvent.click(screen.getByText('This is the modal content.'));
    expect(handleClose).not.toHaveBeenCalled();
  });

  test('calls onClose when the Escape key is pressed', () => {
    render(
      <Modal isOpen={true} onClose={handleClose} title="Test Modal">
        <p>This is the modal content.</p>
      </Modal>
    );

        fireEvent.keyDown(document, { key: 'Escape', code: 'Escape' });
    expect(handleClose).toHaveBeenCalledTimes(1);
  });
});

