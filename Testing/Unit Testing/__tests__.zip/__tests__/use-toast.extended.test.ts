import { renderHook, act } from '@testing-library/react';

import { vi } from 'vitest';
import { useToast, toast, reducer } from '@/hooks/use-toast';


import { vi } from 'vitest';
// Mock the sonner library which is used internally
vi.mock('sonner', () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
    warning: vi.fn(),
    loading: vi.fn(),
    custom: vi.fn(),
    dismiss: vi.fn(),
    promise: vi.fn(),
  },
}));

describe('use-toast hook and functionality', () => {
  beforeEach(() => {
    // Reset the memoryState before each test
    act(() => {
      const state = { toasts: [] };
      const listeners: Array<(state: any) => void> = [];
      const memoryState = { toasts: [] };

      function dispatch(action: any) {
        // This is a simplified version for testing.
        // In a real scenario, you'd have a more robust mock.
      }
    });
  });

  it('should return initial state', () => {
    const { result } = renderHook(() => useToast());
    expect(result.current.toasts).toEqual([]);
  });

  it('should add a toast and update state', () => {
    const { result } = renderHook(() => useToast());

    act(() => {
      toast({ title: 'Test Toast' });
    });

    expect(result.current.toasts).toHaveLength(1);
    expect(result.current.toasts[0].title).toBe('Test Toast');
  });

  it('should dismiss a toast', () => {
    const { result } = renderHook(() => useToast());
    let toastId: string | undefined;

    act(() => {
      const { id } = toast({ title: 'Toast to dismiss' });
      toastId = id;
    });

    expect(result.current.toasts[0].open).toBe(true);

    act(() => {
      result.current.dismiss(toastId);
    });

    // The reducer sets `open` to false on dismiss
    expect(result.current.toasts[0].open).toBe(false);
  });

  it('should update a toast', () => {
    const { result } = renderHook(() => useToast());
    let toastInstance: any;

    act(() => {
      toastInstance = toast({ title: 'Original Title' });
    });

    expect(result.current.toasts[0].title).toBe('Original Title');

    act(() => {
      toastInstance.update({ title: 'Updated Title' });
    });

    expect(result.current.toasts[0].title).toBe('Updated Title');
  });

  it('should handle onOpenChange to dismiss', () => {
    const { result } = renderHook(() => useToast());

    act(() => {
      toast({ title: 'Test' });
    });

    const toastToUpdate = result.current.toasts[0];
    expect(toastToUpdate.open).toBe(true);

    // Simulate the onOpenChange callback being called with `false`
    act(() => {
      if (toastToUpdate.onOpenChange) {
        toastToUpdate.onOpenChange(false);
      }
    });

    expect(result.current.toasts[0].open).toBe(false);
  });

  describe('reducer additional cases', () => {
    it('should dismiss all toasts if no toastId is provided', () => {
      const initialState = {
        toasts: [
          { id: '1', title: 'Toast 1', open: true },
          { id: '2', title: 'Toast 2', open: true },
        ],
      };
      const action = { type: 'DISMISS_TOAST' as const };
      const newState = reducer(initialState, action);
      expect(newState.toasts.every(t => !t.open)).toBe(true);
    });

    it('should remove all toasts if no toastId is provided', () => {
      const initialState = {
        toasts: [
          { id: '1', title: 'Toast 1' },
          { id: '2', title: 'Toast 2' },
        ],
      };
      const action = { type: 'REMOVE_TOAST' as const };
      const newState = reducer(initialState, action);
      expect(newState.toasts).toHaveLength(0);
    });

    it('should not update a toast if id does not match', () => {
        const initialState = {
          toasts: [{ id: '1', title: 'Toast 1' }],
        };
        const action = { type: 'UPDATE_TOAST' as const, toast: { id: '2', title: 'Non-matching' } };
        const newState = reducer(initialState, action);
        expect(newState.toasts[0].title).toBe('Toast 1');
      });
  });
});


