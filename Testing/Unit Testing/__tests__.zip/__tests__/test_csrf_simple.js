/**
 * Simple CSRF Test Script
 * Quick test to verify CSRF endpoint is accessible
 */

const http = require('http');

const BASE_URL = process.env.BASE_URL || 'http://localhost:8000';

console.log('Testing CSRF endpoint...');
console.log(`URL: ${BASE_URL}/api/auth/csrf/`);
console.log('');

const url = new URL(`${BASE_URL}/api/auth/csrf/`);

const options = {
  hostname: url.hostname,
  port: url.port || 80,
  path: url.pathname,
  method: 'GET',
  headers: {
    'Content-Type': 'application/json',
  },
};

const req = http.request(options, (res) => {
  let data = '';

  res.on('data', (chunk) => {
    data += chunk;
  });

  res.on('end', () => {
    console.log(`Status Code: ${res.statusCode}`);
    console.log(`Response: ${data}`);
    
    if (res.statusCode === 200) {
      try {
        const json = JSON.parse(data);
        if (json.success && json.data?.csrf_token) {
          console.log('\n✓ CSRF endpoint is working!');
          console.log(`Token: ${json.data.csrf_token.substring(0, 20)}...`);
        } else {
          console.log('\n✗ Invalid response format');
        }
      } catch (e) {
        console.log('\n✗ Invalid JSON response');
      }
    } else {
      console.log(`\n✗ Request failed with status ${res.statusCode}`);
    }
  });
});

req.on('error', (error) => {
  console.error(`\n✗ Connection error: ${error.message}`);
  console.error('\nMake sure:');
  console.error('1. Django server is running: cd backend && python manage.py runserver');
  console.error('2. Server is accessible at:', BASE_URL);
  process.exit(1);
});

req.setTimeout(5000, () => {
  req.destroy();
  console.error('\n✗ Request timeout');
  console.error('Make sure the Django server is running');
  process.exit(1);
});

req.end();


