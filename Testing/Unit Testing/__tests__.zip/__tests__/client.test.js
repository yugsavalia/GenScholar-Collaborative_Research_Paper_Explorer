import { vi } from 'vitest';
import { apiRequest, apiGet, apiPost, apiPut, apiDelete } from '@/api/client';
import { API_BASE_URL } from '@/api/config';
import { getCsrfToken } from '@/utils/csrf';

vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

describe('api/client', () => {
  const csrfToken = 'test-csrf-token';
  const endpoint = '/test-endpoint';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  // --- apiRequest ---
  describe('apiRequest', () => {
    it('should make a successful GET request', async () => {
      const mockData = { success: true, data: 'get-data' };
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve(mockData),
      });

      const result = await apiGet(endpoint);

      expect(mockFetch).toHaveBeenCalledWith(`${API_BASE_URL}${endpoint}`, expect.any(Object));
      expect(getCsrfToken).not.toHaveBeenCalled();
      expect(result).toEqual(mockData);
    });

    it('should make a successful POST request with JSON body', async () => {
      const postData = { key: 'value' };
      const mockResponse = { success: true, data: 'post-data' };
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve(mockResponse),
      });

      const result = await apiPost(endpoint, postData);

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}${endpoint}`,
        expect.objectContaining({
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
          },
          body: JSON.stringify(postData),
        })
      );
      expect(result).toEqual(mockResponse);
    });

    it('should make a successful POST request with FormData', async () => {
      const formData = new FormData();
      formData.append('file', 'some-file-content');
      const mockResponse = { success: true, data: 'form-data' };
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve(mockResponse),
      });

      const result = await apiPost(endpoint, formData);

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}${endpoint}`,
        expect.objectContaining({
          method: 'POST',
          headers: {
            // Note: Content-Type is NOT set for FormData
            'X-CSRFToken': csrfToken,
          },
          body: formData,
        })
      );
      expect(result).toEqual(mockResponse);
    });

    it('should throw an error if response.ok is false', async () => {
      const errorResponse = { message: 'You shall not pass' };
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve(errorResponse),
      });

      await expect(apiGet(endpoint)).rejects.toThrow('You shall not pass');
    });

    it('should throw an error if responseData.success is false', async () => {
      const errorResponse = { success: false, error: 'A custom error occurred' };
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve(errorResponse),
      });

      await expect(apiGet(endpoint)).rejects.toThrow('A custom error occurred');
    });

    it('should throw a generic error for network failures', async () => {
      const networkError = new Error('Network request failed');
      mockFetch.mockRejectedValue(networkError);

      await expect(apiGet(endpoint)).rejects.toThrow('API request failed: Network request failed');
    });

    it('should correctly call apiRequest for apiPut and apiDelete', async () => {
        const mockResponse = { success: true };
        mockFetch.mockResolvedValue({
          ok: true,
          headers: { get: vi.fn().mockReturnValue('application/json') },
          json: () => Promise.resolve(mockResponse),
        });
  
        // Test apiPut
        await apiPut('/put-test', { data: 'put' });
        expect(mockFetch).toHaveBeenCalledWith(expect.any(String), expect.objectContaining({ method: 'PUT' }));
  
        // Test apiDelete
        await apiDelete('/delete-test');
        expect(mockFetch).toHaveBeenCalledWith(expect.any(String), expect.objectContaining({ method: 'DELETE' }));
  
        // CSRF token should be fetched for both
        expect(getCsrfToken).toHaveBeenCalledTimes(2);
      });
  });
});


