import { describe, it, expect, vi, beforeEach } from 'vitest';
import { formatDateTime, formatDateTimeShort } from '../utils/dateFormat';

describe('utils/dateFormat - Comprehensive Coverage', () => {
  beforeEach(() => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  describe('formatDateTime', () => {
    it('should format Date object correctly', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTime(date);
      expect(result).toMatch(/15\/01\/2024, \d{2}:\d{2}:\d{2}/);
    });

    it('should format ISO string correctly', () => {
      const result = formatDateTime('2024-03-20T14:25:30Z');
      expect(result).toMatch(/20\/03\/2024, \d{2}:\d{2}:\d{2}/);
    });

    it('should return empty string for null', () => {
      expect(formatDateTime(null)).toBe('');
    });

    it('should return empty string for undefined', () => {
      expect(formatDateTime(undefined)).toBe('');
    });

    it('should return empty string for empty string', () => {
      expect(formatDateTime('')).toBe('');
    });

    it('should handle invalid date string', () => {
      const result = formatDateTime('not a date');
      expect(result).toBe('');
    });

    it('should warn for invalid dates', () => {
      const consoleWarnSpy = vi.spyOn(console, 'warn');
      formatDateTime('invalid');
      expect(consoleWarnSpy).toHaveBeenCalledWith('Invalid date:', 'invalid');
    });

    it('should pad single digit days', () => {
      const date = new Date('2024-01-05T10:30:45');
      const result = formatDateTime(date);
      expect(result).toContain('05/01/2024');
    });

    it('should pad single digit months', () => {
      const date = new Date('2024-03-15T10:30:45');
      const result = formatDateTime(date);
      expect(result).toContain('15/03/2024');
    });

    it('should pad single digit hours', () => {
      const date = new Date('2024-01-15T05:30:45');
      const result = formatDateTime(date);
      expect(result).toMatch(/05:\d{2}:\d{2}/);
    });

    it('should pad single digit minutes', () => {
      const date = new Date('2024-01-15T10:05:45');
      const result = formatDateTime(date);
      expect(result).toMatch(/\d{2}:05:\d{2}/);
    });

    it('should pad single digit seconds', () => {
      const date = new Date('2024-01-15T10:30:05');
      const result = formatDateTime(date);
      expect(result).toMatch(/\d{2}:\d{2}:05/);
    });

    it('should handle midnight correctly', () => {
      const date = new Date('2024-01-15T00:00:00');
      const result = formatDateTime(date);
      expect(result).toContain('00:00:00');
    });

    it('should handle end of day correctly', () => {
      const date = new Date('2024-01-15T23:59:59');
      const result = formatDateTime(date);
      expect(result).toContain('23:59:59');
    });

    it('should handle leap year dates', () => {
      const date = new Date('2024-02-29T12:00:00');
      const result = formatDateTime(date);
      expect(result).toContain('29/02/2024');
    });

    it('should handle year 2000', () => {
      const date = new Date('2000-12-31T23:59:59');
      const result = formatDateTime(date);
      expect(result).toContain('2000');
    });

    it('should handle different timezones when parsing ISO strings', () => {
      const result = formatDateTime('2024-01-15T10:30:45+05:30');
      expect(result).toContain('2024');
    });

    it('should convert string dates to Date objects', () => {
      const result = formatDateTime('2024-06-15T15:45:30');
      expect(result).toMatch(/\d{2}\/\d{2}\/2024, \d{2}:\d{2}:\d{2}/);
    });

    it('should handle Date objects directly without conversion', () => {
      const date = new Date(2024, 0, 15, 10, 30, 45);
      const result = formatDateTime(date);
      expect(result).toContain('15/01/2024');
    });

    it('should handle very old dates', () => {
      const date = new Date('1900-01-01T00:00:00');
      const result = formatDateTime(date);
      expect(result).toContain('1900');
    });

    it('should handle future dates', () => {
      const date = new Date('2099-12-31T23:59:59');
      const result = formatDateTime(date);
      expect(result).toContain('2099');
    });

    it('should include comma separator', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTime(date);
      expect(result).toContain(', ');
    });

    it('should use colon separators in time', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTime(date);
      expect(result).toMatch(/\d{2}:\d{2}:\d{2}/);
    });
  });

  describe('formatDateTimeShort', () => {
    it('should format Date object without seconds', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toMatch(/15\/01\/2024, \d{2}:\d{2}/);
      expect(result).not.toContain(':45');
    });

    it('should format ISO string without seconds', () => {
      const result = formatDateTimeShort('2024-03-20T14:25:30Z');
      expect(result).toMatch(/20\/03\/2024, \d{2}:\d{2}/);
      expect(result).not.toMatch(/:\d{2}:\d{2}/);
    });

    it('should return empty string for null', () => {
      expect(formatDateTimeShort(null)).toBe('');
    });

    it('should return empty string for undefined', () => {
      expect(formatDateTimeShort(undefined)).toBe('');
    });

    it('should return empty string for empty string', () => {
      expect(formatDateTimeShort('')).toBe('');
    });

    it('should handle invalid date string', () => {
      const result = formatDateTimeShort('not a date');
      expect(result).toBe('');
    });

    it('should warn for invalid dates', () => {
      const consoleWarnSpy = vi.spyOn(console, 'warn');
      formatDateTimeShort('invalid');
      expect(consoleWarnSpy).toHaveBeenCalledWith('Invalid date:', 'invalid');
    });

    it('should pad single digit days', () => {
      const date = new Date('2024-01-05T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toContain('05/01/2024');
    });

    it('should pad single digit months', () => {
      const date = new Date('2024-03-15T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toContain('15/03/2024');
    });

    it('should pad single digit hours', () => {
      const date = new Date('2024-01-15T05:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toMatch(/05:\d{2}/);
    });

    it('should pad single digit minutes', () => {
      const date = new Date('2024-01-15T10:05:45');
      const result = formatDateTimeShort(date);
      expect(result).toMatch(/\d{2}:05/);
    });

    it('should handle midnight correctly', () => {
      const date = new Date('2024-01-15T00:00:00');
      const result = formatDateTimeShort(date);
      expect(result).toContain('00:00');
    });

    it('should handle end of day correctly', () => {
      const date = new Date('2024-01-15T23:59:59');
      const result = formatDateTimeShort(date);
      expect(result).toContain('23:59');
    });

    it('should not include seconds in output', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result.split(':').length).toBe(2);
    });

    it('should handle leap year dates', () => {
      const date = new Date('2024-02-29T12:00:00');
      const result = formatDateTimeShort(date);
      expect(result).toContain('29/02/2024');
    });

    it('should handle year 2000', () => {
      const date = new Date('2000-12-31T23:59:59');
      const result = formatDateTimeShort(date);
      expect(result).toContain('2000');
    });

    it('should convert string dates to Date objects', () => {
      const result = formatDateTimeShort('2024-06-15T15:45:30');
      expect(result).toMatch(/\d{2}\/\d{2}\/2024, \d{2}:\d{2}/);
    });

    it('should handle Date objects directly', () => {
      const date = new Date(2024, 0, 15, 10, 30, 45);
      const result = formatDateTimeShort(date);
      expect(result).toContain('15/01/2024');
    });

    it('should include comma separator', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toContain(', ');
    });

    it('should use colon separator in time', () => {
      const date = new Date('2024-01-15T10:30:45');
      const result = formatDateTimeShort(date);
      expect(result).toMatch(/\d{2}:\d{2}/);
    });

    it('should format differently than formatDateTime', () => {
      const date = new Date('2024-01-15T10:30:45');
      const full = formatDateTime(date);
      const short = formatDateTimeShort(date);
      expect(full).not.toBe(short);
      expect(full.length).toBeGreaterThan(short.length);
    });
  });

  describe('Mutation-specific coverage', () => {
    // Kill mutant: ConditionalExpression typeof dateInput === 'string' → true
    it('formatDateTime should handle Date objects correctly not just strings', () => {
      // If mutation changes to always true, Date objects would be incorrectly converted
      const dateObj = new Date('2024-01-15T10:30:45');
      const result = formatDateTime(dateObj);
      
      // Should work with Date object directly
      expect(result).toContain('15/01/2024');
      expect(result).toMatch(/\d{2}:\d{2}:\d{2}/);
    });

    it('formatDateTime should convert string to Date when input is string', () => {
      const stringDate = '2024-01-15T10:30:45Z';
      const result = formatDateTime(stringDate);
      
      // Should correctly identify as string and convert
      expect(result).toContain('2024');
      expect(result).toMatch(/\d{2}\/\d{2}\/\d{4}/);
    });

    it('formatDateTime should check typeof specifically not assume all inputs are strings', () => {
      // Test with number (timestamp)
      const timestamp = new Date('2024-01-15T10:30:45');
      const result = formatDateTime(timestamp);
      
      // Should handle non-string Date object
      expect(typeof timestamp).not.toBe('string');
      expect(result).toBeTruthy();
    });

    // Kill mutant: ConditionalExpression typeof dateInput === 'string' → true (for formatDateTimeShort)
    it('formatDateTimeShort should handle Date objects correctly not just strings', () => {
      const dateObj = new Date('2024-01-15T10:30:45');
      const result = formatDateTimeShort(dateObj);
      
      // Should work with Date object directly
      expect(result).toContain('15/01/2024');
      expect(result).toMatch(/\d{2}:\d{2}/);
    });

    it('formatDateTimeShort should convert string to Date when input is string', () => {
      const stringDate = '2024-01-15T10:30:45Z';
      const result = formatDateTimeShort(stringDate);
      
      // Should correctly identify as string and convert
      expect(result).toContain('2024');
      expect(result).toMatch(/\d{2}\/\d{2}\/\d{4}/);
    });

    it('should differentiate between string and Date object inputs', () => {
      const stringInput = '2024-01-15T10:30:45';
      const dateInput = new Date('2024-01-15T10:30:45');
      
      const fromString = formatDateTime(stringInput);
      const fromDate = formatDateTime(dateInput);
      
      // Both should work, proving typeof check is necessary
      expect(typeof stringInput).toBe('string');
      expect(typeof dateInput).toBe('object');
      expect(fromString).toBeTruthy();
      expect(fromDate).toBeTruthy();
    });

    it('should handle edge case where Date object looks like it might be string', () => {
      const date = new Date('2024-01-15');
      
      // Verify it's not a string
      expect(typeof date).toBe('object');
      expect(date instanceof Date).toBe(true);
      
      // Should still format correctly
      const result = formatDateTime(date);
      expect(result).toContain('2024');
    });
  });
});
