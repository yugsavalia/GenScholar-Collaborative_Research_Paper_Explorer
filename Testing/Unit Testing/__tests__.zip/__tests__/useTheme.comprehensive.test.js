import { describe, test, expect, beforeEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useTheme } from '@/hooks/useTheme';
import * as theme from '@/utils/theme';

// Mock theme utilities
vi.mock('@/utils/theme', () => ({
  initTheme: vi.fn(),
  toggleTheme: vi.fn(),
  getTheme: vi.fn(() => 'dark'),
  THEMES: {
    LIGHT: 'light',
    DARK: 'dark'
  }
}));

describe('useTheme hook comprehensive coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    theme.getTheme.mockReturnValue('dark');
  });

  test('should initialize with current theme', () => {
    theme.getTheme.mockReturnValue('dark');
    
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('dark');
  });

  test('should initialize with light theme when stored', () => {
    theme.getTheme.mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('light');
  });

  test('should call initTheme on mount', () => {
    renderHook(() => useTheme());
    
    expect(theme.initTheme).toHaveBeenCalled();
  });

  test('should toggle theme', () => {
    theme.toggleTheme.mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    
    expect(theme.toggleTheme).toHaveBeenCalled();
    expect(result.current.theme).toBe('light');
  });

  test('should toggle from light to dark', () => {
    theme.getTheme.mockReturnValue('light');
    theme.toggleTheme.mockReturnValue('dark');
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe('dark');
  });

  test('should toggle from dark to light', () => {
    theme.getTheme.mockReturnValue('dark');
    theme.toggleTheme.mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe('light');
  });

  test('should update theme state after toggle', () => {
    const { result } = renderHook(() => useTheme());
    const initialTheme = result.current.theme;
    
    theme.toggleTheme.mockReturnValue(initialTheme === 'dark' ? 'light' : 'dark');
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).not.toBe(initialTheme);
  });

  test('should handle multiple toggles', () => {
    const { result } = renderHook(() => useTheme());
    
    theme.toggleTheme.mockReturnValue('light');
    act(() => result.current.toggle());
    expect(result.current.theme).toBe('light');
    
    theme.toggleTheme.mockReturnValue('dark');
    act(() => result.current.toggle());
    expect(result.current.theme).toBe('dark');
    
    theme.toggleTheme.mockReturnValue('light');
    act(() => result.current.toggle());
    expect(result.current.theme).toBe('light');
  });

  test('should return both theme and toggle function', () => {
    const { result } = renderHook(() => useTheme());
    
    expect(result.current).toHaveProperty('theme');
    expect(result.current).toHaveProperty('toggle');
    expect(typeof result.current.toggle).toBe('function');
  });

  test('should handle theme state persistence', () => {
    theme.getTheme.mockReturnValue('dark');
    
    const { result } = renderHook(() => useTheme());
    
    // State should persist
    expect(result.current.theme).toBe('dark');
    expect(typeof result.current.theme).toBe('string');
  });

  test('should provide consistent toggle behavior', () => {
    const { result } = renderHook(() => useTheme());
    
    // Toggle should be callable
    expect(typeof result.current.toggle).toBe('function');
    
    theme.toggleTheme.mockReturnValue('light');
    act(() => result.current.toggle());
    
    expect(theme.toggleTheme).toHaveBeenCalled();
  });
});
