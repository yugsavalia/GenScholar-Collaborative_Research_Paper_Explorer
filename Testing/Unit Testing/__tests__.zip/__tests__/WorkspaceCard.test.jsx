import React from 'react';
import { vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import WorkspaceCard from '@/components/WorkspaceCard';
import { MemoryRouter } from 'wouter';

// Mock all dependencies
vi.mock('@/components/Modal', () => {
  return {
    default: ({ children, isOpen }) => isOpen ? <div data-testid="modal">{children}</div> : null
  };
});

vi.mock('@/components/Button', () => {
  return {
    default: ({ children, onClick, ...props }) => <button onClick={onClick} {...props}>{children}</button>
  };
});

vi.mock('@/components/Icon', () => {
  return {
    default: ({ name }) => <i data-testid={`icon-${name}`} />
  };
});

// Mock AppContext
vi.mock('@/context/AppContext', () => ({
  useApp: () => ({
    workspaces: [],
    deleteWorkspace: vi.fn().mockResolvedValue({}),
    loading: false
  })
}));

describe('WorkspaceCard component', () => {
  const mockWorkspace = {
    id: 1,
    name: 'Test Workspace',
    description: 'This is a test workspace for our application.',
    createdAt: '2023-10-27T10:00:00Z',
  };

  test('component is defined and exported', () => {
    expect(WorkspaceCard).toBeDefined();
    expect(typeof WorkspaceCard).toBe('function');
  });

  test('accepts workspace prop', () => {
    const props = { workspace: mockWorkspace };
    expect(props.workspace.id).toBe(1);
    expect(props.workspace.name).toBe('Test Workspace');
  });

  test('workspace has required fields', () => {
    expect(mockWorkspace).toHaveProperty('id');
    expect(mockWorkspace).toHaveProperty('name');
    expect(mockWorkspace).toHaveProperty('createdAt');
  });

  test('date formatting works', () => {
    const formattedDate = new Date(mockWorkspace.createdAt).toLocaleDateString();
    expect(formattedDate).toBeTruthy();
    expect(typeof formattedDate).toBe('string');
  });
});

