import { getCsrfToken } from '@/utils/csrf';

describe('utils/csrf', () => {
  it('should return the CSRF token from the cookie', async () => {
    Object.defineProperty(document, 'cookie', {
      writable: true,
      value: 'csrftoken=test-csrf-token',
    });
    const token = await getCsrfToken();
    expect(token).toBe('test-csrf-token');
  });

  it('should return an empty string if the cookie is not found', async () => {
    Object.defineProperty(document, 'cookie', {
      writable: true,
      value: '',
    });
    const token = await getCsrfToken();
    expect(token).toBe('');
  });
});

