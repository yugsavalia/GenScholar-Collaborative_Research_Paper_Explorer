import { vi } from 'vitest';
import { login, signup, logout, getCurrentUser } from '@/api/auth';
import { apiGet, apiPost } from '@/api/client';

// Mock the api client
vi.mock('@/api/client', () => ({
  apiGet: vi.fn(),
  apiPost: vi.fn(),
}));

describe('api/auth', () => {
  beforeEach(() => {
    // Clear all mocks before each test
    vi.clearAllMocks();
  });

  // --- login ---
  describe('login', () => {
    it('should call apiPost with correct credentials and return user data', async () => {
      const identifier = 'testuser';
      const password = 'password123';
      const mockUser = { id: 1, username: 'testuser' };
      apiPost.mockResolvedValue({ data: { user: mockUser } });

      const result = await login(identifier, password);

      expect(apiPost).toHaveBeenCalledWith('/api/auth/login/', {
        identifier,
        password,
      });
      expect(result).toEqual(mockUser);
    });

    it('should throw an error if the API call fails', async () => {
      const error = new Error('Login failed');
      apiPost.mockRejectedValue(error);

      await expect(login('test', 'wrong')).rejects.toThrow('Login failed');
    });
  });

  // --- signup ---
  describe('signup', () => {
    it('should call apiPost with correct user details and return new user data', async () => {
      const userData = {
        username: 'newuser',
        email: 'new@example.com',
        password: 'password123',
        confirm_password: 'password123',
      };
      const mockUser = { id: 2, username: 'newuser' };
      apiPost.mockResolvedValue({ data: { user: mockUser } });

      const result = await signup(
        userData.username,
        userData.email,
        userData.password,
        userData.confirm_password
      );

      expect(apiPost).toHaveBeenCalledWith('/api/auth/signup/', userData);
      expect(result).toEqual(mockUser);
    });
  });

  // --- logout ---
  describe('logout', () => {
    it('should call apiPost to the logout endpoint and return the success message', async () => {
      const mockResponse = { message: 'Logged out successfully' };
      apiPost.mockResolvedValue({ data: mockResponse });

      const result = await logout();

      expect(apiPost).toHaveBeenCalledWith('/api/auth/logout/', {});
      expect(result).toEqual(mockResponse);
    });
  });

  // --- getCurrentUser ---
  describe('getCurrentUser', () => {
    it('should call apiGet and return user data if authenticated', async () => {
      const mockUser = { id: 1, username: 'testuser' };
      apiGet.mockResolvedValue({ data: { user: mockUser } });

      const result = await getCurrentUser();

      expect(apiGet).toHaveBeenCalledWith('/api/auth/user/');
      expect(result).toEqual(mockUser);
    });

    it('should return null if the user is not authenticated (401 error)', async () => {
      const error = new Error('Not authenticated');
      // @ts-ignore
      error.status = 401;
      apiGet.mockRejectedValue(error);

      const result = await getCurrentUser();

      expect(apiGet).toHaveBeenCalledWith('/api/auth/user/');
      expect(result).toBeNull();
    });

    it('should rethrow other errors (non-401)', async () => {
      const error = new Error('Server error');
      // @ts-ignore
      error.status = 500;
      apiGet.mockRejectedValue(error);

      await expect(getCurrentUser()).rejects.toThrow('Server error');
    });
  });
});


