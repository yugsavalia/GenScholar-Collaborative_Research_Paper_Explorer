import React from 'react';
import { vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import NotFound from '@/pages/not-found';

// Mocking shadcn/ui components and lucide-react icon
vi.mock('@/components/ui/card', () => ({
  Card: ({ children, className }) => <div className={`mock-card ${className}`}>{children}</div>,
  CardContent: ({ children, className }) => <div className={`mock-card-content ${className}`}>{children}</div>,
}));

vi.mock('lucide-react', () => ({
  AlertCircle: ({ className }) => <svg className={`mock-alert-icon ${className}`} />,
}));

describe('NotFound Page', () => {
  it('should render the 404 error message and title', () => {
    render(<NotFound />);

    // Check for the main title
    expect(screen.getByRole('heading', { name: /404 Page Not Found/i })).toBeInTheDocument();

    // Check for the icon (by checking its mock class)
    expect(document.querySelector('.mock-alert-icon')).toBeInTheDocument();

    // Check for the suggestion text
    expect(screen.getByText(/Did you forget to add the page to the router?/i)).toBeInTheDocument();
  });

  it('should apply correct styling classes for layout', () => {
    const { container } = render(<NotFound />);
    
    // Check for the main container classes
    expect(container.firstChild).toHaveClass('min-h-screen', 'w-full', 'flex', 'items-center', 'justify-center');

    // Check for card classes
    const card = document.querySelector('.mock-card');
    expect(card).toHaveClass('w-full', 'max-w-md');
  });
});


