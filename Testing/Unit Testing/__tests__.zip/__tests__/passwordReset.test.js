import { describe, it, expect, vi, beforeEach } from 'vitest';
import { requestPasswordReset, confirmPasswordReset } from '../api/passwordReset';
import * as client from '../api/client';

vi.mock('../api/client');

describe('api/passwordReset', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('requestPasswordReset', () => {
    it('should request password reset with email', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ success: true });

      await requestPasswordReset('test@example.com');

      expect(client.apiPost).toHaveBeenCalledWith('/api/auth/password-reset/', {
        email: 'test@example.com'
      });
    });

    it('should return response from API', async () => {
      const mockResponse = { success: true, message: 'Email sent' };
      vi.mocked(client.apiPost).mockResolvedValue(mockResponse);

      const result = await requestPasswordReset('user@test.com');

      expect(result).toEqual(mockResponse);
    });
  });

  describe('confirmPasswordReset', () => {
    it('should confirm password reset with all parameters', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ success: true });

      await confirmPasswordReset('uid123', 'token456', 'newpass', 'newpass');

      expect(client.apiPost).toHaveBeenCalledWith('/api/auth/password-reset/confirm/', {
        uid: 'uid123',
        token: 'token456',
        new_password: 'newpass',
        re_new_password: 'newpass'
      });
    });

    it('should return response from API', async () => {
      const mockResponse = { success: true, message: 'Password reset' };
      vi.mocked(client.apiPost).mockResolvedValue(mockResponse);

      const result = await confirmPasswordReset('uid', 'token', 'pass1', 'pass1');

      expect(result).toEqual(mockResponse);
    });
  });
});
