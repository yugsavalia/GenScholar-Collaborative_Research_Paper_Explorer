import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useTheme } from '../hooks/useTheme';
import * as themeUtils from '../utils/theme';

vi.mock('../utils/theme', () => ({
  initTheme: vi.fn(),
  toggleTheme: vi.fn(() => 'light'),
  getTheme: vi.fn(() => 'dark'),
}));

describe('hooks/useTheme - Comprehensive Mutation Coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(themeUtils.getTheme).mockReturnValue('dark');
    vi.mocked(themeUtils.toggleTheme).mockReturnValue('light');
  });

  it('should initialize with dark theme by default', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('dark');
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('dark');
  });

  it('should initialize with light theme when getTheme returns light', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('light');
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('light');
  });

  it('should call initTheme on mount', () => {
    renderHook(() => useTheme());
    expect(themeUtils.initTheme).toHaveBeenCalled();
  });

  it('should call getTheme on mount', () => {
    renderHook(() => useTheme());
    expect(themeUtils.getTheme).toHaveBeenCalled();
  });

  it('should call getTheme after initTheme in useEffect', () => {
    const callOrder = [];
    vi.mocked(themeUtils.initTheme).mockImplementation(() => {
      callOrder.push('initTheme');
    });
    vi.mocked(themeUtils.getTheme).mockImplementation(() => {
      callOrder.push('getTheme');
      return 'dark';
    });
    
    renderHook(() => useTheme());
    
    expect(callOrder).toEqual(['getTheme', 'initTheme', 'getTheme']);
  });

  it('should toggle theme from dark to light', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('dark');
    vi.mocked(themeUtils.toggleTheme).mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('dark');
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe('light');
    expect(themeUtils.toggleTheme).toHaveBeenCalled();
  });

  it('should toggle theme from light to dark', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('light');
    vi.mocked(themeUtils.toggleTheme).mockReturnValue('dark');
    
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('light');
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe('dark');
  });

  it('should update theme state after toggle', () => {
    const { result } = renderHook(() => useTheme());
    const initialTheme = result.current.theme;
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).not.toBe(initialTheme);
  });

  it('should handle typeof window check in useState', () => {
    // In browser environment, window is always defined
    // This test verifies the hook works in normal browser context
    const { result } = renderHook(() => useTheme());
    expect(['dark', 'light']).toContain(result.current.theme);
  });

  it('should check if window is undefined before calling getTheme in useState', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('light');
    const { result } = renderHook(() => useTheme());
    
    // Should call getTheme since window is defined
    expect(result.current.theme).toBe('light');
  });

  it('should provide both theme and toggle function', () => {
    const { result } = renderHook(() => useTheme());
    
    expect(result.current).toHaveProperty('theme');
    expect(result.current).toHaveProperty('toggle');
    expect(typeof result.current.toggle).toBe('function');
  });

  it('should handle multiple toggle calls', () => {
    vi.mocked(themeUtils.toggleTheme)
      .mockReturnValueOnce('light')
      .mockReturnValueOnce('dark')
      .mockReturnValueOnce('light');
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    expect(result.current.theme).toBe('light');
    
    act(() => {
      result.current.toggle();
    });
    expect(result.current.theme).toBe('dark');
    
    act(() => {
      result.current.toggle();
    });
    expect(result.current.theme).toBe('light');
  });

  it('should update state with value returned from toggleTheme', () => {
    const newTheme = 'custom-theme';
    vi.mocked(themeUtils.toggleTheme).mockReturnValue(newTheme);
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe(newTheme);
  });

  it('should not call toggleTheme until toggle is invoked', () => {
    renderHook(() => useTheme());
    
    expect(themeUtils.toggleTheme).not.toHaveBeenCalled();
  });

  it('should call setTheme with new theme after toggle', () => {
    vi.mocked(themeUtils.toggleTheme).mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    act(() => {
      result.current.toggle();
    });
    
    expect(result.current.theme).toBe('light');
  });

  it('should use empty dependency array for useEffect', () => {
    const { rerender } = renderHook(() => useTheme());
    const initialCallCount = vi.mocked(themeUtils.initTheme).mock.calls.length;
    
    rerender();
    
    // Should not call again on rerender (empty dependency array)
    expect(vi.mocked(themeUtils.initTheme).mock.calls.length).toBe(initialCallCount);
  });

  it('should store theme state correctly', () => {
    vi.mocked(themeUtils.getTheme).mockReturnValue('dark');
    const { result } = renderHook(() => useTheme());
    
    expect(result.current.theme).toBe('dark');
    expect(typeof result.current.theme).toBe('string');
  });

  // Kill mutant: typeof window !== ""
  it('should handle window type check correctly - not empty string', () => {
    // In test environment, window should not be an empty string
    const { result } = renderHook(() => useTheme());
    
    // Verify window is not empty string
    expect(typeof window).not.toBe('');
    expect(typeof window).toBe('object');
    expect(result.current.theme).toBeTruthy();
  });

  // Kill mutant: dependency array mutation ["Stryker was here"]
  it('should run useEffect exactly once on mount', () => {
    vi.clearAllMocks();
    
    const { rerender } = renderHook(() => useTheme());
    
    // Called once on mount
    expect(themeUtils.initTheme).toHaveBeenCalledTimes(1);
    
    // Rerender multiple times
    rerender();
    rerender();
    rerender();
    
    // Should still be called only once (empty dependency array)
    expect(themeUtils.initTheme).toHaveBeenCalledTimes(1);
  });

  // Kill mutant: ConditionalExpression if (true)
  it('should only call getTheme when window is defined', () => {
    vi.clearAllMocks();
    vi.mocked(themeUtils.getTheme).mockReturnValue('light');
    
    const { result } = renderHook(() => useTheme());
    
    // In browser environment (typeof window !== 'undefined'), getTheme is called
    expect(themeUtils.getTheme).toHaveBeenCalled();
    expect(result.current.theme).toBe('light');
  });
});
