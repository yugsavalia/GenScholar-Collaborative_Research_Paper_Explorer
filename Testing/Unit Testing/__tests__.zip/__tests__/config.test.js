import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('api/config', () => {
  beforeEach(() => {
    vi.unstubAllEnvs();
  });

  it('should use environment variable when set', async () => {
    vi.stubEnv('VITE_API_BASE_URL', 'https://api.example.com');
    
    // Re-import to get fresh module with new env
    const module = await import('../api/config.js?t=' + Date.now());
    expect(module.API_BASE_URL).toBe('https://api.example.com');
  });

  it('should use default localhost when env variable not set', async () => {
    const module = await import('../api/config.js');
    // May be set from environment or default to localhost
    expect(typeof module.API_BASE_URL).toBe('string');
    expect(module.API_BASE_URL.length).toBeGreaterThan(0);
  });

  it('should export API_BASE_URL as a string', async () => {
    const module = await import('../api/config.js');
    expect(typeof module.API_BASE_URL).toBe('string');
  });

  it('should have a valid URL format', async () => {
    const module = await import('../api/config.js');
    expect(() => new URL(module.API_BASE_URL)).not.toThrow();
  });
});
