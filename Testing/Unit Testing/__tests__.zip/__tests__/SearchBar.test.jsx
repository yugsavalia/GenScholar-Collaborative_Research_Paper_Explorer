import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import '@testing-library/jest-dom';

import SearchBar from '@/components/SearchBar';


describe('SearchBar component', () => {
  const handleChange = vi.fn();

  beforeEach(() => {
    render(<SearchBar value="" onChange={handleChange} placeholder="Search for documents..." />);
  });

  afterEach(() => {
    handleChange.mockClear();
  });

  test('renders with a placeholder', () => {
    expect(screen.getByPlaceholderText('Search for documents...')).toBeInTheDocument();
  });

  test('renders the search icon', () => {
    const input = screen.getByTestId('input-search');
    const container = input.parentElement.parentElement;
    const svgElement = container.querySelector('svg');
    expect(svgElement).toBeInTheDocument();
    expect(svgElement.querySelector('circle')).toBeInTheDocument();
  });

  test('calls onChange when the user types in the input', () => {
    const input = screen.getByTestId('input-search');
    fireEvent.change(input, { target: { value: 'new query' } });
    expect(handleChange).toHaveBeenCalledTimes(1);
    expect(handleChange).toHaveBeenCalledWith('new query');
  });

  test('displays the correct value', () => {
    // Re-render with a specific value
    render(<SearchBar value="initial query" onChange={handleChange} />);
    const input = screen.getByDisplayValue('initial query');
    expect(input).toBeInTheDocument();
  });
});


