import { vi } from 'vitest';
import React from 'react';

import { render, screen } from '@testing-library/react';

import '@testing-library/jest-dom';

import InvitationList from '@/components/InvitationList';


// Mock the InvitationCard component
vi.mock('@/components/InvitationCard', () => ({ 
  default: ({ invitation, onAccept, onDecline }) => (
    <div data-testid={`invitation-card-${invitation.id}`}>
      <span>{invitation.workspace.name}</span>
      <button onClick={() => onAccept(invitation.id)}>Accept</button>
      <button onClick={() => onDecline(invitation.id)}>Decline</button>
    </div>
  )
}));

describe('InvitationList component', () => {
  const mockInvitations = [
    { id: 1, workspace: { name: 'Workspace A' } },
    { id: 2, workspace: { name: 'Workspace B' } },
  ];

  const handleAccept = vi.fn();
  const handleDecline = vi.fn();

  test('renders a list of invitations', () => {
    render(
      <InvitationList
        invitations={mockInvitations}
        onAccept={handleAccept}
        onDecline={handleDecline}
      />
    );
    expect(screen.getByText('Workspace A')).toBeInTheDocument();
    expect(screen.getByText('Workspace B')).toBeInTheDocument();
    expect(screen.getAllByTestId(/invitation-card-/)).toHaveLength(2);
  });

  test('renders a message when there are no invitations', () => {
    render(<InvitationList invitations={[]} />);
    expect(screen.getByText('No pending invitations')).toBeInTheDocument();
  });

  test('passes the onAccept and onDecline handlers to InvitationCard', () => {
    render(
      <InvitationList
        invitations={mockInvitations}
        onAccept={handleAccept}
        onDecline={handleDecline}
      />
    );
    
    const acceptButton = screen.getAllByRole('button', { name: 'Accept' })[0];
    const declineButton = screen.getAllByRole('button', { name: 'Decline' })[1];

    acceptButton.click();
    expect(handleAccept).toHaveBeenCalledWith(mockInvitations[0].id);

    declineButton.click();
    expect(handleDecline).toHaveBeenCalledWith(mockInvitations[1].id);
  });

  test('uses onInvitationUpdate as a fallback for onAccept and onDecline', () => {
    const handleInvitationUpdate = vi.fn();
    render(
      <InvitationList
        invitations={mockInvitations}
        onInvitationUpdate={handleInvitationUpdate}
      />
    );

    const acceptButton = screen.getAllByRole('button', { name: 'Accept' })[0];
    acceptButton.click();
    expect(handleInvitationUpdate).toHaveBeenCalledWith(mockInvitations[0].id);
  });
});


