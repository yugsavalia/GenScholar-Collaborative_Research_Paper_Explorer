import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import '@testing-library/jest-dom';

import ThreadPanel from '@/components/ThreadPanel';

import ThreadItem from '@/components/ThreadItem';

import { storage } from '@/utils/storage';


vi.mock('@/utils/storage', () => ({
    storage: {
        get: vi.fn(),
        set: vi.fn(),
    },
    STORAGE_KEYS: {
        THREADS: vi.fn((ws, pdf, an) => `threads_${ws}_${pdf}_${an}`),
    },
}));

// Separate describe block for ThreadPanel, which can have a mock if needed
describe('ThreadPanel', () => {
    const mockAnnotation = { id: 'anno1', text: 'Selected text' };

    beforeEach(() => {
        storage.get.mockClear();
    });

    it('renders placeholder when no annotation is selected', () => {
        render(<ThreadPanel workspaceId="ws1" pdfId="pdf1" selectedAnnotation={null} />);
        expect(screen.getByText('Select text in the PDF to start a threaded discussion')).toBeInTheDocument();
    });

    it('renders ThreadItem when an annotation is selected', () => {
        storage.get.mockReturnValue([]);
        render(<ThreadPanel workspaceId="ws1" pdfId="pdf1" selectedAnnotation={mockAnnotation} />);
        expect(screen.getByText(/"Selected text"/)).toBeInTheDocument();
    });
});

// Separate describe block for ThreadItem, using the real component
describe('ThreadItem', () => {
    const mockMessages = [
        { id: 1, content: 'Hello', author: 'other' },
        { id: 2, content: 'Hi there', author: 'me' },
    ];

    it('renders selection text and messages', () => {
        render(<ThreadItem selectionText="A selection" messages={mockMessages} onAddMessage={() => {}} />);
        expect(screen.getByText(/"A selection"/)).toBeInTheDocument();
        expect(screen.getByText('Hello')).toBeInTheDocument();
        expect(screen.getByText('Hi there')).toBeInTheDocument();
    });

    it('calls onAddMessage when send button is clicked', () => {
        const onAddMessage = vi.fn();
        render(<ThreadItem selectionText="A selection" messages={[]} onAddMessage={onAddMessage} />);
        
        const input = screen.getByTestId('input-thread');
        fireEvent.change(input, { target: { value: 'A new message' } });
        
        const sendButton = screen.getByTestId('button-send-thread');
        fireEvent.click(sendButton);
        
        expect(onAddMessage).toHaveBeenCalledWith('A new message');
    });
});



