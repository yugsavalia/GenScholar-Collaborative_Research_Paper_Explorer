import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { AppProvider, useApp } from '../context/AppContext';
import * as workspacesApi from '../api/workspaces';
import * as pdfsApi from '../api/pdfs';
import * as threadsApi from '../api/threads';

// Mock all API modules
vi.mock('../api/workspaces');
vi.mock('../api/pdfs');
vi.mock('../api/threads');
vi.mock('../utils/storage');

const mockWorkspace = {
  id: 123,
  name: 'Test Workspace',
  created_at: '2024-01-01T00:00:00Z',
  created_by: 'user-1',
  is_creator: true
};

const mockMember = {
  id: 1,
  user: { id: 'user-1', username: 'testuser', email: 'test@example.com' },
  role: 'admin',
  is_creator: true,
  joined_at: '2024-01-01T00:00:00Z'
};

const mockInvitation = {
  id: 1,
  workspace: { id: 123, name: 'Test Workspace' },
  invited_by: 'user-1',
  role: 'member',
  created_at: '2024-01-01T00:00:00Z'
};

const mockNotification = {
  id: 1,
  message: 'Test notification',
  is_read: false,
  created_at: '2024-01-01T00:00:00Z'
};

const mockPdf = {
  id: 456,
  title: 'Test PDF',
  name: 'test.pdf',
  uploaded_at: '2024-01-01T00:00:00Z',
  workspace: 123
};

const mockThread = {
  id: 789,
  title: 'Test Thread',
  content: 'Thread content',
  pdf: 456,
  workspace: 123,
  created_at: '2024-01-01T00:00:00Z'
};

describe('AppContext', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    workspacesApi.getWorkspaces.mockResolvedValue([mockWorkspace]);
  });

  describe('useApp hook', () => {
    it('should throw error when used outside AppProvider', () => {
      expect(() => {
        renderHook(() => useApp());
      }).toThrow('useApp must be used within AppProvider');
    });

    it('should provide context when used inside AppProvider', () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      expect(result.current).toBeDefined();
      expect(result.current.workspaces).toBeDefined();
      expect(result.current.createWorkspace).toBeDefined();
    });
  });

  describe('Initial load', () => {
    it('should load workspaces on mount', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      expect(result.current.loading).toBe(true);
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      expect(workspacesApi.getWorkspaces).toHaveBeenCalled();
      expect(result.current.workspaces).toHaveLength(1);
      expect(result.current.workspaces[0].id).toBe('123');
      expect(result.current.workspaces[0].name).toBe('Test Workspace');
    });

    it('should transform backend workspace format correctly', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      const workspace = result.current.workspaces[0];
      expect(workspace.id).toBe('123');
      expect(workspace.name).toBe('Test Workspace');
      expect(workspace.description).toBe('');
      expect(workspace.createdAt).toBe('2024-01-01T00:00:00Z');
      expect(workspace.updatedAt).toBe('2024-01-01T00:00:00Z');
      expect(workspace.is_creator).toBe(true);
    });

    it('should set isWorkspaceCreator map correctly', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      expect(result.current.isWorkspaceCreator['123']).toBe(true);
    });

    it('should handle load error gracefully', async () => {
      workspacesApi.getWorkspaces.mockRejectedValue(new Error('Network error'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      expect(result.current.workspaces).toEqual([]);
      expect(consoleErrorSpy).toHaveBeenCalledWith('Error loading workspaces:', expect.any(Error));
      
      consoleErrorSpy.mockRestore();
    });

    it('should handle workspaces without is_creator flag', async () => {
      workspacesApi.getWorkspaces.mockResolvedValue([
        { ...mockWorkspace, is_creator: undefined }
      ]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      expect(result.current.workspaces[0].is_creator).toBe(false);
      expect(result.current.isWorkspaceCreator['123']).toBe(false);
    });
  });

  describe('createWorkspace', () => {
    it('should create workspace and update state', async () => {
      workspacesApi.createWorkspace.mockResolvedValue(mockWorkspace);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let createdWorkspace;
      await act(async () => {
        createdWorkspace = await result.current.createWorkspace('New Workspace', 'Description');
      });
      
      expect(workspacesApi.createWorkspace).toHaveBeenCalledWith('New Workspace');
      expect(createdWorkspace.id).toBe('123');
      expect(result.current.workspaces).toHaveLength(2);
    });

    it('should re-throw error on create failure', async () => {
      workspacesApi.createWorkspace.mockRejectedValue(new Error('Creation failed'));
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.createWorkspace('New Workspace');
        });
      }).rejects.toThrow('Creation failed');
    });
  });

  describe('deleteWorkspace', () => {
    it('should delete workspace and remove from state', async () => {
      workspacesApi.deleteWorkspace.mockResolvedValue();
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      expect(result.current.workspaces).toHaveLength(1);
      
      await act(async () => {
        await result.current.deleteWorkspace('123');
      });
      
      expect(workspacesApi.deleteWorkspace).toHaveBeenCalledWith('123');
      expect(result.current.workspaces).toHaveLength(0);
    });

    it('should handle numeric workspace ID', async () => {
      workspacesApi.deleteWorkspace.mockResolvedValue();
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.deleteWorkspace(123);
      });
      
      expect(result.current.workspaces).toHaveLength(0);
    });

    it('should log error and re-throw on delete failure', async () => {
      workspacesApi.deleteWorkspace.mockRejectedValue(new Error('Delete failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.deleteWorkspace('123');
        });
      }).rejects.toThrow('Delete failed');
      
      expect(consoleErrorSpy).toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('getPdfs', () => {
    beforeEach(() => {
      vi.resetModules();
      vi.doMock('../api/pdfs.js', () => ({
        getPdfs: vi.fn().mockResolvedValue([mockPdf])
      }));
    });

    it('should fetch and transform PDFs', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let pdfs;
      await act(async () => {
        pdfs = await result.current.getPdfs('123');
      });
      
      expect(pdfs).toHaveLength(1);
      expect(pdfs[0].id).toBe('456');
      expect(pdfs[0].name).toBe('Test PDF');
      expect(pdfs[0].url).toBeNull();
      expect(pdfs[0].workspaceId).toBe('123');
    });

    it('should use title when available, fallback to name', async () => {
      vi.doMock('../api/pdfs.js', () => ({
        getPdfs: vi.fn().mockResolvedValue([{ ...mockPdf, title: null }])
      }));
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let pdfs;
      await act(async () => {
        pdfs = await result.current.getPdfs('123');
      });
      
      expect(pdfs[0].name).toBe('test.pdf');
    });

    it('should return empty array on error', async () => {
      vi.doMock('../api/pdfs.js', () => ({
        getPdfs: vi.fn().mockRejectedValue(new Error('Fetch failed'))
      }));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let pdfs;
      await act(async () => {
        pdfs = await result.current.getPdfs('123');
      });
      
      expect(pdfs).toEqual([]);
      expect(consoleErrorSpy).toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('addPdf', () => {
    beforeEach(() => {
      vi.resetModules();
      vi.doMock('../api/pdfs.js', () => ({
        uploadPdf: vi.fn().mockResolvedValue(mockPdf),
        getPdfUrl: vi.fn().mockResolvedValue('blob:test-url')
      }));
    });

    it('should upload PDF and return with blob URL', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      const file = new File(['test'], 'test.pdf', { type: 'application/pdf' });
      let uploadedPdf;
      
      await act(async () => {
        uploadedPdf = await result.current.addPdf('123', file, 'Custom Title');
      });
      
      expect(uploadedPdf.id).toBe('456');
      expect(uploadedPdf.name).toBe('Test PDF');
      expect(uploadedPdf.url).toBe('blob:test-url');
    });

    it('should use file.name as title if not provided', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      const file = new File(['test'], 'test.pdf', { type: 'application/pdf' });
      
      await act(async () => {
        await result.current.addPdf('123', file);
      });
      
      // Just verify it doesn't throw
      expect(true).toBe(true);
    });

    it('should log error and re-throw on upload failure', async () => {
      vi.doMock('../api/pdfs.js', () => ({
        uploadPdf: vi.fn().mockRejectedValue(new Error('Upload failed'))
      }));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      const file = new File(['test'], 'test.pdf', { type: 'application/pdf' });
      
      await expect(async () => {
        await act(async () => {
          await result.current.addPdf('123', file);
        });
      }).rejects.toThrow();
      
      expect(consoleErrorSpy).toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('loadWorkspaceMembers', () => {
    it('should load members and update state', async () => {
      workspacesApi.getWorkspaceMembers.mockResolvedValue([mockMember]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let members;
      await act(async () => {
        members = await result.current.loadWorkspaceMembers('123', 'user-1');
      });
      
      expect(members).toEqual([mockMember]);
      expect(result.current.workspaceMembers['123']).toEqual([mockMember]);
      expect(result.current.currentWorkspaceRole['123']).toBe('admin');
      expect(result.current.isWorkspaceCreator['123']).toBe(true);
    });

    it('should work without currentUserId', async () => {
      workspacesApi.getWorkspaceMembers.mockResolvedValue([mockMember]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.loadWorkspaceMembers('123');
      });
      
      expect(result.current.workspaceMembers['123']).toEqual([mockMember]);
    });

    it('should handle user not in members list', async () => {
      workspacesApi.getWorkspaceMembers.mockResolvedValue([mockMember]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.loadWorkspaceMembers('123', 'user-999');
      });
      
      expect(result.current.currentWorkspaceRole['123']).toBeUndefined();
    });

    it('should re-throw error on failure', async () => {
      workspacesApi.getWorkspaceMembers.mockRejectedValue(new Error('Load failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.loadWorkspaceMembers('123', 'user-1');
        });
      }).rejects.toThrow('Load failed');
      
      consoleErrorSpy.mockRestore();
    });
  });

  describe('inviteUser', () => {
    it('should invite user successfully', async () => {
      workspacesApi.inviteUserToWorkspace.mockResolvedValue(mockInvitation);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let invitation;
      await act(async () => {
        invitation = await result.current.inviteUser('123', 'user-2', 'member', 'user-1');
      });
      
      expect(workspacesApi.inviteUserToWorkspace).toHaveBeenCalledWith('123', 'user-2', 'member');
      expect(invitation).toEqual(mockInvitation);
    });

    it('should re-throw error on failure', async () => {
      workspacesApi.inviteUserToWorkspace.mockRejectedValue(new Error('Invite failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.inviteUser('123', 'user-2', 'member');
        });
      }).rejects.toThrow('Invite failed');
      
      consoleErrorSpy.mockRestore();
    });
  });

  describe('changeMemberRole', () => {
    it('should change role and refresh members', async () => {
      workspacesApi.updateMemberRole.mockResolvedValue(mockMember);
      workspacesApi.getWorkspaceMembers.mockResolvedValue([mockMember]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.changeMemberRole('123', 'member-1', 'admin', 'user-1');
      });
      
      expect(workspacesApi.updateMemberRole).toHaveBeenCalledWith('123', 'member-1', 'admin');
      expect(workspacesApi.getWorkspaceMembers).toHaveBeenCalledWith('123');
    });

    it('should re-throw error on failure', async () => {
      workspacesApi.updateMemberRole.mockRejectedValue(new Error('Update failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.changeMemberRole('123', 'member-1', 'admin');
        });
      }).rejects.toThrow('Update failed');
      
      consoleErrorSpy.mockRestore();
    });
  });

  describe('Invitations', () => {
    it('should load invitations', async () => {
      workspacesApi.getPendingInvitations.mockResolvedValue([mockInvitation]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let invitations;
      await act(async () => {
        invitations = await result.current.loadInvitations();
      });
      
      expect(invitations).toEqual([mockInvitation]);
      expect(result.current.pendingInvitations).toEqual([mockInvitation]);
    });

    it('should accept invitation and refresh data', async () => {
      workspacesApi.acceptInvitation.mockResolvedValue(mockMember);
      workspacesApi.getPendingInvitations.mockResolvedValue([]);
      workspacesApi.getWorkspaces.mockResolvedValue([mockWorkspace]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.handleAcceptInvitation(1);
      });
      
      expect(workspacesApi.acceptInvitation).toHaveBeenCalledWith(1);
      expect(workspacesApi.getPendingInvitations).toHaveBeenCalled();
      expect(workspacesApi.getWorkspaces).toHaveBeenCalled();
    });

    it('should decline invitation and refresh', async () => {
      workspacesApi.declineInvitation.mockResolvedValue();
      workspacesApi.getPendingInvitations.mockResolvedValue([]);
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.handleDeclineInvitation(1);
      });
      
      expect(workspacesApi.declineInvitation).toHaveBeenCalledWith(1);
      expect(workspacesApi.getPendingInvitations).toHaveBeenCalled();
    });

    it('should handle errors in invitation operations', async () => {
      workspacesApi.getPendingInvitations.mockRejectedValue(new Error('Load failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.loadInvitations();
        });
      }).rejects.toThrow();
      
      consoleErrorSpy.mockRestore();
    });
  });

  describe('Notifications', () => {
    it('should load notifications', async () => {
      workspacesApi.getNotifications.mockResolvedValue({
        notifications: [mockNotification],
        unread_count: 1
      });
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let data;
      await act(async () => {
        data = await result.current.loadNotifications();
      });
      
      expect(data.notifications).toEqual([mockNotification]);
      expect(result.current.notifications).toEqual([mockNotification]);
      expect(result.current.unreadNotificationCount).toBe(1);
    });

    it('should handle empty notifications response', async () => {
      workspacesApi.getNotifications.mockResolvedValue({});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.loadNotifications();
      });
      
      expect(result.current.notifications).toEqual([]);
      expect(result.current.unreadNotificationCount).toBe(0);
    });

    it('should mark notification as read', async () => {
      workspacesApi.getNotifications.mockResolvedValue({
        notifications: [mockNotification],
        unread_count: 1
      });
      workspacesApi.markNotificationRead.mockResolvedValue();
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.loadNotifications();
      });
      
      await act(async () => {
        await result.current.handleMarkNotificationRead(1);
      });
      
      expect(workspacesApi.markNotificationRead).toHaveBeenCalledWith(1);
      expect(result.current.notifications[0].is_read).toBe(true);
      expect(result.current.unreadNotificationCount).toBe(0);
    });

    it('should not let unread count go negative', async () => {
      workspacesApi.getNotifications.mockResolvedValue({
        notifications: [{ ...mockNotification, is_read: true }],
        unread_count: 0
      });
      workspacesApi.markNotificationRead.mockResolvedValue();
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await act(async () => {
        await result.current.loadNotifications();
      });
      
      await act(async () => {
        await result.current.handleMarkNotificationRead(1);
      });
      
      expect(result.current.unreadNotificationCount).toBe(0);
    });

    it('should handle errors in notification operations', async () => {
      workspacesApi.getNotifications.mockRejectedValue(new Error('Load failed'));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.loadNotifications();
        });
      }).rejects.toThrow();
      
      consoleErrorSpy.mockRestore();
    });
  });

  describe('Threads', () => {
    beforeEach(() => {
      vi.resetModules();
      vi.doMock('../api/threads.js', () => ({
        getThreads: vi.fn().mockResolvedValue([mockThread]),
        createThread: vi.fn().mockResolvedValue(mockThread)
      }));
    });

    it('should get threads', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let threads;
      await act(async () => {
        threads = await result.current.getThreads('123', '456');
      });
      
      expect(threads).toEqual([mockThread]);
      expect(result.current.threadsByPdf['456']).toEqual([mockThread]);
    });

    it('should return empty array on error', async () => {
      vi.doMock('../api/threads.js', () => ({
        getThreads: vi.fn().mockRejectedValue(new Error('Fetch failed'))
      }));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      let threads;
      await act(async () => {
        threads = await result.current.getThreads('123', '456');
      });
      
      expect(threads).toEqual([]);
      consoleErrorSpy.mockRestore();
    });

    it('should create thread and update state', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      const threadData = { title: 'New Thread', content: 'Content' };
      let thread;
      
      await act(async () => {
        thread = await result.current.createThread('123', '456', threadData);
      });
      
      expect(thread).toEqual(mockThread);
      expect(result.current.threadsByPdf['456']).toContainEqual(mockThread);
    });

    it('should prepend new thread to existing threads', async () => {
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      // First get threads
      await act(async () => {
        await result.current.getThreads('123', '456');
      });
      
      // Then create new thread
      const newThread = { ...mockThread, id: 999, title: 'Newer Thread' };
      vi.doMock('../api/threads.js', () => ({
        createThread: vi.fn().mockResolvedValue(newThread),
        getThreads: vi.fn().mockResolvedValue([mockThread])
      }));
      
      await act(async () => {
        await result.current.createThread('123', '456', {});
      });
      
      expect(result.current.threadsByPdf['456'][0]).toEqual(newThread);
    });

    it('should re-throw error on create failure', async () => {
      vi.doMock('../api/threads.js', () => ({
        createThread: vi.fn().mockRejectedValue(new Error('Create failed'))
      }));
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const wrapper = ({ children }) => <AppProvider>{children}</AppProvider>;
      const { result } = renderHook(() => useApp(), { wrapper });
      
      await waitFor(() => {
        expect(result.current.loading).toBe(false);
      });
      
      await expect(async () => {
        await act(async () => {
          await result.current.createThread('123', '456', {});
        });
      }).rejects.toThrow();
      
      consoleErrorSpy.mockRestore();
    });
  });
});
