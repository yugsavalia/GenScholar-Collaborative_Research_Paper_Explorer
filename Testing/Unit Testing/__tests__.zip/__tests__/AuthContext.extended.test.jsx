import { vi } from 'vitest';
import React from 'react';
import { render, screen, act } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import * as storageModule from '@/utils/storage';
import * as authApi from '@/api/auth';

vi.mock('@/utils/storage', () => ({
  storage: {
    get: vi.fn(),
    set: vi.fn(),
    remove: vi.fn(),
  },
}));

vi.mock('@/api/auth', () => ({
  login: vi.fn(),
  signup: vi.fn(),
  logout: vi.fn(),
  getCurrentUser: vi.fn(),
}));

const storage = storageModule.storage;

const TestComponent = () => {
  const { user, login, signup, logout } = useAuth();
  
  const handleSignup = () => {
    signup('test', 'test@test.com', 'test', 'test');
  };
  
  return (
    <div>
      <div data-testid="user">{JSON.stringify(user)}</div>
      <button onClick={() => login('test', 'test')}>Login</button>
      <button onClick={handleSignup}>Signup</button>
      <button onClick={() => logout()}>Logout</button>
    </div>
  );
};

describe('context/AuthContext extended', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    storage.get.mockReturnValue(null);
  });

  it('should login a user and set user state', async () => {
    const user = { id: 1, username: 'test' };
    authApi.login.mockResolvedValue(user);

    await act(async () => {
      render(
        <AuthProvider>
          <TestComponent />
        </AuthProvider>
      );
    });

    await act(async () => {
      screen.getByText('Login').click();
    });

    expect(authApi.login).toHaveBeenCalledWith('test', 'test');
    expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(user));
  });

  it('should signup a user and set user state', async () => {
    const user = { id: 1, username: 'test' };
    authApi.signup.mockResolvedValue(user);

    await act(async () => {
      render(
        <AuthProvider>
          <TestComponent />
        </AuthProvider>
      );
    });

    await act(async () => {
      screen.getByText('Signup').click();
    });

    expect(authApi.signup).toHaveBeenCalledWith('test', 'test@test.com', 'test', 'test', undefined);
    expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(user));
  });

  it('should logout a user and clear user state', async () => {
    const user = { id: 1, username: 'test' };
    authApi.getCurrentUser.mockResolvedValue(user);

    await act(async () => {
      render(
        <AuthProvider>
          <TestComponent />
        </AuthProvider>
      );
    });

    expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(user));

    await act(async () => {
      screen.getByText('Logout').click();
    });

    expect(authApi.logout).toHaveBeenCalled();
    expect(screen.getByTestId('user')).toHaveTextContent('null');
  });

  it('should load user from token on mount', async () => {
    const user = { id: 1, username: 'test' };
    authApi.getCurrentUser.mockResolvedValue(user);

    await act(async () => {
      render(
        <AuthProvider>
          <TestComponent />
        </AuthProvider>
      );
    });

    expect(authApi.getCurrentUser).toHaveBeenCalled();
    expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(user));
  });

  it('should handle authentication check error on mount', async () => {
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    authApi.getCurrentUser.mockRejectedValue(new Error('Auth check failed'));

    await act(async () => {
      render(
        <AuthProvider>
          <TestComponent />
        </AuthProvider>
      );
    });

    expect(consoleSpy).toHaveBeenCalledWith('Error checking authentication:', expect.any(Error));
    expect(screen.getByTestId('user')).toHaveTextContent('null');
    consoleSpy.mockRestore();
  });

});


