import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Input } from '@/components/ui/input';
import { vi } from 'vitest';

describe('Input component', () => {
  test('renders input element', () => {
    const { container } = render(<Input />);
    const inputElement = container.querySelector('input');
    expect(inputElement).toBeInTheDocument();
  });

  test('handles onChange event', () => {
    const handleChange = vi.fn();
    const { container } = render(<Input onChange={handleChange} />);
    const inputElement = container.querySelector('input');
    fireEvent.change(inputElement, { target: { value: 'testing' } });
    expect(handleChange).toHaveBeenCalledTimes(1);
    expect(inputElement.value).toBe('testing');
  });

  test('applies custom className', () => {
    const { container } = render(<Input className="custom-class" />);
    const inputElement = container.querySelector('input');
    expect(inputElement).toHaveClass('custom-class');
  });

  test('accepts standard input props like placeholder', () => {
    const { getByPlaceholderText } = render(<Input placeholder="Enter username" />);
    const inputElement = getByPlaceholderText('Enter username');
    expect(inputElement).toBeInTheDocument();
  });

  test('is disabled when disabled prop is true', () => {
    const { container } = render(<Input disabled />);
    const inputElement = container.querySelector('input');
    expect(inputElement).toBeDisabled();
  });

  test('renders with a specific type', () => {
    const { container } = render(<Input type="password" />);
    const inputElement = container.querySelector('input');
    expect(inputElement).toHaveAttribute('type', 'password');
  });

  test('forwards ref correctly', () => {
    const ref = React.createRef();
    render(<Input ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });
});

