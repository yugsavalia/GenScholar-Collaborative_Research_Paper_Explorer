import { describe, it, expect, vi, beforeEach } from 'vitest';
import { debounce, PerformanceTimer, createTimer } from '../utils/perf';

describe('utils/perf', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.spyOn(console, 'debug').mockImplementation(() => {});
    vi.spyOn(performance, 'now').mockReturnValue(1000);
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  describe('debounce', () => {
    it('should debounce function calls', () => {
      const fn = vi.fn();
      const debounced = debounce(fn, 100);

      debounced();
      debounced();
      debounced();

      expect(fn).not.toHaveBeenCalled();

      vi.advanceTimersByTime(100);
      expect(fn).toHaveBeenCalledTimes(1);
    });

    it('should pass arguments to debounced function', () => {
      const fn = vi.fn();
      const debounced = debounce(fn, 50);

      debounced('arg1', 'arg2');
      vi.advanceTimersByTime(50);

      expect(fn).toHaveBeenCalledWith('arg1', 'arg2');
    });

    it('should reset timer on subsequent calls', () => {
      const fn = vi.fn();
      const debounced = debounce(fn, 100);

      debounced();
      vi.advanceTimersByTime(50);
      debounced();
      vi.advanceTimersByTime(50);

      expect(fn).not.toHaveBeenCalled();

      vi.advanceTimersByTime(50);
      expect(fn).toHaveBeenCalledTimes(1);
    });

    it('should handle multiple invocations', () => {
      const fn = vi.fn();
      const debounced = debounce(fn, 100);

      debounced(1);
      vi.advanceTimersByTime(150);
      
      debounced(2);
      vi.advanceTimersByTime(150);

      expect(fn).toHaveBeenCalledTimes(2);
      expect(fn).toHaveBeenNthCalledWith(1, 1);
      expect(fn).toHaveBeenNthCalledWith(2, 2);
    });
  });

  describe('PerformanceTimer', () => {
    it('should create timer with label', () => {
      const timer = new PerformanceTimer('test');
      
      expect(timer.label).toBe('test');
      expect(timer.startTime).toBeDefined();
    });

    it('should mark events and log elapsed time', () => {
      const consoleSpy = vi.spyOn(console, 'debug');
      vi.spyOn(performance, 'now').mockReturnValueOnce(1000).mockReturnValueOnce(1250);
      
      const timer = new PerformanceTimer('test');
      const elapsed = timer.mark('event1');

      expect(elapsed).toBeCloseTo(250, 0);
      expect(consoleSpy).toHaveBeenCalledWith('[PERF:test] event1: 250.00ms');
    });

    it('should end timer and return total time', () => {
      const consoleSpy = vi.spyOn(console, 'debug');
      vi.spyOn(performance, 'now').mockReturnValueOnce(1000).mockReturnValueOnce(1500);
      
      const timer = new PerformanceTimer('test');
      const elapsed = timer.end();

      expect(elapsed).toBeCloseTo(500, 0);
      expect(consoleSpy).toHaveBeenCalledWith('[PERF:test] Total: 500.00ms');
    });

    it('should track multiple marks', () => {
      vi.spyOn(performance, 'now')
        .mockReturnValueOnce(1000) // constructor
        .mockReturnValueOnce(1100) // first mark
        .mockReturnValueOnce(1300); // second mark
      
      const timer = new PerformanceTimer('multi');
      const mark1 = timer.mark('step1');
      const mark2 = timer.mark('step2');

      expect(mark1).toBeCloseTo(100, 0);
      expect(mark2).toBeCloseTo(300, 0);
    });
  });

  describe('createTimer', () => {
    it('should create PerformanceTimer instance', () => {
      const timer = createTimer('my-timer');

      expect(timer).toBeInstanceOf(PerformanceTimer);
      expect(timer.label).toBe('my-timer');
    });

    it('should return timer with mark and end methods', () => {
      const timer = createTimer('test');

      expect(typeof timer.mark).toBe('function');
      expect(typeof timer.end).toBe('function');
    });
  });
});
