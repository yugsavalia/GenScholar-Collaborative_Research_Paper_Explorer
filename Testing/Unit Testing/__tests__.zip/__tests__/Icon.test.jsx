import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import Icon from '@/components/Icon';

describe('Icon component', () => {
  test('renders the search icon', () => {
    const { container } = render(<Icon name="search" />);
    const svgElement = container.querySelector('svg');
    expect(svgElement).toBeInTheDocument();
    expect(svgElement.querySelector('circle')).toBeInTheDocument();
  });

  test('renders the plus icon', () => {
    const { container } = render(<Icon name="plus" />);
    const svgElement = container.querySelector('svg');
    expect(svgElement).toBeInTheDocument();
    expect(svgElement.querySelectorAll('line').length).toBe(2);
  });

  test('renders with a custom size', () => {
    const { container } = render(<Icon name="upload" size={32} />);
    const svgElement = container.querySelector('svg');
    expect(svgElement).toHaveAttribute('width', '32');
    expect(svgElement).toHaveAttribute('height', '32');
  });

  test('applies a custom className', () => {
    const { container } = render(<Icon name="file" className="custom-icon" />);
    expect(container.firstChild).toHaveClass('custom-icon');
  });

  test('renders nothing if the icon name is invalid', () => {
    const { container } = render(<Icon name="invalid-icon-name" />);
    const span = container.querySelector('span');
    expect(span).toBeInTheDocument();
    expect(span).toBeEmptyDOMElement();
  });
});

