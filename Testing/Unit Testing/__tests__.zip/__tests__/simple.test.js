describe('Basic Test', () => {
  test('Two plus two equals four', () => {
    expect(2 + 2).toBe(4);
  });

  // --- Numeric Assertions ---

  test('floating point addition should be close enough', () => {
    // Jest warns against using toBe for floating point math due to precision issues.
    // Use toBeCloseTo instead.
    expect(0.1 + 0.2).toBeCloseTo(0.3);
  });

  test('subtraction result should be negative', () => {
    expect(5 - 10).toBeLessThan(0);
  });

  test('multiplication result should be positive', () => {
    expect(3 * 4).toBeGreaterThan(0);
  });

  test('division by zero should result in Infinity', () => {
    expect(10 / 0).toBe(Infinity);
  });

  // --- Boolean Assertions ---

  test('should return true when comparing two identical strings', () => {
    expect('hello' === 'hello').toBe(true);
    expect(1).toBeTruthy(); // Any defined non-zero value
  });

  test('should identify null and undefined values', () => {
    let x; // undefined
    expect(x).toBeUndefined();
    expect(null).toBeNull();
    expect(null).toBeFalsy(); // null, 0, false, and empty string are Falsy
  });

  // --- Object/Array Assertions ---

  test('should check for deep equality of objects', () => {
    const data = { a: 1, b: 2 };
    const expected = { a: 1, b: 2 };
    // For comparing object contents (deep equality), use toEqual, not toBe (which checks reference)
    expect(data).toEqual(expected);
  });

  test('should check if an array contains a specific element', () => {
    const list = ['apple', 'banana', 'cherry'];
    expect(list).toContain('banana');
  });

  test('should check the length of an array', () => {
    const numbers = [1, 2, 3];
    expect(numbers).toHaveLength(3);
  });

  // --- String Assertions ---

  test('should check if a string matches a regular expression', () => {
    expect('Jest Testing').toMatch(/Jest/);
  });
});

// Mocking API calls for login
const mockLoginApi = (email, password) => {
  return new Promise((resolve, reject) => {
    if (email === 'test@example.com' && password === 'password') {
      resolve({ success: true, message: 'Login successful' });
    } else {
      reject({ success: false, message: 'Invalid credentials' });
    }
  });
};

describe('Login Page', () => {
  test('should log in successfully with valid credentials', async () => {
    const response = await mockLoginApi('test@example.com', 'password');
    expect(response.success).toBe(true);
  });

  test('should fail to log in with invalid credentials', async () => {
    try {
      await mockLoginApi('wrong@example.com', 'wrongpassword');
    } catch (error) {
      expect(error.success).toBe(false);
    }
  });
});

// Mocking API calls for signup
const mockSignupApi = (email, password) => {
  return new Promise((resolve) => {
    resolve({ success: true, message: 'Signup successful' });
  });
};

describe('Signup Page', () => {
  test('should sign up successfully with valid data', async () => {
    const response = await mockSignupApi('newuser@example.com', 'newpassword');
    expect(response.success).toBe(true);
  });
});

// Mocking WebSocket connection
class MockWebSocket {
  constructor(url) {
    this.url = url;
    this.readyState = 1; // OPEN
  }

  send(data) {
    // Mock sending data
  }

  close() {
    this.readyState = 3; // CLOSED
  }
}

describe('WebSocket Connection', () => {
  test('should establish a WebSocket connection', () => {
    const ws = new MockWebSocket('ws://localhost:8000/ws/chat/');
    expect(ws.readyState).toBe(1);
  });

  test('should close a WebSocket connection', () => {
    const ws = new MockWebSocket('ws://localhost:8000/ws/chat/');
    ws.close();
    expect(ws.readyState).toBe(3);
  });
});

// Mocking chatbot response
const mockChatbotApi = (message) => {
  return new Promise((resolve) => {
    resolve({ response: `You said: ${message}` });
  });
};

describe('Chatbot', () => {
  test('should get a response from the chatbot', async () => {
    const response = await mockChatbotApi('Hello');
    expect(response.response).toBe('You said: Hello');
  });
});
