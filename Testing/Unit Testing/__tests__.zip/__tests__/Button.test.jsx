import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Button } from '@/components/ui/button';
import { vi } from 'vitest';

describe('Button component', () => {
  test('renders with default props', () => {
    const { getByText } = render(<Button>Click me</Button>);
    const buttonElement = getByText('Click me');
    expect(buttonElement).toBeInTheDocument();
    expect(buttonElement).toHaveClass('bg-primary');
  });

  test('renders with secondary variant', () => {
    const { getByText } = render(<Button variant="secondary">Click me</Button>);
    const buttonElement = getByText('Click me');
    expect(buttonElement).toHaveClass('bg-secondary');
  });

  test('renders with destructive variant', () => {
    const { getByText } = render(<Button variant="destructive">Click me</Button>);
    const buttonElement = getByText('Click me');
    expect(buttonElement).toHaveClass('bg-destructive');
  });

  test('handles onClick event', () => {
    const handleClick = vi.fn();
    const { getByText } = render(<Button onClick={handleClick}>Click me</Button>);
    const buttonElement = getByText('Click me');
    fireEvent.click(buttonElement);
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  test('applies custom className', () => {
    const { getByText } = render(<Button className="custom-class">Click me</Button>);
    const buttonElement = getByText('Click me');
    expect(buttonElement).toHaveClass('custom-class');
  });

  test('is disabled when disabled prop is true', () => {
    const { getByText } = render(<Button disabled>Click me</Button>);
    const buttonElement = getByText('Click me');
    expect(buttonElement).toBeDisabled();
  });
});

