import { vi } from 'vitest';

// Mock the client module BEFORE importing workspaces
const apiGet = vi.fn();
const apiPost = vi.fn();
const apiDelete = vi.fn();
const apiPatch = vi.fn();

vi.mock('@/api/client', () => ({
  apiGet,
  apiPost,
  apiDelete,
  apiPatch,
}));

// Now import after mocking
const { 
  getWorkspaces, 
  createWorkspace, 
  deleteWorkspace,
  getWorkspaceMembers,
  inviteUserToWorkspace,
  updateMemberRole 
} = await import('@/api/workspaces');

describe('api/workspaces - Comprehensive Coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getWorkspaces', () => {
    it('should handle array response', async () => {
      const mockWorkspaces = [
        { id: 1, name: 'Workspace 1' },
        { id: 2, name: 'Workspace 2' }
      ];
      apiGet.mockResolvedValue({ data: { workspaces: mockWorkspaces } });

      const result = await getWorkspaces();

      expect(apiGet).toHaveBeenCalledWith('/api/workspaces/');
      expect(result).toEqual(mockWorkspaces);
    });

    it('should handle paginated response', async () => {
      const mockWorkspaces = [
        { id: 1, name: 'Workspace 1' },
        { id: 2, name: 'Workspace 2' }
      ];
      apiGet.mockResolvedValue({ data: { workspaces: mockWorkspaces } });

      const result = await getWorkspaces();

      expect(result).toEqual(mockWorkspaces);
    });

    it('should handle empty results', async () => {
      apiGet.mockResolvedValue({ data: { workspaces: [] } });

      const result = await getWorkspaces();

      expect(result).toEqual([]);
    });
  });

  describe('createWorkspace', () => {
    it('should create workspace with name', async () => {
      const mockWorkspace = { id: 1, name: 'New Workspace' };
      apiPost.mockResolvedValue({ data: { workspace: mockWorkspace } });

      const result = await createWorkspace('New Workspace');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/', { name: 'New Workspace' });
      expect(result).toEqual(mockWorkspace);
    });

    it('should handle creation errors', async () => {
      apiPost.mockRejectedValue(new Error('Creation failed'));

      await expect(createWorkspace('Test')).rejects.toThrow('Creation failed');
    });
  });

  describe('deleteWorkspace', () => {
    it('should delete workspace by id', async () => {
      apiDelete.mockResolvedValue({ success: true, message: 'Workspace deleted' });

      await deleteWorkspace('123');

      expect(apiDelete).toHaveBeenCalledWith('/api/workspaces/123/');
    });

    it('should handle numeric ids', async () => {
      apiDelete.mockResolvedValue({ success: true, message: 'Workspace deleted' });

      await deleteWorkspace(456);

      expect(apiDelete).toHaveBeenCalledWith('/api/workspaces/456/');
    });
  });

  describe('getWorkspaceMembers', () => {
    it('should fetch workspace members', async () => {
      const mockMembers = [
        { id: 1, user: { id: 1, username: 'user1' }, role: 'creator' },
        { id: 2, user: { id: 2, username: 'user2' }, role: 'editor' }
      ];
      apiGet.mockResolvedValue({ data: { members: mockMembers } });

      const result = await getWorkspaceMembers('ws1');

      expect(apiGet).toHaveBeenCalledWith('/api/workspaces/ws1/members/');
      expect(result).toEqual(mockMembers);
    });

    it('should handle empty members list', async () => {
      apiGet.mockResolvedValue({ data: { members: [] } });

      const result = await getWorkspaceMembers('ws1');

      expect(result).toEqual([]);
    });
  });

  describe('inviteUserToWorkspace', () => {
    it('should invite user with role', async () => {
      const mockResponse = { success: true };
      apiPost.mockResolvedValue(mockResponse);

      const result = await inviteUserToWorkspace('ws1', 'user2', 'EDITOR');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/ws1/invite/', {
        username: 'user2',
        role: 'EDITOR'
      });
      expect(result).toEqual(mockResponse);
    });

    it('should default to RESEARCHER role', async () => {
      const mockResponse = { success: true };
      apiPost.mockResolvedValue(mockResponse);

      await inviteUserToWorkspace('ws1', 'user2');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/ws1/invite/', {
        username: 'user2',
        role: 'RESEARCHER'
      });
    });
  });

  describe('updateMemberRole', () => {
    it('should update member role', async () => {
      const mockMember = { id: 1, role: 'editor' };
      apiPatch.mockResolvedValue({ data: { member: mockMember } });

      const result = await updateMemberRole('ws1', 'member1', 'editor');

      expect(apiPatch).toHaveBeenCalledWith('/api/workspaces/ws1/members/member1/', {
        role: 'editor'
      });
      expect(result).toEqual(mockMember);
    });

    it('should handle role update errors', async () => {
      apiPatch.mockRejectedValue(new Error('Insufficient permissions'));

      await expect(updateMemberRole('ws1', 'member1', 'creator')).rejects.toThrow('Insufficient permissions');
    });
  });
});
