import { vi } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';

import ThreadPanel from '@/components/ThreadPanel';

import { storage } from '@/utils/storage';

import { STORAGE_KEYS } from '@/utils/constants';

import { generateId } from '@/utils/ids';


vi.mock('@/utils/storage', () => ({
  storage: {
    get: vi.fn(),
    set: vi.fn(),
  },
}));

vi.mock('@/utils/ids', () => ({
  generateId: vi.fn(),
}));

describe('ThreadPanel', () => {
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';
  const selectedAnnotation = { id: 'anno1', text: 'Test annotation' };

  beforeEach(() => {
    storage.get.mockClear();
    storage.set.mockClear();
    generateId.mockClear();
    // Mock scrollIntoView for all tests
    window.HTMLElement.prototype.scrollIntoView = vi.fn();
  });

  it('should show a message when no annotation is selected', () => {
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={null} />);
    expect(screen.getByText('Select text in the PDF to start a threaded discussion')).toBeInTheDocument();
  });

  it('should load threads from storage on mount', () => {
    const threads = [{ id: 't1', author: 'me', content: 'a test message' }];
    storage.get.mockReturnValue(threads);
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);
    expect(storage.get).toHaveBeenCalledWith(STORAGE_KEYS.THREADS(workspaceId, pdfId, selectedAnnotation.id));
    expect(screen.getByText('a test message')).toBeInTheDocument();
  });

  it('should add a new message', async () => {
    storage.get.mockReturnValue([]);
    generateId.mockReturnValue('new-id');
    
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);

    const input = screen.getByPlaceholderText('Reply to thread...');
    const form = input.closest('form');

    await act(async () => {
      fireEvent.change(input, { target: { value: 'new message' } });
    });
    
    await act(async () => {
      fireEvent.submit(form);
    });

    expect(screen.getByText('new message')).toBeInTheDocument();

    const expectedThreads = [{
      id: 'new-id',
      author: 'me',
      content: 'new message',
      createdAt: expect.any(String)
    }];
    expect(storage.set).toHaveBeenCalledWith(
      STORAGE_KEYS.THREADS(workspaceId, pdfId, selectedAnnotation.id),
      expectedThreads
    );
  });

  it('should not add an empty message', async () => {
    storage.get.mockReturnValue([]);
    
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);

    const input = screen.getByPlaceholderText('Reply to thread...');
    const form = input.closest('form');

    await act(async () => {
      fireEvent.change(input, { target: { value: '  ' } });
    });
    
    await act(async () => {
      fireEvent.submit(form);
    });

    expect(storage.set).not.toHaveBeenCalled();
  });
});

