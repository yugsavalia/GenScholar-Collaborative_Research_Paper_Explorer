import { describe, it, expect } from 'vitest';
import { createAccountSchema } from '../utils/validators';

describe('validators.js - Regex Anchor Mutations (Kill remaining 4 mutants)', () => {
  describe('Email validation regex anchor mutations', () => {
    /**
     * KILL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
     *    → /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/  (remove ^)
     *    → /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/  (remove $)
     * 
     * Without anchors, these would match:
     * - "invalid@test.com\n" (trailing newline)
     * - "  test@test.com  " (spaces)
     * - "prefix_test@test.com_suffix" (extra chars)
     */

    it('should reject email with trailing characters after domain', async () => {
      // Without $, this would match because regex finds valid email in the string
      const data = {
        username: 'user',
        email: 'test@example.com_INVALID',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should reject email with leading characters before local part', async () => {
      // Without ^, this would match because regex finds valid email in the string
      // Note: Yup's .email() validator is more permissive than our regex
      // The regex anchor ^ is critical to prevent "text before email"
      const data = {
        username: 'user',
        email: 'mailto:test@example.com', // Protocol prefix should be rejected
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should reject email with trailing newline', async () => {
      // Without $, "test@test.com\n" would match
      const data = {
        username: 'user',
        email: 'test@example.com\n',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should reject email with leading spaces', async () => {
      // Without ^, "  test@test.com" would match
      const data = {
        username: 'user',
        email: '  test@example.com',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should reject email with trailing spaces', async () => {
      // Without $, "test@test.com  " would match
      const data = {
        username: 'user',
        email: 'test@example.com  ',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should reject email embedded in larger string', async () => {
      // Without anchors, "prefix test@test.com suffix" would match
      const data = {
        username: 'user',
        email: 'Contact us at test@example.com for help',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow();
    });

    it('should accept clean valid email (baseline)', async () => {
      // This should pass with or without anchors
      const data = {
        username: 'user',
        email: 'test@example.com',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
    });
  });

  describe('Error message string literal mutations', () => {
    /**
     * KILL: .required('Password is required') → .required("")
     * KILL: .oneOf([Yup.ref('password')], 'Passwords must match') → .oneOf([Yup.ref("")], ...)
     */

    it('should show specific error message when password is missing', async () => {
      // This test verifies the .required('Password is required') mutation
      // where 'Password is required' → ""
      
      // When password is completely missing, Yup throws "Password is required"
      const data = {
        username: 'user',
        email: 'test@example.com',
        confirm_password: 'something' // Add confirm so it validates
      };
      // Don't include password field at all
      
      try {
        await createAccountSchema.validate(data);
        expect.fail('Should have thrown validation error');
      } catch (error) {
        // The specific error message matters for user experience
        // If mutated to .required(""), error message would be less helpful
        expect(error.message).toBeTruthy();
        expect(error.message.length).toBeGreaterThan(0);
      }
    });

    it('should show specific error message when passwords do not match', async () => {
      const data = {
        username: 'user',
        email: 'test@example.com',
        password: 'password123',
        confirm_password: 'different456'
      };
      
      try {
        await createAccountSchema.validate(data);
        expect.fail('Should have thrown validation error');
      } catch (error) {
        // Verify the error message contains "Passwords must match"
        // If mutated to "", the error would be generic or empty
        expect(error.message).toContain('Passwords must match');
        expect(error.message).not.toBe('');
      }
    });

    it('should verify password field reference in oneOf is correct', async () => {
      // If Yup.ref('password') → Yup.ref(""), it would compare against wrong field
      const data = {
        username: 'user',
        email: 'test@example.com',
        password: 'password123',
        confirm_password: 'password123'
      };
      
      // This should pass because passwords match
      await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      
      // Now test they must actually match
      const data2 = {
        ...data,
        confirm_password: 'different'
      };
      
      await expect(createAccountSchema.validate(data2)).rejects.toThrow('Passwords must match');
    });
  });
});
