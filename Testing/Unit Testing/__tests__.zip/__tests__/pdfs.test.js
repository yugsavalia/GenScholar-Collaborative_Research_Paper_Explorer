import { vi } from 'vitest';
import { getPdfs, uploadPdf, getPdfUrl, deletePdf } from '@/api/pdfs';

import { getCsrfToken } from '@/utils/csrf';

import { API_BASE_URL } from '@/api/config';


// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Mock config module
vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

describe('api/pdfs', () => {
  const csrfToken = 'test-csrf-token';
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  // --- getPdfs ---
  describe('getPdfs', () => {
    it('should fetch and return a list of PDFs', async () => {
      const mockPdfs = [{ id: 'pdf1', title: 'Test PDF' }];
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockPdfs),
      });

      const result = await getPdfs(workspaceId);

      expect(mockFetch).toHaveBeenCalledWith(`${API_BASE_URL}/api/pdfs/?workspace=${workspaceId}`, expect.any(Object));
      expect(result).toEqual(mockPdfs);
    });

    it('should handle paginated response from DRF', async () => {
        const mockPdfs = [{ id: 'pdf1', title: 'Test PDF' }];
        mockFetch.mockResolvedValue({
          ok: true,
          json: () => Promise.resolve({ count: 1, next: null, previous: null, results: mockPdfs }),
        });
  
        const result = await getPdfs(workspaceId);
        expect(result).toEqual(mockPdfs);
      });

    it('should throw an error if the fetch fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Server Error',
      });

      await expect(getPdfs(workspaceId)).rejects.toThrow('Failed to fetch PDFs: Server Error');
    });
  });

  // --- uploadPdf ---
  describe('uploadPdf', () => {
    it('should upload a file using FormData and return the new PDF object', async () => {
      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      const title = 'My Test PDF';
      const mockResponse = { id: 'new-pdf', title };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await uploadPdf(workspaceId, file, title);

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}/api/pdfs/`,
        expect.objectContaining({
          method: 'POST',
          headers: { 'X-CSRFToken': csrfToken },
          body: expect.any(FormData),
        })
      );
      
      // Check if FormData contains the correct fields
      const formData = mockFetch.mock.calls[0][1].body;
      expect(formData.get('file')).toEqual(file);
      expect(formData.get('title')).toEqual(title);
      expect(formData.get('workspace')).toEqual(workspaceId);

      expect(result).toEqual(mockResponse);
    });

    it('should throw an error on upload failure', async () => {
        mockFetch.mockResolvedValue({
          ok: false,
          status: 400,
          statusText: 'Bad Request',
          json: () => Promise.resolve({ error: 'Invalid file' }),
        });
  
        await expect(uploadPdf(workspaceId, new File([], ''), 'title')).rejects.toThrow('Invalid file');
      });
  });

  // --- getPdfUrl ---
  describe('getPdfUrl', () => {
    it('should fetch PDF bytes and return a blob URL', async () => {
      const mockBlob = new Blob(['pdf-content'], { type: 'application/pdf' });
      const mockBlobUrl = 'blob:http://localhost/some-uuid';
      global.URL.createObjectURL = vi.fn(() => mockBlobUrl); // Mock blob URL creation

      mockFetch.mockResolvedValue({
        ok: true,
        blob: () => Promise.resolve(mockBlob),
      });

      const result = await getPdfUrl(pdfId);

      expect(mockFetch).toHaveBeenCalledWith(`${API_BASE_URL}/api/pdfs/${pdfId}/file/`, expect.any(Object));
      expect(global.URL.createObjectURL).toHaveBeenCalledWith(mockBlob);
      expect(result).toBe(mockBlobUrl);
    });
  });

  // --- deletePdf ---
  describe('deletePdf', () => {
    it('should send a DELETE request', async () => {
        mockFetch.mockResolvedValue({
            ok: true,
            json: () => Promise.resolve({ success: true }),
        });

        await deletePdf(pdfId);

        expect(getCsrfToken).toHaveBeenCalledTimes(1);
        expect(mockFetch).toHaveBeenCalledWith(
            `${API_BASE_URL}/api/pdfs/${pdfId}/`,
            {
                method: 'DELETE',
                headers: { 'X-CSRFToken': csrfToken, "Content-Type": "application/json" },
                credentials: 'include'
            }
        );
    });
  });
});


