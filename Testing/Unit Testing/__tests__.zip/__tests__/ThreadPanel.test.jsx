import { vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';

import ThreadPanel from '@/components/ThreadPanel';

import { storage } from '@/utils/storage';

import { STORAGE_KEYS } from '@/utils/constants';


vi.mock('@/utils/storage', () => ({
  storage: {
    get: vi.fn(),
    set: vi.fn(),
  },
}));

vi.mock('@/utils/ids', () => ({
  generateId: vi.fn(() => 'test-id-123'),
}));

describe('components/ThreadPanel', () => {
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';
  const selectedAnnotation = {
    id: 'ann1',
    text: 'Selected text from PDF',
  };

  beforeEach(() => {
    vi.clearAllMocks();
    storage.get.mockReturnValue([]);
  });

  it('should show placeholder when no annotation is selected', () => {
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={null} />);
    
    expect(screen.getByText(/Select text in the PDF to start a threaded discussion/i)).toBeInTheDocument();
  });

  it('should show placeholder when pdfId is missing', () => {
    render(<ThreadPanel workspaceId={workspaceId} pdfId={null} selectedAnnotation={selectedAnnotation} />);
    
    expect(screen.getByText(/Select text in the PDF to start a threaded discussion/i)).toBeInTheDocument();
  });

  it('should load threads from storage when annotation is selected', () => {
    const existingThreads = [
      { id: '1', author: 'me', content: 'Test message', createdAt: '2024-01-01T00:00:00Z' },
    ];
    storage.get.mockReturnValue(existingThreads);

    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);

    const key = STORAGE_KEYS.THREADS(workspaceId, pdfId, selectedAnnotation.id);
    expect(storage.get).toHaveBeenCalledWith(key);
  });

  it('should render ThreadItem when annotation is selected', () => {
    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);
    
    // ThreadItem should be rendered (we can't test exact content without knowing ThreadItem's implementation)
    expect(screen.queryByText(/Select text in the PDF/i)).not.toBeInTheDocument();
  });

  it('should handle empty threads from storage', () => {
    storage.get.mockReturnValue(null);

    render(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />);

    const key = STORAGE_KEYS.THREADS(workspaceId, pdfId, selectedAnnotation.id);
    expect(storage.get).toHaveBeenCalledWith(key);
  });

  it('should update when selectedAnnotation changes', async () => {
    const { rerender } = render(
      <ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={selectedAnnotation} />
    );

    const newAnnotation = {
      id: 'ann2',
      text: 'Different selected text',
    };

    rerender(<ThreadPanel workspaceId={workspaceId} pdfId={pdfId} selectedAnnotation={newAnnotation} />);

    await waitFor(() => {
      const newKey = STORAGE_KEYS.THREADS(workspaceId, pdfId, newAnnotation.id);
      expect(storage.get).toHaveBeenCalledWith(newKey);
    });
  });
});


