import { vi } from 'vitest';
import { apiRequest, apiGet, apiPost, apiPut, apiPatch, apiDelete } from '@/api/client';

import { getCsrfToken } from '@/utils/csrf';


vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000',
}));

const mockFetch = vi.fn();
global.fetch = mockFetch;

describe('api/client - Extended Coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue('csrf-token');
  });

  describe('Network Errors', () => {
    it('should handle network errors in apiRequest', async () => {
      mockFetch.mockRejectedValue(new Error('Network failure'));

      await expect(apiGet('/test')).rejects.toThrow('API request failed: Network failure');
    });

    it('should handle fetch errors without status', async () => {
      const networkError = new Error('Failed to fetch');
      mockFetch.mockRejectedValue(networkError);

      await expect(apiPost('/test', { data: 'test' })).rejects.toThrow('API request failed: Failed to fetch');
    });

    it('should rethrow errors that already have status', async () => {
      const customError = new Error('Custom error');
      customError.status = 500;
      mockFetch.mockRejectedValue(customError);

      await expect(apiGet('/test')).rejects.toThrow(customError);
    });
  });

  describe('Error Responses', () => {
    it('should handle error response with message field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({ message: 'Invalid data' }),
      });

      try {
        await apiPost('/test', { data: 'test' });
        fail('Should have thrown');
      } catch (error) {
        expect(error.message).toBe('Invalid data');
        expect(error.status).toBe(400);
      }
    });

    it('should handle error response with success=false', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        status: 200,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({ success: false, message: 'Operation failed' }),
      });

      try {
        await apiGet('/test');
        fail('Should have thrown');
      } catch (error) {
        expect(error.message).toBe('Operation failed');
      }
    });

    it('should use statusText when no error message provided', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({}),
      });

      try {
        await apiGet('/test');
        fail('Should have thrown');
      } catch (error) {
        expect(error.message).toBe('Internal Server Error');
        expect(error.status).toBe(500);
      }
    });
  });

  describe('HTTP Methods', () => {
    it('should make PUT request correctly', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({ success: true }),
      });

      await apiPut('/test', { data: 'updated' });

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:8000/test',
        expect.objectContaining({
          method: 'PUT',
          body: JSON.stringify({ data: 'updated' }),
        })
      );
    });

    it('should make PATCH request correctly', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({ success: true }),
      });

      await apiPatch('/test', { data: 'patched' });

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:8000/test',
        expect.objectContaining({
          method: 'PATCH',
          body: JSON.stringify({ data: 'patched' }),
        })
      );
    });

    it('should make DELETE request correctly', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
        headers: { get: vi.fn().mockReturnValue('application/json') },
        json: () => Promise.resolve({ success: true }),
      });

      await apiDelete('/test');

      expect(mockFetch).toHaveBeenCalledWith(
        'http://localhost:8000/test',
        expect.objectContaining({
          method: 'DELETE',
        })
      );
      expect(getCsrfToken).toHaveBeenCalled();
    });
  });
});


