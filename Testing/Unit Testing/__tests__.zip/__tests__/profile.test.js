import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getProfile } from '../api/profile';
import * as client from '../api/client';

vi.mock('../api/client');

describe('api/profile', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getProfile', () => {
    it('should fetch user profile', async () => {
      const mockProfile = { username: 'test', email: 'test@example.com', stats: {} };
      vi.mocked(client.apiGet).mockResolvedValue({ data: { profile: mockProfile } });

      const result = await getProfile();

      expect(client.apiGet).toHaveBeenCalledWith('/api/profile/me/');
      expect(result).toEqual(mockProfile);
    });

    it('should extract profile from response', async () => {
      const profile = { username: 'user', stats: { workspaces: 5 } };
      vi.mocked(client.apiGet).mockResolvedValue({ 
        success: true,
        data: { profile }
      });

      const result = await getProfile();

      expect(result).toEqual(profile);
    });
  });
});
