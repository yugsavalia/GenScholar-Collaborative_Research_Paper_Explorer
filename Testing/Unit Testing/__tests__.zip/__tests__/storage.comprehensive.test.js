import { describe, test, expect, beforeEach, vi } from 'vitest';
import { storage } from '@/utils/storage';

describe('storage utilities comprehensive coverage', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  describe('get', () => {
    test('should get value from localStorage', () => {
      localStorage.setItem('test', JSON.stringify({ value: 'data' }));
      const result = storage.get('test');
      expect(result).toEqual({ value: 'data' });
    });

    test('should return null for non-existent key', () => {
      const result = storage.get('nonexistent');
      expect(result).toBeNull();
    });

    test('should handle JSON parse errors', () => {
      localStorage.setItem('invalid', 'not-valid-json{');
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      const result = storage.get('invalid');
      
      expect(result).toBeNull();
      expect(consoleSpy).toHaveBeenCalled();
      consoleSpy.mockRestore();
    });

    test('should handle localStorage errors', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const getItemSpy = vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
        throw new Error('Storage error');
      });
      
      const result = storage.get('test');
      
      expect(result).toBeNull();
      expect(consoleSpy).toHaveBeenCalled();
      
      consoleSpy.mockRestore();
      getItemSpy.mockRestore();
    });
  });

  describe('set', () => {
    test('should set value in localStorage', () => {
      storage.set('test', { value: 'data' });
      const stored = localStorage.getItem('test');
      expect(JSON.parse(stored)).toEqual({ value: 'data' });
    });

    test('should handle numbers', () => {
      storage.set('number', 42);
      expect(storage.get('number')).toBe(42);
    });

    test('should handle arrays', () => {
      const arr = [1, 2, 3];
      storage.set('array', arr);
      expect(storage.get('array')).toEqual(arr);
    });

    test('should handle localStorage errors', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const setItemSpy = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
        throw new Error('Storage full');
      });
      
      storage.set('test', 'data');
      
      expect(consoleSpy).toHaveBeenCalled();
      
      consoleSpy.mockRestore();
      setItemSpy.mockRestore();
    });
  });

  describe('remove', () => {
    test('should remove value from localStorage', () => {
      localStorage.setItem('test', 'value');
      storage.remove('test');
      expect(localStorage.getItem('test')).toBeNull();
    });

    test('should handle removing non-existent key', () => {
      expect(() => storage.remove('nonexistent')).not.toThrow();
    });

    test('should handle localStorage errors', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const removeItemSpy = vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => {
        throw new Error('Storage error');
      });
      
      storage.remove('test');
      
      expect(consoleSpy).toHaveBeenCalled();
      
      consoleSpy.mockRestore();
      removeItemSpy.mockRestore();
    });
  });

  describe('clear', () => {
    test('should clear all localStorage', () => {
      localStorage.setItem('key1', 'value1');
      localStorage.setItem('key2', 'value2');
      
      storage.clear();
      
      expect(localStorage.length).toBe(0);
    });

    test('should handle localStorage errors', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const clearSpy = vi.spyOn(Storage.prototype, 'clear').mockImplementation(() => {
        throw new Error('Storage error');
      });
      
      storage.clear();
      
      expect(consoleSpy).toHaveBeenCalled();
      
      consoleSpy.mockRestore();
      clearSpy.mockRestore();
    });
  });

  describe('integration tests', () => {
    test('should handle multiple operations', () => {
      storage.set('user', { id: 1, name: 'John' });
      storage.set('settings', { theme: 'dark' });
      
      expect(storage.get('user')).toEqual({ id: 1, name: 'John' });
      expect(storage.get('settings')).toEqual({ theme: 'dark' });
      
      storage.remove('user');
      expect(storage.get('user')).toBeNull();
      expect(storage.get('settings')).toEqual({ theme: 'dark' });
      
      storage.clear();
      expect(storage.get('settings')).toBeNull();
    });
  });
});
