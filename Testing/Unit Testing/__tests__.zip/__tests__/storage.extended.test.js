import { storage } from '@/utils/storage';


import { vi } from 'vitest';
describe('utils/storage - Extended Coverage', () => {
  let localStorageMock;

  beforeEach(() => {
    localStorageMock = (() => {
      let store = {};
      return {
        getItem: vi.fn((key) => store[key] || null),
        setItem: vi.fn((key, value) => {
          store[key] = value.toString();
        }),
        removeItem: vi.fn((key) => {
          delete store[key];
        }),
        clear: () => {
          store = {};
        },
      };
    })();
    Object.defineProperty(window, 'localStorage', { value: localStorageMock });
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    console.error.mockRestore();
  });

  describe('Error Handling', () => {
    it('should handle errors when getting item from localStorage', () => {
      const testKey = 'testKey';
      localStorageMock.getItem.mockImplementation(() => {
        throw new Error('Storage error');
      });

      const result = storage.get(testKey);
      expect(result).toBeNull();
      expect(console.error).toHaveBeenCalledWith(
        'Error reading from localStorage:',
        expect.any(Error)
      );
    });

    it('should handle errors when setting item in localStorage', () => {
      const testKey = 'testKey';
      const testValue = { data: 'testValue' };
      localStorageMock.setItem.mockImplementation(() => {
        throw new Error('Storage error');
      });

      storage.set(testKey, testValue);
      expect(console.error).toHaveBeenCalledWith(
        'Error writing to localStorage:',
        expect.any(Error)
      );
    });

    it('should handle errors when removing item from localStorage', () => {
      const testKey = 'testKey';
      localStorageMock.removeItem.mockImplementation(() => {
        throw new Error('Storage error');
      });

      storage.remove(testKey);
      expect(console.error).toHaveBeenCalledWith(
        'Error removing from localStorage:',
        expect.any(Error)
      );
    });
  });
});


