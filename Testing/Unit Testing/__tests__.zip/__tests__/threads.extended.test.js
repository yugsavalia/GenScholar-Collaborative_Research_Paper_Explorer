import { vi } from 'vitest';
import { getThreads, createThread, getThread, addMessage, deleteThread } from '@/api/threads';

import { getCsrfToken } from '@/utils/csrf';

import { API_BASE_URL } from '@/api/config';


// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Mock config module
vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

describe('api/threads - Extended Coverage', () => {
  const csrfToken = 'test-csrf-token';
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';
  const threadId = 'thread1';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  // --- getThreads Error Cases ---
  describe('getThreads - Error Handling', () => {
    it('should throw an error when fetch fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Not Found',
      });

      await expect(getThreads(workspaceId, pdfId)).rejects.toThrow('Failed to fetch threads: Not Found');
    });
  });

  // --- createThread Error Cases ---
  describe('createThread - Error Handling', () => {
    it('should throw an error when fetch fails with detail', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ detail: 'Invalid workspace' }),
      });

      const threadData = {
        page_number: 1,
        selection_text: 'Test',
        anchor_rect: {},
      };

      await expect(createThread(workspaceId, pdfId, threadData)).rejects.toThrow('Invalid workspace');
    });

    it('should throw an error when fetch fails with message', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ message: 'Validation error' }),
      });

      const threadData = {
        page_number: 1,
        selection_text: 'Test',
        anchor_rect: {},
      };

      await expect(createThread(workspaceId, pdfId, threadData)).rejects.toThrow('Validation error');
    });

    it('should throw a default error when fetch fails without detail or message', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Bad Request',
        json: () => Promise.resolve({}),
      });

      const threadData = {
        page_number: 1,
        selection_text: 'Test',
        anchor_rect: {},
      };

      await expect(createThread(workspaceId, pdfId, threadData)).rejects.toThrow('Failed to create thread: Bad Request');
    });

    it('should throw a default error when json parsing fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Internal Server Error',
        json: () => Promise.reject(new Error('Parse error')),
      });

      const threadData = {
        page_number: 1,
        selection_text: 'Test',
        anchor_rect: {},
      };

      await expect(createThread(workspaceId, pdfId, threadData)).rejects.toThrow('Failed to create thread: Internal Server Error');
    });
  });

  // --- getThread Error Cases ---
  describe('getThread - Error Handling', () => {
    it('should throw an error when fetch fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Not Found',
      });

      await expect(getThread(threadId)).rejects.toThrow('Failed to fetch thread: Not Found');
    });
  });

  // --- addMessage Error Cases ---
  describe('addMessage - Error Handling', () => {
    it('should throw an error when fetch fails with detail', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ detail: 'Thread locked' }),
      });

      await expect(addMessage(threadId, 'Test message')).rejects.toThrow('Thread locked');
    });

    it('should throw an error when fetch fails with message', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ message: 'Content required' }),
      });

      await expect(addMessage(threadId, 'Test message')).rejects.toThrow('Content required');
    });

    it('should throw a default error when fetch fails without detail or message', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Forbidden',
        json: () => Promise.resolve({}),
      });

      await expect(addMessage(threadId, 'Test message')).rejects.toThrow('Failed to add message: Forbidden');
    });

    it('should throw a default error when json parsing fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Internal Server Error',
        json: () => Promise.reject(new Error('Parse error')),
      });

      await expect(addMessage(threadId, 'Test message')).rejects.toThrow('Failed to add message: Internal Server Error');
    });
  });

  // --- deleteThread ---
  describe('deleteThread', () => {
    it('should successfully delete a thread', async () => {
      mockFetch.mockResolvedValue({
        ok: true,
      });

      await expect(deleteThread(threadId)).resolves.toBeUndefined();

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}/api/threads/${threadId}/`,
        expect.objectContaining({
          method: 'DELETE',
          headers: expect.objectContaining({
            'X-CSRFToken': csrfToken,
          }),
        })
      );
    });

    it('should throw an error when delete fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Forbidden',
      });

      await expect(deleteThread(threadId)).rejects.toThrow('Failed to delete thread: Forbidden');
    });
  });
});


