import { describe, it, expect, vi, beforeEach } from 'vitest';
import { loadPdf, getTextContent } from '../utils/pdf';
import * as pdfjsLib from 'pdfjs-dist';

vi.mock('pdfjs-dist', () => ({
  GlobalWorkerOptions: { workerSrc: '' },
  getDocument: vi.fn()
}));

vi.mock('react-pdf', () => ({
  pdfjs: {
    GlobalWorkerOptions: { workerSrc: '' }
  }
}));

describe('pdf utils', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('loadPdf', () => {
    it('should load PDF successfully', async () => {
      const mockPdf = { numPages: 10, getPage: vi.fn() };
      const mockLoadingTask = { promise: Promise.resolve(mockPdf) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);

      const result = await loadPdf('https://example.com/test.pdf');

      expect(pdfjsLib.getDocument).toHaveBeenCalledWith('https://example.com/test.pdf');
      expect(result).toEqual(mockPdf);
    });

    it('should handle blob URLs', async () => {
      const mockPdf = { numPages: 5, getPage: vi.fn() };
      const mockLoadingTask = { promise: Promise.resolve(mockPdf) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);

      const result = await loadPdf('blob:http://localhost:3000/abc123');

      expect(pdfjsLib.getDocument).toHaveBeenCalledWith('blob:http://localhost:3000/abc123');
      expect(result).toEqual(mockPdf);
    });

    it('should handle local file URLs', async () => {
      const mockPdf = { numPages: 3, getPage: vi.fn() };
      const mockLoadingTask = { promise: Promise.resolve(mockPdf) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);

      const result = await loadPdf('/pdfs/document.pdf');

      expect(pdfjsLib.getDocument).toHaveBeenCalledWith('/pdfs/document.pdf');
      expect(result).toEqual(mockPdf);
    });

    it('should throw error when PDF fails to load', async () => {
      const error = new Error('Failed to fetch PDF');
      const mockLoadingTask = { promise: Promise.reject(error) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      await expect(loadPdf('https://example.com/invalid.pdf')).rejects.toThrow('Failed to fetch PDF');

      expect(consoleErrorSpy).toHaveBeenCalledWith('Error loading PDF:', error);
      consoleErrorSpy.mockRestore();
    });

    it('should handle network errors', async () => {
      const error = new Error('Network error');
      const mockLoadingTask = { promise: Promise.reject(error) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      await expect(loadPdf('https://example.com/test.pdf')).rejects.toThrow('Network error');

      expect(consoleErrorSpy).toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });

    it('should handle invalid PDF format', async () => {
      const error = new Error('Invalid PDF structure');
      const mockLoadingTask = { promise: Promise.reject(error) };
      pdfjsLib.getDocument.mockReturnValue(mockLoadingTask);
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      await expect(loadPdf('https://example.com/corrupted.pdf')).rejects.toThrow('Invalid PDF structure');

      expect(consoleErrorSpy).toHaveBeenCalled();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('getTextContent', () => {
    it('should get text content from page', async () => {
      const mockTextContent = {
        items: [
          { str: 'Hello', transform: [1, 0, 0, 1, 0, 0] },
          { str: 'World', transform: [1, 0, 0, 1, 50, 0] }
        ]
      };
      const mockPage = {
        getTextContent: vi.fn().mockResolvedValue(mockTextContent)
      };

      const result = await getTextContent(mockPage);

      expect(mockPage.getTextContent).toHaveBeenCalled();
      expect(result).toEqual(mockTextContent);
    });

    it('should handle empty text content', async () => {
      const mockTextContent = { items: [] };
      const mockPage = {
        getTextContent: vi.fn().mockResolvedValue(mockTextContent)
      };

      const result = await getTextContent(mockPage);

      expect(result).toEqual(mockTextContent);
    });

    it('should return null on error', async () => {
      const mockPage = {
        getTextContent: vi.fn().mockRejectedValue(new Error('Text extraction failed'))
      };
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      const result = await getTextContent(mockPage);

      expect(result).toBeNull();
      expect(consoleErrorSpy).toHaveBeenCalledWith('Error getting text content:', expect.any(Error));
      consoleErrorSpy.mockRestore();
    });

    it('should handle pages without text', async () => {
      const mockTextContent = { items: [] };
      const mockPage = {
        getTextContent: vi.fn().mockResolvedValue(mockTextContent)
      };

      const result = await getTextContent(mockPage);

      expect(result).toEqual(mockTextContent);
      expect(result.items).toHaveLength(0);
    });

    it('should handle complex text content with styles', async () => {
      const mockTextContent = {
        items: [
          { str: 'Bold', transform: [1, 0, 0, 1, 0, 0], fontName: 'g_d0_f1' },
          { str: 'Normal', transform: [1, 0, 0, 1, 50, 0], fontName: 'g_d0_f2' }
        ],
        styles: {
          g_d0_f1: { fontFamily: 'Times-Bold' },
          g_d0_f2: { fontFamily: 'Times-Roman' }
        }
      };
      const mockPage = {
        getTextContent: vi.fn().mockResolvedValue(mockTextContent)
      };

      const result = await getTextContent(mockPage);

      expect(result).toEqual(mockTextContent);
      expect(result.styles).toBeDefined();
    });

    it('should handle text content extraction errors gracefully', async () => {
      const mockPage = {
        getTextContent: vi.fn().mockRejectedValue(new Error('Page rendering failed'))
      };
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      const result = await getTextContent(mockPage);

      expect(result).toBeNull();
      consoleErrorSpy.mockRestore();
    });
  });

  describe('worker URL configuration', () => {
    // Kill mutant: StringLiteral empty worker URL
    it('should set worker URL to non-empty string', () => {
      // Worker URL should be set to a valid path, not empty string
      expect(pdfjsLib.GlobalWorkerOptions.workerSrc).toBeTruthy();
      expect(pdfjsLib.GlobalWorkerOptions.workerSrc).not.toBe('');
      expect(typeof pdfjsLib.GlobalWorkerOptions.workerSrc).toBe('string');
    });

    it('should configure worker with valid URL path', () => {
      // Verify the worker URL contains expected path
      const workerSrc = pdfjsLib.GlobalWorkerOptions.workerSrc;
      expect(workerSrc).toContain('pdf.worker');
    });
  });
});
