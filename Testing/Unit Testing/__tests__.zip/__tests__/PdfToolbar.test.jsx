import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import '@testing-library/jest-dom';

import PdfToolbar from '@/components/PdfToolbar';

import { ANNOTATION_TYPES } from '@/utils/constants';


// Mock the Icon component
vi.mock('../Icon', () => ({ name, size }) => <i data-testid={`icon-${name}`} style={{ fontSize: size }} />);

describe('PdfToolbar', () => {
  const mockOnModeChange = vi.fn();

  beforeEach(() => {
    mockOnModeChange.mockClear();
  });

  it('should render all toolbar buttons', () => {
    const { container } = render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} />);

    expect(screen.getByTestId('button-tool-select')).toBeInTheDocument();
    expect(screen.getByText('Select')).toBeInTheDocument();
    expect(container.querySelector('svg')).toBeInTheDocument();

    expect(screen.getByTestId('button-tool-highlight')).toBeInTheDocument();
    expect(screen.getByText('Highlight')).toBeInTheDocument();

    expect(screen.getByTestId('button-tool-underline')).toBeInTheDocument();
    expect(screen.getByText('Underline')).toBeInTheDocument();
  });

  it('should highlight the active tool button', () => {
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.HIGHLIGHT} onModeChange={mockOnModeChange} />);

    const selectButton = screen.getByTestId('button-tool-select');
    const highlightButton = screen.getByTestId('button-tool-highlight');

    // Active button should have inline style for accent color
    expect(highlightButton).toHaveStyle({ background: 'var(--accent-color)', color: '#ffffff' });
    // Inactive button should have different styling
    expect(selectButton).toHaveStyle({ background: 'var(--hover-bg)' });
  });

  it('should call onModeChange with the correct tool name when a button is clicked', () => {
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} />);

    const underlineButton = screen.getByTestId('button-tool-underline');
    fireEvent.click(underlineButton);

    expect(mockOnModeChange).toHaveBeenCalledTimes(1);
    expect(mockOnModeChange).toHaveBeenCalledWith(ANNOTATION_TYPES.UNDERLINE);
  });

  it('should call onModeChange even when active tool is clicked', () => {
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.HIGHLIGHT} onModeChange={mockOnModeChange} />);

    const highlightButton = screen.getByTestId('button-tool-highlight');
    fireEvent.click(highlightButton);

    // The handler is called regardless, as the component doesn't prevent it.
    // The parent component is responsible for handling the state change.
    expect(mockOnModeChange).toHaveBeenCalledTimes(1);
    expect(mockOnModeChange).toHaveBeenCalledWith(ANNOTATION_TYPES.HIGHLIGHT);
  });

  it('should render undo button when onUndo prop is provided', () => {
    const mockOnUndo = vi.fn();
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} onUndo={mockOnUndo} />);
    
    const undoButton = screen.getByTestId('button-undo-annotation');
    expect(undoButton).toBeInTheDocument();
    expect(screen.getByText('Undo Last Annotation')).toBeInTheDocument();
  });

  it('should not render undo button when onUndo prop is not provided', () => {
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} />);
    
    expect(screen.queryByTestId('button-undo-annotation')).not.toBeInTheDocument();
  });

  it('should call onUndo when undo button is clicked', () => {
    const mockOnUndo = vi.fn();
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} onUndo={mockOnUndo} />);
    
    const undoButton = screen.getByTestId('button-undo-annotation');
    fireEvent.click(undoButton);
    
    expect(mockOnUndo).toHaveBeenCalledTimes(1);
  });

  it('should render select tool with correct attributes', () => {
    render(<PdfToolbar activeMode={ANNOTATION_TYPES.SELECT} onModeChange={mockOnModeChange} />);
    
    const selectButton = screen.getByTestId('button-tool-select');
    fireEvent.click(selectButton);
    
    expect(mockOnModeChange).toHaveBeenCalledWith(ANNOTATION_TYPES.SELECT);
  });
});


