import { vi } from 'vitest';
import { generateId } from '@/utils/ids';

describe('utils/ids', () => {
  it('should generate a unique id', () => {
    const id1 = generateId();
    const id2 = generateId();
    
    expect(id1).toBeDefined();
    expect(id2).toBeDefined();
    expect(id1).not.toBe(id2);
  });

  it('should generate ids that are strings', () => {
    const id = generateId();
    
    expect(typeof id).toBe('string');
  });

  it('should generate ids with reasonable length', () => {
    const id = generateId();
    
    expect(id.length).toBeGreaterThan(0);
    expect(id.length).toBeLessThan(100); // Reasonable upper bound
  });

  it('should generate multiple unique ids', () => {
    const ids = new Set();
    
    for (let i = 0; i < 100; i++) {
      ids.add(generateId());
    }
    
    // All 100 ids should be unique
    expect(ids.size).toBe(100);
  });

  it('should generate ids in quick succession', () => {
    const id1 = generateId();
    const id2 = generateId();
    const id3 = generateId();
    
    expect(id1).not.toBe(id2);
    expect(id2).not.toBe(id3);
    expect(id1).not.toBe(id3);
  });

  // Mutation testing: Validate UUID v4 format
  it('should generate valid UUID v4 format', () => {
    const id = generateId();
    const uuidV4Regex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    
    expect(id).toMatch(uuidV4Regex);
  });

  // Mutation testing: Ensure not empty string
  it('should not generate empty string', () => {
    const id = generateId();
    
    expect(id).not.toBe('');
    expect(id.length).toBeGreaterThan(30); // UUIDs are 36 chars
  });

  // Mutation testing: Ensure not null or undefined
  it('should not return null or undefined', () => {
    const id = generateId();
    
    expect(id).not.toBeNull();
    expect(id).not.toBeUndefined();
    expect(id).toBeTruthy();
  });

  // Mutation testing: Ensure not constant value
  it('should generate different ids each time', () => {
    const ids = Array.from({ length: 10 }, () => generateId());
    const uniqueIds = new Set(ids);
    
    expect(uniqueIds.size).toBe(10);
    // Verify no constant "fixed-id" or similar
    expect(ids.every(id => id.includes('-'))).toBe(true);
  });
});
