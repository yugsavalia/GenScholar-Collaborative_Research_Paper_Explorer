import { describe, it, expect } from 'vitest';
import { loginSchema, createAccountSchema, workspaceSchema } from '../utils/validators';

describe('utils/validators - Comprehensive Coverage', () => {
  describe('loginSchema', () => {
    it('should validate correct login credentials', async () => {
      const validData = { identifier: 'test@example.com', password: 'password123' };
      await expect(loginSchema.validate(validData)).resolves.toEqual(validData);
    });

    it('should accept username as identifier', async () => {
      const validData = { identifier: 'username123', password: 'password' };
      await expect(loginSchema.validate(validData)).resolves.toEqual(validData);
    });

    it('should require identifier field', async () => {
      const invalidData = { password: 'password123' };
      await expect(loginSchema.validate(invalidData)).rejects.toThrow('Email or username is required');
    });

    it('should reject empty identifier', async () => {
      const invalidData = { identifier: '', password: 'password123' };
      await expect(loginSchema.validate(invalidData)).rejects.toThrow('Email or username is required');
    });

    it('should require password field', async () => {
      const invalidData = { identifier: 'test@example.com' };
      await expect(loginSchema.validate(invalidData)).rejects.toThrow('Password is required');
    });

    it('should reject empty password', async () => {
      const invalidData = { identifier: 'test@example.com', password: '' };
      await expect(loginSchema.validate(invalidData)).rejects.toThrow('Password must be at least 6 characters');
    });

    it('should reject short passwords', async () => {
      const invalidData = { identifier: 'test@example.com', password: '12345' };
      await expect(loginSchema.validate(invalidData)).rejects.toThrow('Password must be at least 6 characters');
    });

    it('should accept exactly 6 character password', async () => {
      const validData = { identifier: 'test@example.com', password: '123456' };
      await expect(loginSchema.validate(validData)).resolves.toEqual(validData);
    });

    it('should accept long passwords', async () => {
      const validData = { identifier: 'user', password: 'verylongpassword1234567890' };
      await expect(loginSchema.validate(validData)).resolves.toEqual(validData);
    });
  });

  describe('createAccountSchema', () => {
    const validAccount = {
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
      confirm_password: 'password123'
    };

    it('should validate correct account data', async () => {
      await expect(createAccountSchema.validate(validAccount)).resolves.toEqual(validAccount);
    });

    describe('username validation', () => {
      it('should accept valid usernames', async () => {
        const data = { ...validAccount, username: 'john_doe123' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should reject usernames with special characters', async () => {
        const data = { ...validAccount, username: 'user@name' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username can only contain letters, numbers, and underscores');
      });

      it('should reject usernames with spaces', async () => {
        const data = { ...validAccount, username: 'john doe' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username can only contain letters, numbers, and underscores');
      });

      it('should reject usernames with hyphens', async () => {
        const data = { ...validAccount, username: 'john-doe' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username can only contain letters, numbers, and underscores');
      });

      it('should require username field', async () => {
        const data = { ...validAccount };
        delete data.username;
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username is required');
      });

      it('should reject short usernames', async () => {
        const data = { ...validAccount, username: 'ab' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username must be at least 3 characters');
      });

      it('should accept exactly 3 character username', async () => {
        const data = { ...validAccount, username: 'abc' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should reject long usernames', async () => {
        const data = { ...validAccount, username: 'a'.repeat(31) };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Username must be less than 30 characters');
      });

      it('should accept exactly 30 character username', async () => {
        const data = { ...validAccount, username: 'a'.repeat(30) };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept underscores in username', async () => {
        const data = { ...validAccount, username: 'user_name_123' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept mixed case usernames', async () => {
        const data = { ...validAccount, username: 'UserName123' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });
    });

    describe('email validation', () => {
      it('should accept valid email addresses', async () => {
        const emails = [
          'test@example.com',
          'user.name@domain.co.uk',
          'first+last@test-domain.com',
          'user123@sub.domain.org'
        ];
        for (const email of emails) {
          const data = { ...validAccount, email };
          await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
        }
      });

      it('should reject invalid email format', async () => {
        const data = { ...validAccount, email: 'notanemail' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
      });

      it('should reject email without @', async () => {
        const data = { ...validAccount, email: 'test.example.com' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
      });

      it('should reject email without domain', async () => {
        const data = { ...validAccount, email: 'test@' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
      });

      it('should reject email without TLD', async () => {
        const data = { ...validAccount, email: 'test@example' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
      });

      it('should require email field', async () => {
        const data = { ...validAccount };
        delete data.email;
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Email is required');
      });

      it('should reject empty email', async () => {
        const data = { ...validAccount, email: '' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Email is required');
      });

      it('should accept email with plus sign', async () => {
        const data = { ...validAccount, email: 'test+tag@example.com' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept email with dots', async () => {
        const data = { ...validAccount, email: 'first.last@example.com' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept email with numbers', async () => {
        const data = { ...validAccount, email: 'user123@example456.com' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });
    });

    describe('password validation', () => {
      it('should require password field', async () => {
        const data = { ...validAccount };
        delete data.password;
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Passwords must match');
      });

      it('should reject short passwords', async () => {
        const data = { ...validAccount, password: '12345', confirm_password: '12345' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Password must be at least 6 characters');
      });

      it('should accept exactly 6 character password', async () => {
        const data = { ...validAccount, password: '123456', confirm_password: '123456' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept long passwords', async () => {
        const longPass = 'verylongpassword1234567890';
        const data = { ...validAccount, password: longPass, confirm_password: longPass };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });
    });

    describe('confirm_password validation', () => {
      it('should require confirm_password field', async () => {
        const data = { ...validAccount };
        delete data.confirm_password;
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Please confirm your password');
      });

      it('should reject when passwords do not match', async () => {
        const data = { ...validAccount, confirm_password: 'different' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Passwords must match');
      });

      it('should accept when passwords match', async () => {
        const data = { ...validAccount, password: 'newpass123', confirm_password: 'newpass123' };
        await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
      });

      it('should be case sensitive for password match', async () => {
        const data = { ...validAccount, password: 'Password', confirm_password: 'password' };
        await expect(createAccountSchema.validate(data)).rejects.toThrow('Passwords must match');
      });
    });
  });

  describe('workspaceSchema', () => {
    const validWorkspace = {
      name: 'My Workspace',
      description: 'A test workspace'
    };

    it('should validate correct workspace data', async () => {
      await expect(workspaceSchema.validate(validWorkspace)).resolves.toEqual(validWorkspace);
    });

    describe('name validation', () => {
      it('should require name field', async () => {
        const data = { description: 'test' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name is required');
      });

      it('should reject empty name', async () => {
        const data = { ...validWorkspace, name: '' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name is required');
      });

      it('should reject long names', async () => {
        const data = { ...validWorkspace, name: 'a'.repeat(26) };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Max size is 25 characters');
      });

      it('should accept exactly 25 character name', async () => {
        const data = { ...validWorkspace, name: 'A' + 'a'.repeat(24) };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept names with spaces', async () => {
        const data = { ...validWorkspace, name: 'My Test Workspace' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept names with underscores', async () => {
        const data = { ...validWorkspace, name: 'My_Test_Workspace' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept names with numbers', async () => {
        const data = { ...validWorkspace, name: 'Workspace123' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should reject names starting with digit', async () => {
        const data = { ...validWorkspace, name: '123Workspace' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name cannot start with a digit, underscore, or blank space');
      });

      it('should reject names starting with underscore', async () => {
        const data = { ...validWorkspace, name: '_Workspace' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name cannot start with a digit, underscore, or blank space');
      });

      it('should reject names starting with space', async () => {
        const data = { ...validWorkspace, name: ' Workspace' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name cannot start with a digit, underscore, or blank space');
      });

      it('should reject names with special characters', async () => {
        const data = { ...validWorkspace, name: 'Workspace@123' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name may contain only letters, digits, underscores, and spaces');
      });

      it('should reject names with hyphens', async () => {
        const data = { ...validWorkspace, name: 'My-Workspace' };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Workspace name may contain only letters, digits, underscores, and spaces');
      });

      it('should accept mixed case names', async () => {
        const data = { ...validWorkspace, name: 'MyWorkSpace' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });
    });

    describe('description validation', () => {
      it('should accept optional description', async () => {
        const data = { name: 'Workspace' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept empty description', async () => {
        const data = { ...validWorkspace, description: '' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept undefined description', async () => {
        const data = { name: 'Workspace', description: undefined };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should reject long descriptions', async () => {
        const data = { ...validWorkspace, description: 'a'.repeat(501) };
        await expect(workspaceSchema.validate(data)).rejects.toThrow('Description must be less than 500 characters');
      });

      it('should accept exactly 500 character description', async () => {
        const data = { ...validWorkspace, description: 'a'.repeat(500) };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept description with special characters', async () => {
        const data = { ...validWorkspace, description: 'Test @#$% description with special chars!' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });

      it('should accept multiline descriptions', async () => {
        const data = { ...validWorkspace, description: 'Line 1\nLine 2\nLine 3' };
        await expect(workspaceSchema.validate(data)).resolves.toEqual(data);
      });
    });
  });

  describe('Mutation-specific coverage', () => {
    const validAccount = {
      username: 'testuser',
      email: 'test@example.com',
      password: 'password123',
      confirm_password: 'password123'
    };

    // Kill mutant: Regex /^[a-zA-Z0-9._%+-]+@...$/  → /[a-zA-Z0-9._%+-]+@.../ (removed ^)
    it('should reject email with text before valid email', async () => {
      // Without ^ anchor, "invalid text test@example.com" would pass
      const data = { ...validAccount, email: 'invalid text test@example.com' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });

    // Kill mutant: Regex /^[a-zA-Z0-9._%+-]+@...$/ → /^[a-zA-Z0-9._%+-]+@.../ (removed $)
    it('should reject email with text after valid email', async () => {
      // Without $ anchor, "test@example.com invalid text" would pass
      const data = { ...validAccount, email: 'test@example.com invalid text' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });

    // Kill mutant: StringLiteral 'Password is required' → ""
    it('should have non-empty error message for missing password', async () => {
      const data = { ...validAccount };
      delete data.password;
      
      try {
        await createAccountSchema.validate(data);
        expect.fail('Should have thrown error');
      } catch (error) {
        expect(error.message).toBeTruthy();
        expect(error.message).not.toBe('');
        // Should contain meaningful error, not empty string
      }
    });

    // Kill mutant: StringLiteral Yup.ref('password') → Yup.ref("")
    it('should reference correct password field for confirmation match', async () => {
      const data = { 
        ...validAccount, 
        password: 'correctpass', 
        confirm_password: 'wrongpass' 
      };
      
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Passwords must match');
    });

    it('should use password field specifically for ref not empty string', async () => {
      const data = { 
        ...validAccount, 
        password: 'password123',
        confirm_password: 'password123'
      };
      
      // Should pass when password and confirm_password match
      await expect(createAccountSchema.validate(data)).resolves.toEqual(data);
    });

    // Additional edge cases for regex anchors
    it('should validate email starts with valid characters', async () => {
      const data = { ...validAccount, email: '@example.com' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });

    it('should validate email ends with valid TLD', async () => {
      const data = { ...validAccount, email: 'test@example.' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });

    it('should not allow whitespace in email', async () => {
      const data = { ...validAccount, email: 'test @example.com' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });

    it('should not allow newline in email', async () => {
      const data = { ...validAccount, email: 'test\n@example.com' };
      await expect(createAccountSchema.validate(data)).rejects.toThrow('Invalid email');
    });
  });
});
