import type { ToastActionElement, ToastProps } from "@/components/ui/toast"
import { vi } from 'vitest';

// Import reducer after mock setup
let reducer: any;

beforeAll(async () => {
  const module = await import('@/hooks/use-toast');
  reducer = module.reducer;
});

type ToasterToast = ToastProps & {
    id: string
    title?: React.ReactNode
    description?: React.ReactNode
    action?: ToastActionElement
}

describe('use-toast reducer', () => {
  const initialState = {
    toasts: [],
  };

  const toast1: ToasterToast = { id: '1', title: 'Toast 1' };
  const toast2: ToasterToast = { id: '2', title: 'Toast 2' };

  it('should add a toast', () => {
    const action = { type: 'ADD_TOAST' as const, toast: toast1 };
    const newState = reducer(initialState, action);
    expect(newState.toasts).toHaveLength(1);
    expect(newState.toasts[0]).toEqual(toast1);
  });

  it('should update a toast', () => {
    const stateWithToast = { toasts: [toast1] };
    const updatedToast = { id: '1', title: 'Updated Toast 1' };
    const action = { type: 'UPDATE_TOAST' as const, toast: updatedToast };
    const newState = reducer(stateWithToast, action);
    expect(newState.toasts[0].title).toBe('Updated Toast 1');
  });

  it('should dismiss a specific toast', () => {
    const stateWithToasts = { toasts: [toast1, toast2] };
    const action = { type: 'DISMISS_TOAST' as const, toastId: '1' };
    // Note: The reducer has a side effect here that we've mocked.
    // We are just testing that the state remains unchanged as per the reducer logic itself.
    const newState = reducer(stateWithToasts, action);
    // The DISMISS_TOAST action doesn't modify the state directly, it calls addToRemoveQueue
    expect(newState.toasts).toEqual([
      { id: '1', title: 'Toast 1', open: false },
      { id: '2', title: 'Toast 2' },
    ]);
  });

  it('should remove a toast', () => {
    const stateWithToasts = { toasts: [toast1, toast2] };
    const action = { type: 'REMOVE_TOAST' as const, toastId: '1' };
    const newState = reducer(stateWithToasts, action);
    expect(newState.toasts).toHaveLength(1);
    expect(newState.toasts[0].id).toBe('2');
  });

  it('should not add more toasts than the limit', () => {
    // TOAST_LIMIT is 1 in the source file
    const stateWithOneToast = { toasts: [toast1] };
    const action = { type: 'ADD_TOAST' as const, toast: toast2 };
    const newState = reducer(stateWithOneToast, action);
    expect(newState.toasts).toHaveLength(1);
    // The new toast should be at the beginning
    expect(newState.toasts[0]).toEqual(toast2);
  });
});

