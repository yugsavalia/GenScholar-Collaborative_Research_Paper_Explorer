import { vi } from 'vitest';
import { askChatbot } from '@/api/chatbot';

import { getCsrfToken } from '@/utils/csrf';


vi.mock('@/api/config');

// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

describe('api/chatbot - Extended Coverage', () => {
  const workspaceId = 'ws1';
  const question = 'What is the meaning of life?';
  const csrfToken = 'test-csrf-token';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  describe('Error Handling', () => {
    it('should handle non-JSON error response with 403 status', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      await expect(askChatbot(workspaceId, question)).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle error with detail field', async () => {
      const errorResponse = { detail: 'Access denied' };
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: () => Promise.resolve(errorResponse),
      });

      await expect(askChatbot(workspaceId, question)).rejects.toThrow('Access denied');
    });

    it('should handle error with message field', async () => {
      const errorResponse = { message: 'Invalid input' };
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: () => Promise.resolve(errorResponse),
      });

      await expect(askChatbot(workspaceId, question)).rejects.toThrow('Invalid input');
    });

    it('should use statusText when error response is not parsable', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      await expect(askChatbot(workspaceId, question)).rejects.toThrow(
        'Failed to get chatbot response: Internal Server Error'
      );
    });

    it('should handle AbortError (timeout)', async () => {
      const abortError = new Error('Abort');
      abortError.name = 'AbortError';
      mockFetch.mockRejectedValue(abortError);

      await expect(askChatbot(workspaceId, question)).rejects.toThrow(
        'Request timed out. The AI is taking too long to respond. Please try again with a simpler question.'
      );
    });
  });

  describe('Response Formats', () => {
    it('should handle response without status field', async () => {
      const mockResponse = {
        user_question: question,
        ai_answer: '42',
      };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await askChatbot(workspaceId, question);
      expect(result).toEqual(mockResponse);
    });

    it('should return data as-is when status is not "ok" but no error field', async () => {
      const mockResponse = {
        status: 'processing',
        data: 'some data',
      };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await askChatbot(workspaceId, question);
      expect(result).toEqual(mockResponse);
    });
  });
});


