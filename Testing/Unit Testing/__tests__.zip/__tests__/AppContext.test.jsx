import React from 'react';
import { vi, beforeEach, describe, it, expect } from 'vitest';
import { render, screen, act, waitFor } from '@testing-library/react';
import { AppProvider, useApp } from '@/context/AppContext';

// Mock API functions
vi.mock('@/api/workspaces.js', () => ({
  getWorkspaces: vi.fn().mockResolvedValue([
    { id: 1, name: 'Workspace 1', created_at: '2024-01-01', is_creator: true },
    { id: 2, name: 'Workspace 2', created_at: '2024-01-02', is_creator: false }
  ]),
  createWorkspace: vi.fn().mockResolvedValue({ id: 3, name: 'New Workspace', created_at: '2024-01-03', is_creator: true }),
  deleteWorkspace: vi.fn().mockResolvedValue({}),
  getWorkspaceMembers: vi.fn().mockResolvedValue([]),
  inviteUserToWorkspace: vi.fn().mockResolvedValue({}),
  updateMemberRole: vi.fn().mockResolvedValue({}),
  getPendingInvitations: vi.fn().mockResolvedValue([]),
  acceptInvitation: vi.fn().mockResolvedValue({}),
  declineInvitation: vi.fn().mockResolvedValue({}),
  getNotifications: vi.fn().mockResolvedValue({ notifications: [], unread_count: 0 }),
  markNotificationRead: vi.fn().mockResolvedValue({})
}));

const TestComponent = () => {
  const { workspaces, loading, createWorkspace } = useApp();
  return (
    <div>
      <div data-testid="loading">{loading ? 'true' : 'false'}</div>
      <div data-testid="workspaceCount">{workspaces.length}</div>
      <button onClick={() => createWorkspace('Test Workspace', '')}>Create Workspace</button>
    </div>
  );
};

describe('context/AppContext', () => {
  it('should load workspaces on mount', async () => {
    render(
      <AppProvider>
        <TestComponent />
      </AppProvider>
    );
    
    // Initially loading
    expect(screen.getByTestId('loading')).toHaveTextContent('true');
    
    // Wait for workspaces to load
    await waitFor(() => {
      expect(screen.getByTestId('loading')).toHaveTextContent('false');
    });
    
    // Should have 2 workspaces
    expect(screen.getByTestId('workspaceCount')).toHaveTextContent('2');
  });

  it('should create a new workspace', async () => {
    render(
      <AppProvider>
        <TestComponent />
      </AppProvider>
    );
    
    // Wait for initial load
    await waitFor(() => {
      expect(screen.getByTestId('loading')).toHaveTextContent('false');
    });
    
    // Create new workspace
    await act(async () => {
      screen.getByText('Create Workspace').click();
    });
    
    // Should now have 3 workspaces
    await waitFor(() => {
      expect(screen.getByTestId('workspaceCount')).toHaveTextContent('3');
    });
  });
});


