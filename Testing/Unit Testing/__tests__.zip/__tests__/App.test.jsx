import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import App from '../App';
import * as seed from '../mocks/seed';

// Mock all route components
vi.mock('../routes/Landing', () => ({
  default: () => <div>Landing Page</div>
}));

vi.mock('../routes/Auth', () => ({
  default: () => <div>Auth Page</div>
}));

vi.mock('../routes/Dashboard', () => ({
  default: () => <div>Dashboard Page</div>
}));

vi.mock('../routes/Workspace', () => ({
  default: () => <div>Workspace Page</div>
}));

vi.mock('../routes/Contact', () => ({
  default: () => <div>Contact Page</div>
}));

vi.mock('../routes/Logout', () => ({
  default: () => <div>Logout Page</div>
}));

vi.mock('../routes/Profile', () => ({
  default: () => <div>Profile Page</div>
}));

vi.mock('../routes/ForgotPassword', () => ({
  default: () => <div>Forgot Password Page</div>
}));

vi.mock('../routes/ResetPassword', () => ({
  default: () => <div>Reset Password Page</div>
}));

// Mock seed data
vi.mock('../mocks/seed', () => ({
  initializeSeedData: vi.fn()
}));

// Mock context providers
vi.mock('../context/AuthContext', () => ({
  AuthProvider: ({ children }) => <div data-testid="auth-provider">{children}</div>,
  useAuth: vi.fn(() => ({
    isAuthenticated: false,
    loading: false
  }))
}));

vi.mock('../context/AppContext', () => ({
  AppProvider: ({ children }) => <div data-testid="app-provider">{children}</div>
}));

describe('App', () => {
  let originalEnv;

  beforeEach(() => {
    originalEnv = import.meta.env.VITE_USE_BACKEND_API;
    vi.clearAllMocks();
    
    // Mock classList
    document.documentElement.classList.add = vi.fn();
  });

  afterEach(() => {
    import.meta.env.VITE_USE_BACKEND_API = originalEnv;
  });

  it('should render App with providers', () => {
    render(<App />);
    
    expect(screen.getByTestId('auth-provider')).toBeInTheDocument();
    expect(screen.getByTestId('app-provider')).toBeInTheDocument();
  });

  it('should add dark class to document on mount', async () => {
    render(<App />);
    
    await waitFor(() => {
      expect(document.documentElement.classList.add).toHaveBeenCalledWith('dark');
    });
  });

  it('should initialize seed data when USE_BACKEND_API is false', async () => {
    import.meta.env.VITE_USE_BACKEND_API = 'false';
    
    render(<App />);
    
    await waitFor(() => {
      expect(seed.initializeSeedData).toHaveBeenCalled();
    });
  });

  it('should NOT initialize seed data when USE_BACKEND_API is true', async () => {
    import.meta.env.VITE_USE_BACKEND_API = 'true';
    
    render(<App />);
    
    await waitFor(() => {
      expect(document.documentElement.classList.add).toHaveBeenCalledWith('dark');
    });
    
    // Wait a bit and ensure seed data was NOT called
    await new Promise(resolve => setTimeout(resolve, 100));
    expect(seed.initializeSeedData).not.toHaveBeenCalled();
  });

  it('should NOT initialize seed data when USE_BACKEND_API is undefined', async () => {
    delete import.meta.env.VITE_USE_BACKEND_API;
    
    render(<App />);
    
    await waitFor(() => {
      expect(document.documentElement.classList.add).toHaveBeenCalledWith('dark');
    });
    
    // Wait a bit and ensure seed data was called (falsy value)
    await new Promise(resolve => setTimeout(resolve, 100));
    expect(seed.initializeSeedData).toHaveBeenCalled();
  });
});

describe('App Routing', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    document.documentElement.classList.add = vi.fn();
  });

  it('should render landing page at root path', () => {
    window.history.pushState({}, '', '/');
    render(<App />);
    
    expect(screen.getByText('Landing Page')).toBeInTheDocument();
  });

  it('should render auth page at /auth', () => {
    window.history.pushState({}, '', '/auth');
    render(<App />);
    
    expect(screen.getByText('Auth Page')).toBeInTheDocument();
  });

  it('should render contact page at /contact', () => {
    window.history.pushState({}, '', '/contact');
    render(<App />);
    
    expect(screen.getByText('Contact Page')).toBeInTheDocument();
  });

  it('should render forgot password page', () => {
    window.history.pushState({}, '', '/forgot-password');
    render(<App />);
    
    expect(screen.getByText('Forgot Password Page')).toBeInTheDocument();
  });

  it('should render reset password page with params', () => {
    window.history.pushState({}, '', '/reset-password/abc123/token456');
    render(<App />);
    
    expect(screen.getByText('Reset Password Page')).toBeInTheDocument();
  });

  it('should render 404 page for unknown routes', () => {
    window.history.pushState({}, '', '/unknown-route');
    render(<App />);
    
    expect(screen.getByText('404')).toBeInTheDocument();
    expect(screen.getByText('Page not found')).toBeInTheDocument();
  });
});

describe('Protected Routes', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    document.documentElement.classList.add = vi.fn();
  });

  it('should show loading state for protected routes when loading', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: false,
      loading: true
    });

    window.history.pushState({}, '', '/dashboard');
    render(<App />);
    
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('should redirect to /auth when not authenticated on dashboard', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: false,
      loading: false
    });

    window.history.pushState({}, '', '/dashboard');
    render(<App />);
    
    await waitFor(() => {
      expect(screen.getByText('Auth Page')).toBeInTheDocument();
    });
  });

  it('should render dashboard when authenticated', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: true,
      loading: false
    });

    window.history.pushState({}, '', '/dashboard');
    render(<App />);
    
    expect(screen.getByText('Dashboard Page')).toBeInTheDocument();
  });

  it('should render profile when authenticated', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: true,
      loading: false
    });

    window.history.pushState({}, '', '/profile');
    render(<App />);
    
    expect(screen.getByText('Profile Page')).toBeInTheDocument();
  });

  it('should render workspace when authenticated with id param', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: true,
      loading: false
    });

    window.history.pushState({}, '', '/workspace/workspace-123');
    render(<App />);
    
    expect(screen.getByText('Workspace Page')).toBeInTheDocument();
  });

  it('should redirect to /auth when not authenticated on profile', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: false,
      loading: false
    });

    window.history.pushState({}, '', '/profile');
    render(<App />);
    
    await waitFor(() => {
      expect(screen.getByText('Auth Page')).toBeInTheDocument();
    });
  });

  it('should redirect to /auth when not authenticated on workspace', async () => {
    const { useAuth } = await import('../context/AuthContext');
    useAuth.mockReturnValue({
      isAuthenticated: false,
      loading: false
    });

    window.history.pushState({}, '', '/workspace/123');
    render(<App />);
    
    await waitFor(() => {
      expect(screen.getByText('Auth Page')).toBeInTheDocument();
    });
  });
});
