import { vi } from 'vitest';
import React from 'react';
import { render, screen, act } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import * as storageModule from '@/utils/storage';
import * as authApi from '@/api/auth';

vi.mock('@/utils/storage', () => ({
    storage: {
        get: vi.fn(),
        set: vi.fn(),
        remove: vi.fn(),
    },
}));

vi.mock('@/api/auth', () => ({
    getCurrentUser: vi.fn(),
    login: vi.fn(),
    logout: vi.fn(),
}));

const storage = storageModule.storage;

const TestComponent = () => {
    const { isAuthenticated, user, login: authLogin, logout: authLogout } = useAuth();
    return (
        <div>
            <div data-testid="isAuthenticated">{String(isAuthenticated)}</div>
            <div data-testid="user">{JSON.stringify(user)}</div>
            <button onClick={() => authLogin('test', 'password')}>Login</button>
            <button onClick={() => authLogout()}>Logout</button>
        </div>
    );
};

describe('context/AuthContext', () => {
    beforeEach(() => {
        storage.get.mockClear();
        storage.set.mockClear();
        storage.remove.mockClear();
        authApi.getCurrentUser.mockClear();
        authApi.login.mockClear();
        authApi.logout.mockClear();
    });

    it('should have a default state of not authenticated', async () => {
        authApi.getCurrentUser.mockResolvedValue(null);
        await act(async () => {
            render(<AuthProvider><TestComponent /></AuthProvider>);
        });
        expect(screen.getByTestId('isAuthenticated')).toHaveTextContent('false');
        expect(screen.getByTestId('user')).toHaveTextContent('null');
    });

    it('should log in a user and update the state', async () => {
        authApi.getCurrentUser.mockResolvedValue(null);
        const mockUser = { username: 'test' };
        authApi.login.mockResolvedValue(mockUser);

        await act(async () => {
            render(<AuthProvider><TestComponent /></AuthProvider>);
        });

        await act(async () => {
            screen.getByText('Login').click();
        });

        expect(authApi.login).toHaveBeenCalledWith('test', 'password');
        expect(screen.getByTestId('isAuthenticated')).toHaveTextContent('true');
        expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(mockUser));
    });

    it('should log out a user and update the state', async () => {
        const mockUser = { username: 'test' };
        authApi.getCurrentUser.mockResolvedValue(mockUser);
        authApi.logout.mockResolvedValue({});

        await act(async () => {
            render(<AuthProvider><TestComponent /></AuthProvider>);
        });

        expect(screen.getByTestId('isAuthenticated')).toHaveTextContent('true');
        expect(screen.getByTestId('user')).toHaveTextContent(JSON.stringify(mockUser));

        await act(async () => {
            screen.getByText('Logout').click();
        });

        expect(authApi.logout).toHaveBeenCalled();
        expect(screen.getByTestId('isAuthenticated')).toHaveTextContent('false');
        expect(screen.getByTestId('user')).toHaveTextContent('null');
    });
});


