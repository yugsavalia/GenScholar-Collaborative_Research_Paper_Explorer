import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Textarea } from '@/components/ui/textarea';
import { vi } from 'vitest';

describe('Textarea component', () => {
  test('renders textarea element', () => {
    const { getByRole } = render(<Textarea />);
    const textareaElement = getByRole('textbox');
    expect(textareaElement).toBeInTheDocument();
  });

  test('handles onChange event', () => {
    const handleChange = vi.fn();
    const { getByRole } = render(<Textarea onChange={handleChange} />);
    const textareaElement = getByRole('textbox');
    fireEvent.change(textareaElement, { target: { value: 'testing' } });
    expect(handleChange).toHaveBeenCalledTimes(1);
    expect(textareaElement.value).toBe('testing');
  });

  test('applies custom className', () => {
    const { getByRole } = render(<Textarea className="custom-class" />);
    const textareaElement = getByRole('textbox');
    expect(textareaElement).toHaveClass('custom-class');
  });

  test('accepts standard textarea props like placeholder', () => {
    const { getByPlaceholderText } = render(<Textarea placeholder="Enter description" />);
    const textareaElement = getByPlaceholderText('Enter description');
    expect(textareaElement).toBeInTheDocument();
  });

  test('is disabled when disabled prop is true', () => {
    const { getByRole } = render(<Textarea disabled />);
    const textareaElement = getByRole('textbox');
    expect(textareaElement).toBeDisabled();
  });

  test('forwards ref correctly', () => {
    const ref = React.createRef();
    render(<Textarea ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLTextAreaElement);
  });
});

