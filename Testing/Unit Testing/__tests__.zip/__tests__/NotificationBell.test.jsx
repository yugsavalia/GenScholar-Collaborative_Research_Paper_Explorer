import React from 'react';
import { render, screen, fireEvent, waitFor, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import NotificationBell from '@/components/NotificationBell';
import { useAuth } from '@/context/AuthContext';
import { useApp } from '@/context/AppContext';
import * as api from '@/api/workspaces';
import { vi } from 'vitest';

vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

// Mock hooks and modules
vi.mock('@/context/AuthContext');
vi.mock('@/context/AppContext');
vi.mock('@/api/workspaces');

const mockNotifications = [
  { id: 1, message: 'You have a new message', is_read: false, type: 'MESSAGE' },
  { id: 2, message: 'You have been invited to a workspace', is_read: false, type: 'INVITATION', invitation_id: 10, workspace_id: 2 },
  { id: 3, message: 'This is an old notification', is_read: true, type: 'MESSAGE' },
];

describe('NotificationBell component', () => {
  beforeEach(() => {
    useAuth.mockReturnValue({ isAuthenticated: true, user: { id: 1 } });
    useApp.mockReturnValue({ loadWorkspaceMembers: vi.fn() });
    api.getNotifications.mockResolvedValue({ notifications: mockNotifications, unread_count: 2 });
    api.markNotificationRead.mockResolvedValue({});
    api.acceptInvitation.mockResolvedValue({});
    api.declineInvitation.mockResolvedValue({});
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  test.skip('fetches and displays notifications on mount', async () => {
    render(<NotificationBell />);
    
    // Bell icon should be visible
    expect(screen.getByRole('button')).toBeInTheDocument();

    // Unread count should be displayed
    await waitFor(() => {
      expect(screen.getByText('2')).toBeInTheDocument();
    });
  });

  test('opens and closes the notification dropdown', async () => {
    render(<NotificationBell />);
    const bellButton = screen.getByRole('button');
    
    // Open dropdown
    fireEvent.click(bellButton);
    await waitFor(() => {
      expect(screen.getByText('You have a new message')).toBeInTheDocument();
      expect(screen.getByText('You have been invited to a workspace')).toBeInTheDocument();
    });

    // Close dropdown by clicking outside (simulated via document mousedown)
    fireEvent.mouseDown(document);
    await waitFor(() => {
      expect(screen.queryByText('You have a new message')).not.toBeInTheDocument();
    });
  });

  test('displays notifications when bell is clicked', async () => {
    render(<NotificationBell />);
    fireEvent.click(screen.getByRole('button'));

    // Wait for dropdown to open and notifications to render
    await waitFor(() => {
      expect(screen.getByText('You have a new message')).toBeInTheDocument();
      expect(screen.getByText('You have been invited to a workspace')).toBeInTheDocument();
    });
  });

  test('handles accepting an invitation', async () => {
    render(<NotificationBell />);
    fireEvent.click(screen.getByRole('button'));

    const acceptButton = await screen.findByText('Accept');
    fireEvent.click(acceptButton);

    await waitFor(() => {
      expect(api.acceptInvitation).toHaveBeenCalledWith(10);
    });
  });

  test('handles declining an invitation', async () => {
    render(<NotificationBell />);
    fireEvent.click(screen.getByRole('button'));

    const declineButton = await screen.findByText('Decline');
    fireEvent.click(declineButton);

    await waitFor(() => {
      expect(api.declineInvitation).toHaveBeenCalledWith(10);
    });
  });

  test('displays a message when there are no notifications', async () => {
    api.getNotifications.mockResolvedValue({ notifications: [], unread_count: 0 });
    render(<NotificationBell />);
    fireEvent.click(screen.getByRole('button'));

    await waitFor(() => {
      expect(screen.getByText('No notifications')).toBeInTheDocument();
    });
  });
});

