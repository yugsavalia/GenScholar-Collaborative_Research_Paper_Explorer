import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import ConfirmModal from '@/components/ConfirmModal';
import { vi } from 'vitest';

// Mock child components
vi.mock('@/components/Modal', () => ({ 
  default: ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;
    return (
      <div data-testid="modal">
        <h1>{title}</h1>
        <div>{children}</div>
        <button onClick={onClose}>Close Modal</button>
      </div>
    );
  }
}));

vi.mock('@/components/ui/button', () => ({ 
  Button: ({ onClick, children, ...props }) => (
    <button onClick={onClick} {...props}>
      {children}
    </button>
  )
}));

describe('ConfirmModal', () => {
  const mockOnClose = vi.fn();
  const mockOnConfirm = vi.fn();

  beforeEach(() => {
    // Clear mock history before each test
    mockOnClose.mockClear();
    mockOnConfirm.mockClear();
  });

  it('should not be visible when isOpen is false', () => {
    render(
      <ConfirmModal
        isOpen={false}
        onClose={mockOnClose}
        onConfirm={mockOnConfirm}
        title="Test Title"
        message="Test message"
      />
    );
    expect(screen.queryByTestId('modal')).not.toBeInTheDocument();
  });

  it('should be visible and display title and message when isOpen is true', () => {
    render(
      <ConfirmModal
        isOpen={true}
        onClose={mockOnClose}
        onConfirm={mockOnConfirm}
        title="Test Title"
        message="Test message"
      />
    );
    expect(screen.getByTestId('modal')).toBeInTheDocument();
    expect(screen.getByText('Test Title')).toBeInTheDocument();
    expect(screen.getByText('Test message')).toBeInTheDocument();
  });

  it('should use a default title if no title is provided', () => {
    render(
      <ConfirmModal
        isOpen={true}
        onClose={mockOnClose}
        onConfirm={mockOnConfirm}
        message="Test message"
      />
    );
    expect(screen.getByText('Confirm Action')).toBeInTheDocument();
  });

  it('should call onClose when the cancel button is clicked', () => {
    render(
      <ConfirmModal
        isOpen={true}
        onClose={mockOnClose}
        onConfirm={mockOnConfirm}
        title="Test Title"
        message="Test message"
      />
    );
    const cancelButton = screen.getByTestId('button-cancel-modal');
    fireEvent.click(cancelButton);
    expect(mockOnClose).toHaveBeenCalledTimes(1);
    expect(mockOnConfirm).not.toHaveBeenCalled();
  });

  it('should call onConfirm and then onClose when the confirm button is clicked', () => {
    render(
      <ConfirmModal
        isOpen={true}
        onClose={mockOnClose}
        onConfirm={mockOnConfirm}
        title="Test Title"
        message="Test message"
      />
    );
    const confirmButton = screen.getByTestId('button-confirm-modal');
    fireEvent.click(confirmButton);

    // Check that onConfirm was called
    expect(mockOnConfirm).toHaveBeenCalledTimes(1);
    // Check that onClose was also called
    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });
});

