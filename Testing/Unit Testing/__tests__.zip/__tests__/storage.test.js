import { storage } from '@/utils/storage';

describe('utils/storage', () => {
  let localStorageMock;

  beforeEach(() => {
    localStorageMock = (() => {
      let store = {};
      return {
        getItem: (key) => store[key] || null,
        setItem: (key, value) => {
          store[key] = value.toString();
        },
        removeItem: (key) => {
          delete store[key];
        },
        clear: () => {
          store = {};
        },
      };
    })();
    Object.defineProperty(window, 'localStorage', { value: localStorageMock });
  });

  it('should set and get an item from local storage', () => {
    const testKey = 'testKey';
    const testValue = { data: 'testValue' };
    storage.set(testKey, testValue);
    expect(storage.get(testKey)).toEqual(testValue);
  });

  it('should return null if the item is not in local storage', () => {
    expect(storage.get('nonExistentKey')).toBeNull();
  });

  it('should remove an item from local storage', () => {
    const testKey = 'testKey';
    const testValue = { data: 'testValue' };
    storage.set(testKey, testValue);
    storage.remove(testKey);
    expect(storage.get(testKey)).toBeNull();
  });

  // Mutation testing: Verify uses localStorage not sessionStorage
  it('should use localStorage for storage operations', () => {
    const setItemSpy = vi.spyOn(localStorageMock, 'setItem');
    const getItemSpy = vi.spyOn(localStorageMock, 'getItem');
    
    storage.set('test', { value: 'data' });
    storage.get('test');
    
    expect(setItemSpy).toHaveBeenCalled();
    expect(getItemSpy).toHaveBeenCalled();
  });

  // Mutation testing: Verify JSON.stringify is used
  it('should stringify objects when storing', () => {
    const testObj = { nested: { data: 'value' } };
    storage.set('test', testObj);
    
    const stored = localStorageMock.getItem('test');
    expect(typeof stored).toBe('string');
    expect(stored).toContain('nested');
    expect(stored).toContain('data');
  });

  // Mutation testing: Verify JSON.parse is used
  it('should parse stored strings back to objects', () => {
    const testObj = { array: [1, 2, 3], bool: true };
    storage.set('test', testObj);
    
    const retrieved = storage.get('test');
    expect(typeof retrieved).toBe('object');
    expect(retrieved).toEqual(testObj);
    expect(Array.isArray(retrieved.array)).toBe(true);
  });

  // Mutation testing: Verify null handling
  it('should return null for non-existent items, not undefined', () => {
    const result = storage.get('nonexistent');
    
    expect(result).toBeNull();
    expect(result).not.toBeUndefined();
  });

  // Mutation testing: Verify error handling
  it('should handle JSON parse errors gracefully', () => {
    localStorageMock.getItem = vi.fn(() => 'invalid-json{');
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    const result = storage.get('test');
    
    expect(result).toBeNull();
    expect(consoleSpy).toHaveBeenCalled();
    
    consoleSpy.mockRestore();
  });

  it('should handle storage quota errors when setting', () => {
    localStorageMock.setItem = vi.fn(() => {
      throw new Error('QuotaExceededError');
    });
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    expect(() => storage.set('test', 'value')).not.toThrow();
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('Error writing'),
      expect.any(Error)
    );
    
    consoleSpy.mockRestore();
  });

  it('should log errors when removing items fails', () => {
    localStorageMock.removeItem = vi.fn(() => {
      throw new Error('Remove error');
    });
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    storage.remove('test');
    
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('Error removing'),
      expect.any(Error)
    );
    
    consoleSpy.mockRestore();
  });

  it('should log errors when clearing storage fails', () => {
    localStorageMock.clear = vi.fn(() => {
      throw new Error('Clear error');
    });
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    storage.clear();
    
    expect(consoleSpy).toHaveBeenCalledWith(
      expect.stringContaining('Error clearing'),
      expect.any(Error)
    );
    
    consoleSpy.mockRestore();
  });

  // Mutation testing: Verify correct method calls
  it('should use correct localStorage methods', () => {
    const setItemSpy = vi.spyOn(localStorageMock, 'setItem');
    const removeItemSpy = vi.spyOn(localStorageMock, 'removeItem');
    const clearSpy = vi.spyOn(localStorageMock, 'clear');
    
    storage.set('key', 'value');
    expect(setItemSpy).toHaveBeenCalledWith('key', JSON.stringify('value'));
    
    storage.remove('key');
    expect(removeItemSpy).toHaveBeenCalledWith('key');
    
    storage.clear();
    expect(clearSpy).toHaveBeenCalled();
  });
});


