import { vi } from 'vitest';
import {
  getWorkspaces,
  createWorkspace,
  getWorkspaceMembers,
  inviteUserToWorkspace,
  updateMemberRole,
  searchUsers,
  getNotifications,
  markNotificationRead
} from '@/api/workspaces';

import { apiGet, apiPost, apiPatch } from '@/api/client';


vi.mock('@/api/client', () => ({
  apiGet: vi.fn(),
  apiPost: vi.fn(),
  apiPatch: vi.fn(),
}));

describe('api/workspaces - Extended Coverage', () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('createWorkspace - Trimming', () => {
    it('should trim workspace name before creating', async () => {
      const mockWorkspace = { id: '2', name: 'Trimmed Workspace' };
      apiPost.mockResolvedValue({ data: { workspace: mockWorkspace } });

      await createWorkspace('  Trimmed Workspace  ');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/', { name: 'Trimmed Workspace' });
    });
  });

  describe('getWorkspaceMembers', () => {
    it('should fetch workspace members', async () => {
      const mockMembers = [
        { id: 1, user: { username: 'user1' }, role: 'RESEARCHER' },
        { id: 2, user: { username: 'user2' }, role: 'REVIEWER' }
      ];
      apiGet.mockResolvedValue({ data: { members: mockMembers } });

      const result = await getWorkspaceMembers('ws1');

      expect(apiGet).toHaveBeenCalledWith('/api/workspaces/ws1/members/');
      expect(result).toEqual(mockMembers);
    });
  });

  describe('inviteUserToWorkspace - Extended', () => {
    it('should trim username and uppercase role', async () => {
      apiPost.mockResolvedValue({ data: { invitation: { id: 'inv1' } } });

      await inviteUserToWorkspace('ws1', '  testuser  ', 'researcher');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/ws1/invite/', {
        username: 'testuser',
        role: 'RESEARCHER'
      });
    });

    it('should use default role if not provided', async () => {
      apiPost.mockResolvedValue({ data: { invitation: { id: 'inv1' } } });

      await inviteUserToWorkspace('ws1', 'testuser');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/ws1/invite/', {
        username: 'testuser',
        role: 'RESEARCHER'
      });
    });
  });

  describe('updateMemberRole', () => {
    it('should update member role', async () => {
      const mockMember = { id: 1, role: 'REVIEWER' };
      apiPatch.mockResolvedValue({ data: { member: mockMember } });

      const result = await updateMemberRole('ws1', 1, 'REVIEWER');

      expect(apiPatch).toHaveBeenCalledWith('/api/workspaces/ws1/members/1/', {
        role: 'REVIEWER'
      });
      expect(result).toEqual(mockMember);
    });
  });

  describe('searchUsers', () => {
    it('should search users with encoded query', async () => {
      const mockUsers = [
        { id: 1, username: 'user1', email: 'user1@test.com' },
        { id: 2, username: 'user2', email: 'user2@test.com' }
      ];
      apiGet.mockResolvedValue({ results: mockUsers });

      const result = await searchUsers('test query');

      expect(apiGet).toHaveBeenCalledWith('/api/users/?q=test%20query');
      expect(result).toEqual(mockUsers);
    });

    it('should return empty array if no results', async () => {
      apiGet.mockResolvedValue({});

      const result = await searchUsers('nonexistent');

      expect(result).toEqual([]);
    });
  });

  describe('getNotifications', () => {
    it('should fetch notifications', async () => {
      const mockData = {
        notifications: [{ id: 1, message: 'Test notification' }],
        unread_count: 1
      };
      apiGet.mockResolvedValue({ data: mockData });

      const result = await getNotifications();

      expect(apiGet).toHaveBeenCalledWith('/api/notifications/');
      expect(result).toEqual(mockData);
    });
  });

  describe('markNotificationRead', () => {
    it('should mark notification as read', async () => {
      const mockResponse = { message: 'Notification marked as read' };
      apiPatch.mockResolvedValue({ data: mockResponse });

      const result = await markNotificationRead(123);

      expect(apiPatch).toHaveBeenCalledWith('/api/notifications/123/', {});
      expect(result).toEqual(mockResponse);
    });
  });
});


