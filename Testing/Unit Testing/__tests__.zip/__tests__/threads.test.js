import { vi } from 'vitest';
import { getThreads, createThread, getThread, addMessage } from '@/api/threads';

import { getCsrfToken } from '@/utils/csrf';

import { API_BASE_URL } from '@/api/config';


// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Mock config module
vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

describe('api/threads', () => {
  const csrfToken = 'test-csrf-token';
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';
  const threadId = 'thread1';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  // --- getThreads ---
  describe('getThreads', () => {
    it('should fetch and return a list of threads', async () => {
      const mockThreads = [{ id: 't1', selection_text: 'Some text' }];
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockThreads),
      });

      const result = await getThreads(workspaceId, pdfId);

      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}/api/threads/?workspace_id=${workspaceId}&pdf_id=${pdfId}`,
        expect.any(Object)
      );
      expect(result).toEqual(mockThreads);
    });

    it('should handle paginated response for getThreads', async () => {
        const mockThreads = [{ id: 't1' }];
        mockFetch.mockResolvedValue({
          ok: true,
          json: () => Promise.resolve({ results: mockThreads }),
        });
  
        const result = await getThreads(workspaceId, pdfId);
        expect(result).toEqual(mockThreads);
      });
  });

  // --- createThread ---
  describe('createThread', () => {
    it('should create a new thread and return it', async () => {
      const threadData = {
        page_number: 1,
        selection_text: 'A new thread',
        anchor_rect: { x: 0, y: 0, width: 0, height: 0 },
      };
      const mockResponse = { id: 'new-thread', ...threadData };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockResponse),
      });

      const result = await createThread(workspaceId, pdfId, threadData);

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}/api/threads/`,
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({
            workspace_id: workspaceId,
            pdf_id: pdfId,
            pdf: pdfId,
            ...threadData,
          }),
        })
      );
      expect(result).toEqual(mockResponse);
    });
  });

  // --- getThread ---
  describe('getThread', () => {
    it('should fetch a single thread with its messages', async () => {
      const mockThreadWithMessages = {
        id: threadId,
        messages: [{ id: 'm1', content: 'Hello' }],
      };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockThreadWithMessages),
      });

      const result = await getThread(threadId);

      expect(mockFetch).toHaveBeenCalledWith(`${API_BASE_URL}/api/threads/${threadId}/`, expect.any(Object));
      expect(result).toEqual(mockThreadWithMessages);
    });
  });

  // --- addMessage ---
  describe('addMessage', () => {
    it('should add a message to a thread and return the new message', async () => {
      const content = 'This is a reply.';
      const mockMessage = { id: 'new-msg', content };
      mockFetch.mockResolvedValue({
        ok: true,
        json: () => Promise.resolve(mockMessage),
      });

      const result = await addMessage(threadId, content);

      expect(getCsrfToken).toHaveBeenCalledTimes(1);
      expect(mockFetch).toHaveBeenCalledWith(
        `${API_BASE_URL}/api/threads/${threadId}/messages/`,
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({ content }),
        })
      );
      expect(result).toEqual(mockMessage);
    });
  });
});


