import { vi } from 'vitest';
import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import WorkspaceList from '@/components/WorkspaceList';
import { MemoryRouter } from 'wouter';

// Mock WorkspaceCard component
vi.mock('@/components/WorkspaceCard', () => ({
  default: ({ workspace, isCreator }) => (
    <div data-testid={`workspace-card-${workspace.id}`}>
      <h3>{workspace.name}</h3>
      <p>{workspace.description}</p>
    </div>
  )
}));

// Mock AppContext
vi.mock('@/context/AppContext', () => ({
  useApp: () => ({
    isWorkspaceCreator: {},
    workspaces: [],
    loading: false
  })
}));

describe('WorkspaceList component', () => {
  const mockWorkspaces = [
    { id: 1, name: 'React Projects', description: 'All about React.' },
    { id: 2, name: 'Vue Projects', description: 'All about Vue.' },
    { id: 3, name: 'Angular Projects', description: 'All about Angular.' },
  ];

  test('component is defined and exported', () => {
    expect(WorkspaceList).toBeDefined();
    expect(typeof WorkspaceList).toBe('function');
  });

  test('accepts workspaces and searchQuery props', () => {
    const props = { workspaces: mockWorkspaces, searchQuery: '' };
    expect(props.workspaces).toHaveLength(3);
    expect(props.searchQuery).toBe('');
  });

  test('filters workspaces by name (lowercase)', () => {
    const filtered = mockWorkspaces.filter(w => 
      w.name.toLowerCase().includes('react')
    );
    expect(filtered).toHaveLength(1);
    expect(filtered[0].name).toBe('React Projects');
  });

  test('filters workspaces by description (case-insensitive)', () => {
    const query = 'about vue';
    const filtered = mockWorkspaces.filter(w => 
      w.name.toLowerCase().includes(query.toLowerCase()) ||
      w.description.toLowerCase().includes(query.toLowerCase())
    );
    expect(filtered).toHaveLength(1);
    expect(filtered[0].name).toBe('Vue Projects');
  });

  test('returns empty array when no matches', () => {
    const query = 'nonexistent';
    const filtered = mockWorkspaces.filter(w => 
      w.name.toLowerCase().includes(query.toLowerCase()) ||
      w.description.toLowerCase().includes(query.toLowerCase())
    );
    expect(filtered).toHaveLength(0);
  });
});


