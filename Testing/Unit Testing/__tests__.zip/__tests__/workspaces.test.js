import { vi } from 'vitest';
import { getWorkspaces, createWorkspace, acceptInvitation, declineInvitation, inviteUserToWorkspace } from '@/api/workspaces';
import { apiGet, apiPost } from '@/api/client';

vi.mock('@/api/client', () => ({
  apiGet: vi.fn(),
  apiPost: vi.fn(),
}));

describe('api/workspaces', () => {
  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('getWorkspaces', () => {
    it('should call apiGet and return workspaces', async () => {
      const mockWorkspaces = [{ id: '1', name: 'Workspace 1' }];
      apiGet.mockResolvedValue({ data: { workspaces: mockWorkspaces } });

      const result = await getWorkspaces();

      expect(apiGet).toHaveBeenCalledWith('/api/workspaces/');
      expect(result).toEqual(mockWorkspaces);
    });

    it('getWorkspaces should handle search query', async () => {
        await getWorkspaces('searchterm');
        expect(apiGet).toHaveBeenCalledWith('/api/workspaces/?q=searchterm');
    });
  });

  describe('createWorkspace', () => {
    it('should call apiPost with the correct data', async () => {
      const mockWorkspace = { id: '2', name: 'New Workspace' };
      apiPost.mockResolvedValue({ data: { workspace: mockWorkspace } });

      const result = await createWorkspace('New Workspace');

      expect(apiPost).toHaveBeenCalledWith('/api/workspaces/', { name: 'New Workspace' });
      expect(result).toEqual(mockWorkspace);
    });
  });

  describe('acceptInvitation', () => {
    it('should call apiPost', async () => {
      const mockMember = { id: 'mem1', user: 'test' };
      apiPost.mockResolvedValue({ data: { member: mockMember } });
      const invitationId = 'inv1';
      
      const result = await acceptInvitation(invitationId);

      expect(apiPost).toHaveBeenCalledWith(`/api/invitations/${invitationId}/accept/`, {});
      expect(result).toEqual(mockMember);
    });
  });

  describe('declineInvitation', () => {
    it('should call apiPost', async () => {
      apiPost.mockResolvedValue({ data: { success: true } });
      const invitationId = 'inv1';

      await declineInvitation(invitationId);

      expect(apiPost).toHaveBeenCalledWith(`/api/invitations/${invitationId}/decline/`, {});
    });
  });

  describe('inviteUserToWorkspace', () => {
    it('should call apiPost with the correct data', async () => {
      const mockInvitation = { id: 'inv2', username: 'newuser' };
      apiPost.mockResolvedValue({ data: { invitation: mockInvitation } });
      const workspaceId = 'ws1';
      const username = 'newuser';
      const role = 'RESEARCHER';

      const result = await inviteUserToWorkspace(workspaceId, username, role);

      expect(apiPost).toHaveBeenCalledWith(`/api/workspaces/${workspaceId}/invite/`, { username, role });
      expect(result).toEqual({ data: { invitation: mockInvitation } });
    });

    it('inviteUserToWorkspace should throw an error if response contains error', async () => {
        apiPost.mockResolvedValue({ error: 'User not found' });
        await expect(inviteUserToWorkspace('ws1', 'ghost')).rejects.toThrow('User not found');
    });
  });
});


