import { getCookie, getCsrfToken, initializeCsrfToken } from '@/utils/csrf';


import { vi } from 'vitest';
describe('utils/csrf - Extended Coverage', () => {
  beforeEach(() => {
    // Reset document.cookie
    Object.defineProperty(document, 'cookie', {
      writable: true,
      value: '',
    });
    vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.spyOn(console, 'warn').mockImplementation(() => {});
  });

  afterEach(() => {
    console.error.mockRestore();
    console.warn.mockRestore();
    vi.restoreAllMocks();
  });

  describe('getCookie', () => {
    it('should handle empty document.cookie', () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: '',
      });
      expect(getCookie('csrftoken')).toBeNull();
    });

    it('should handle multiple cookies and find the right one', () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'session=abc; csrftoken=test-token; user=john',
      });
      expect(getCookie('csrftoken')).toBe('test-token');
    });

    it('should decode URI encoded cookie values', () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'csrftoken=test%20token%20value',
      });
      expect(getCookie('csrftoken')).toBe('test token value');
    });

    it('should return null if cookie is not found', () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'session=abc; user=john',
      });
      expect(getCookie('csrftoken')).toBeNull();
    });
  });

  describe('getCsrfToken with forceRefresh', () => {
    it('should fetch from server when forceRefresh is true', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'csrftoken=old-token',
      });

      global.fetch = vi.fn().mockResolvedValue({
        ok: true,
        json: () => Promise.resolve({ data: { csrf_token: 'new-token' } }),
      });

      const token = await getCsrfToken(true);
      expect(token).toBe('new-token');
      expect(global.fetch).toHaveBeenCalled();
    });

    it('should handle fetch errors and fallback to cookie', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'csrftoken=fallback-token',
      });

      global.fetch = vi.fn().mockRejectedValue(new Error('Network error'));

      const token = await getCsrfToken(true);
      expect(token).toBe('fallback-token');
      expect(console.error).toHaveBeenCalledWith(
        'Error fetching CSRF token:',
        expect.any(Error)
      );
    });

    it('should handle non-ok response status', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'csrftoken=fallback-token',
      });

      global.fetch = vi.fn().mockResolvedValue({
        ok: false,
        statusText: 'Internal Server Error',
      });

      const token = await getCsrfToken(true);
      expect(token).toBe('fallback-token');
      expect(console.error).toHaveBeenCalled();
    });

    it('should return empty string if no cookie and fetch fails', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: '',
      });

      global.fetch = vi.fn().mockRejectedValue(new Error('Network error'));

      const token = await getCsrfToken(true);
      expect(token).toBe('');
    });
  });

  describe('initializeCsrfToken', () => {
    it('should call getCsrfToken and handle success', async () => {
      Object.defineProperty(document, 'cookie', {
        writable: true,
        value: 'csrftoken=test-token',
      });

      await initializeCsrfToken();
      // Should not throw and should not warn
      expect(console.warn).not.toHaveBeenCalled();
    });
  });
});


