import { describe, it, expect } from 'vitest';
import { parseMentions, renderMessageWithMentions } from '../utils/mentions';

describe('utils/mentions - Comprehensive Mutation Coverage', () => {
  describe('parseMentions', () => {
    it('should return empty array for text without mentions', () => {
      const result = parseMentions('Hello world');
      expect(result).toEqual([]);
      expect(result.length).toBe(0);
    });

    it('should parse single mention', () => {
      const result = parseMentions('Hello @user123');
      expect(result).toHaveLength(1);
      expect(result[0].username).toBe('user123');
      expect(result[0].fullMatch).toBe('@user123');
    });

    it('should parse multiple mentions', () => {
      const result = parseMentions('@alice Hey @bob and @charlie');
      expect(result).toHaveLength(3);
      expect(result[0].username).toBe('alice');
      expect(result[1].username).toBe('bob');
      expect(result[2].username).toBe('charlie');
    });

    it('should capture correct start position', () => {
      const result = parseMentions('Hey @user');
      expect(result[0].start).toBe(4);
    });

    it('should capture correct end position', () => {
      const result = parseMentions('Hey @user');
      expect(result[0].end).toBe(9);
    });

    it('should calculate end as start + fullMatch length', () => {
      const result = parseMentions('@username');
      expect(result[0].end).toBe(result[0].start + result[0].fullMatch.length);
    });

    it('should match usernames with letters, numbers, and underscores', () => {
      const result = parseMentions('@user_123_ABC');
      expect(result[0].username).toBe('user_123_ABC');
    });

    it('should not match mentions with hyphens', () => {
      const result = parseMentions('@user-name');
      expect(result[0].username).toBe('user');
    });

    it('should not match mentions with special characters', () => {
      const result = parseMentions('@user@domain');
      expect(result).toHaveLength(2);
      expect(result[0].username).toBe('user');
      expect(result[1].username).toBe('domain');
    });

    it('should handle mention at start of string', () => {
      const result = parseMentions('@first text');
      expect(result[0].start).toBe(0);
      expect(result[0].username).toBe('first');
    });

    it('should handle mention at end of string', () => {
      const result = parseMentions('text @last');
      expect(result[0].username).toBe('last');
      expect(result[0].end).toBe(10);
    });

    it('should handle consecutive mentions', () => {
      const result = parseMentions('@alice@bob');
      expect(result).toHaveLength(2);
      expect(result[0].username).toBe('alice');
      expect(result[1].username).toBe('bob');
    });

    it('should include @ in fullMatch', () => {
      const result = parseMentions('@user');
      expect(result[0].fullMatch).toContain('@');
      expect(result[0].fullMatch[0]).toBe('@');
    });

    it('should use regex with global flag', () => {
      const result = parseMentions('@a @b @c');
      expect(result).toHaveLength(3);
    });

    it('should handle empty string', () => {
      const result = parseMentions('');
      expect(result).toEqual([]);
    });

    it('should handle @ without username', () => {
      const result = parseMentions('Email: test@');
      expect(result).toEqual([]);
    });

    it('should capture uppercase letters', () => {
      const result = parseMentions('@USER');
      expect(result[0].username).toBe('USER');
    });

    it('should capture lowercase letters', () => {
      const result = parseMentions('@user');
      expect(result[0].username).toBe('user');
    });

    it('should capture numbers in username', () => {
      const result = parseMentions('@user123');
      expect(result[0].username).toBe('user123');
    });

    it('should capture underscores in username', () => {
      const result = parseMentions('@user_name');
      expect(result[0].username).toBe('user_name');
    });

    it('should stop at space', () => {
      const result = parseMentions('@user hello');
      expect(result[0].username).toBe('user');
      expect(result[0].fullMatch).toBe('@user');
    });

    it('should stop at punctuation', () => {
      const result = parseMentions('@user, hello');
      expect(result[0].username).toBe('user');
    });

    it('should match only valid username characters [A-Za-z0-9_]', () => {
      const result = parseMentions('@user!name');
      expect(result[0].username).toBe('user');
    });

    it('should push mention object with all required properties', () => {
      const result = parseMentions('@test');
      expect(result[0]).toHaveProperty('username');
      expect(result[0]).toHaveProperty('start');
      expect(result[0]).toHaveProperty('end');
      expect(result[0]).toHaveProperty('fullMatch');
    });

    it('should use while loop to find all matches', () => {
      const result = parseMentions('@a @b @c @d @e');
      expect(result.length).toBe(5);
    });

    it('should use regex.exec() method', () => {
      const result = parseMentions('@mention');
      expect(result[0].username).toBe('mention');
    });

    it('should handle match[1] for captured group', () => {
      const result = parseMentions('@captured');
      expect(result[0].username).toBe('captured');
    });

    it('should use match.index for start position', () => {
      const text = '  @user';
      const result = parseMentions(text);
      expect(result[0].start).toBe(text.indexOf('@'));
    });

    it('should use match[0] for fullMatch', () => {
      const result = parseMentions('@fullmatch');
      expect(result[0].fullMatch).toBe('@fullmatch');
    });
  });

  describe('renderMessageWithMentions', () => {
    it('should return plain text when no mentions', () => {
      const result = renderMessageWithMentions('Hello world');
      expect(result).toBe('Hello world');
      expect(typeof result).toBe('string');
    });

    it('should return array with mention when mentions exist', () => {
      const result = renderMessageWithMentions('Hello @user');
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
    });

    it('should render mention as span element', () => {
      const result = renderMessageWithMentions('@user');
      expect(result[0].type).toBe('span');
    });

    it('should apply accent color to mention span', () => {
      const result = renderMessageWithMentions('@user');
      expect(result[0].props.style.color).toBe('var(--accent-color)');
    });

    it('should apply fontWeight 500 to mention span', () => {
      const result = renderMessageWithMentions('@user');
      expect(result[0].props.style.fontWeight).toBe(500);
    });

    it('should include text before mention', () => {
      const result = renderMessageWithMentions('Hello @user');
      expect(result[0]).toBe('Hello ');
    });

    it('should include text after mention', () => {
      const result = renderMessageWithMentions('@user hello');
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
    });

    it('should handle multiple mentions with text between', () => {
      const result = renderMessageWithMentions('@alice and @bob');
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(1);
      const spans = result.filter(p => p?.type === 'span');
      expect(spans.length).toBe(2);
    });

    it('should use unique keys for mention spans', () => {
      const result = renderMessageWithMentions('@alice @bob');
      expect(result[0].key).toBe('mention-0');
      expect(result[2].key).toBe('mention-1');
    });

    it('should handle mention at start', () => {
      const result = renderMessageWithMentions('@start text');
      expect(result[0].type).toBe('span');
      expect(result[1]).toBe(' text');
    });

    it('should handle mention at end', () => {
      const result = renderMessageWithMentions('text @end');
      expect(result[0]).toBe('text ');
      expect(result[1].type).toBe('span');
    });

    it('should check mentions.length === 0', () => {
      const result = renderMessageWithMentions('no mentions');
      expect(result).toBe('no mentions');
    });

    it('should check mention.start > lastIndex', () => {
      const result = renderMessageWithMentions('a @b');
      expect(result[0]).toBe('a ');
    });

    it('should update lastIndex to mention.end', () => {
      const result = renderMessageWithMentions('@user and more');
      expect(result[1]).toBe(' and more');
    });

    it('should check lastIndex < text.length', () => {
      const result = renderMessageWithMentions('@user end');
      expect(result[1]).toBe(' end');
    });

    it('should use substring(lastIndex, mention.start)', () => {
      const result = renderMessageWithMentions('text @mention');
      expect(result[0]).toBe('text ');
    });

    it('should use substring(lastIndex)', () => {
      const result = renderMessageWithMentions('@mention text');
      expect(result[1]).toBe(' text');
    });

    it('should forEach over mentions array', () => {
      const result = renderMessageWithMentions('@a @b @c');
      const spanCount = result.filter(part => part.type === 'span').length;
      expect(spanCount).toBe(3);
    });

    it('should pass mention index to key', () => {
      const result = renderMessageWithMentions('@a @b');
      expect(result[0].key).toContain('0');
      expect(result[2].key).toContain('1');
    });

    it('should render fullMatch inside span', () => {
      const result = renderMessageWithMentions('@username');
      expect(result[0].props.children).toBe('@username');
    });

    it('should initialize parts as empty array', () => {
      const result = renderMessageWithMentions('@test');
      expect(Array.isArray(result)).toBe(true);
    });

    it('should initialize lastIndex to 0', () => {
      const result = renderMessageWithMentions('@start');
      expect(result[0].type).toBe('span');
    });

    it('should call parseMentions', () => {
      const result = renderMessageWithMentions('@test');
      expect(result.length).toBeGreaterThan(0);
    });

    it('should return early if no mentions', () => {
      const text = 'no mentions here';
      const result = renderMessageWithMentions(text);
      expect(result).toBe(text);
    });

    it('should handle mention only text', () => {
      const result = renderMessageWithMentions('@only');
      expect(result.length).toBe(1);
      expect(result[0].type).toBe('span');
    });

    it('should handle multiple consecutive mentions', () => {
      const result = renderMessageWithMentions('@a@b@c');
      const spans = result.filter(p => p.type === 'span');
      expect(spans.length).toBe(3);
    });

    it('should append text after last mention', () => {
      const result = renderMessageWithMentions('@user goodbye');
      const lastPart = result[result.length - 1];
      expect(lastPart).toBe(' goodbye');
    });

    it('should use CSS variable for color', () => {
      const result = renderMessageWithMentions('@user');
      expect(result[0].props.style.color).toContain('var(');
    });

    it('should use numeric fontWeight value', () => {
      const result = renderMessageWithMentions('@user');
      expect(typeof result[0].props.style.fontWeight).toBe('number');
    });
  });

  describe('Integration tests', () => {
    it('should handle complex message with multiple patterns', () => {
      const text = 'Hi @alice, can you review @bob\'s PR? CC: @charlie';
      const parsed = parseMentions(text);
      expect(parsed.length).toBe(3);
      
      const rendered = renderMessageWithMentions(text);
      expect(Array.isArray(rendered)).toBe(true);
      const spanCount = rendered.filter(p => p?.type === 'span').length;
      expect(spanCount).toBe(3);
    });

    it('should maintain text order when rendering', () => {
      const result = renderMessageWithMentions('A @b C @d E');
      expect(result[0]).toBe('A ');
      expect(result[1].props.children).toBe('@b');
      expect(result[2]).toBe(' C ');
      expect(result[3].props.children).toBe('@d');
      expect(result[4]).toBe(' E');
    });
  });
});
