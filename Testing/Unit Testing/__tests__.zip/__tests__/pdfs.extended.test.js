import { vi } from 'vitest';
import { uploadPdf, deletePdf, getPdfUrl } from '@/api/pdfs';

import { getCsrfToken } from '@/utils/csrf';

import { API_BASE_URL } from '@/api/config';


// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Mock config module
vi.mock('@/api/config', () => ({
  API_BASE_URL: 'http://localhost:8000'
}));

describe('api/pdfs - Extended Coverage', () => {
  const csrfToken = 'test-csrf-token';
  const workspaceId = 'ws1';
  const pdfId = 'pdf1';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  describe('uploadPdf - Error Handling', () => {
    it('should handle CSRF error with detail field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.resolve({ detail: 'CSRF verification failed' }),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle CSRF error with message field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.resolve({ message: 'CSRF token missing' }),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle 403 error without JSON response', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle error with detail field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ detail: 'Invalid file format' }),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow('Invalid file format');
    });

    it('should handle error with message field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ message: 'File too large' }),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow('File too large');
    });

    it('should use statusText for non-JSON error responses', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      
      await expect(uploadPdf(workspaceId, file, 'Test')).rejects.toThrow(
        'Failed to upload PDF: Internal Server Error'
      );
    });
  });

  describe('deletePdf - Error Handling', () => {
    it('should handle CSRF error with detail field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.resolve({ detail: 'CSRF verification failed' }),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle CSRF error with message field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.resolve({ message: 'CSRF token invalid' }),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle 403 error without JSON response', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow(
        'CSRF verification failed. Please refresh the page and try again.'
      );
    });

    it('should handle error with detail field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
        json: () => Promise.resolve({ detail: 'PDF not found' }),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow('PDF not found');
    });

    it('should handle error with message field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 403,
        statusText: 'Forbidden',
        json: () => Promise.resolve({ message: 'No permission' }),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow(
        'No permission'
      );
    });

    it('should handle error with error field', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 400,
        statusText: 'Bad Request',
        json: () => Promise.resolve({ error: 'Invalid request' }),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow('Invalid request');
    });

    it('should use statusText for non-JSON error responses', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        status: 500,
        statusText: 'Internal Server Error',
        json: () => Promise.reject(new Error('Not JSON')),
      });

      await expect(deletePdf(pdfId)).rejects.toThrow(
        'Failed to delete PDF: Internal Server Error'
      );
    });
  });

  describe('getPdfUrl - Error Handling', () => {
    it('should throw an error when fetch fails', async () => {
      mockFetch.mockResolvedValue({
        ok: false,
        statusText: 'Not Found',
      });

      await expect(getPdfUrl(pdfId)).rejects.toThrow('Failed to fetch PDF: Not Found');
    });
  });
});


