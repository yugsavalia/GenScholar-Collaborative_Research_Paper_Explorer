import { vi } from 'vitest';
import { askChatbot } from '@/api/chatbot';

import { getCsrfToken } from '@/utils/csrf';

import { act } from 'react';

vi.mock('@/api/config');

// Mock dependencies
vi.mock('@/utils/csrf', () => ({
  getCsrfToken: vi.fn(),
}));

// Mock global fetch
const mockFetch = vi.fn();
global.fetch = mockFetch;

// Use fake timers for timeout tests
vi.useFakeTimers();

describe('api/chatbot', () => {
  const workspaceId = 'ws1';
  const question = 'What is the meaning of life?';
  const csrfToken = 'test-csrf-token';

  beforeEach(() => {
    vi.clearAllMocks();
    getCsrfToken.mockResolvedValue(csrfToken);
  });

  it('should send a question and return a successful response', async () => {
    const mockResponse = {
      status: 'ok',
      user_question: question,
      ai_answer: '42',
    };
    mockFetch.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    const result = await askChatbot(workspaceId, question);

    expect(getCsrfToken).toHaveBeenCalledTimes(1);
    expect(mockFetch).toHaveBeenCalledWith(
      expect.stringContaining('/api/chatbot/ask/'),
      expect.objectContaining({
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({
          question: question,
          workspace_id: workspaceId,
        }),
      })
    );
    expect(result).toEqual({
      user_question: question,
      ai_answer: '42',
    });
  });

  it('should throw an error if the fetch response is not ok', async () => {
    const errorResponse = { error: 'Something went wrong' };
    mockFetch.mockResolvedValue({
      ok: false,
      status: 500,
      statusText: 'Server Error',
      json: () => Promise.resolve(errorResponse),
    });

    await expect(askChatbot(workspaceId, question)).rejects.toThrow('Something went wrong');
  });

  it('should throw a specific CSRF error message on 403 failure', async () => {
    const errorResponse = { detail: 'CSRF Failed' };
    mockFetch.mockResolvedValue({
      ok: false,
      status: 403,
      statusText: 'Forbidden',
      json: () => Promise.resolve(errorResponse),
    });

    await expect(askChatbot(workspaceId, question)).rejects.toThrow(
      'CSRF verification failed. Please refresh the page and try again.'
    );
  });

  it('should throw an error if the response contains an error field', async () => {
    const errorResponse = { error: 'Invalid question' };
    mockFetch.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(errorResponse),
    });

    await expect(askChatbot(workspaceId, question)).rejects.toThrow('Invalid question');
  });

  it.skip('should throw a timeout error if the request takes too long', async (done) => {
    // Make fetch never resolve
    mockFetch.mockReturnValue(new Promise(() => {}));

    try {
      const askPromise = askChatbot(workspaceId, question);
      jest.runAllTimers();
      await askPromise;
    } catch (error) {
      expect(error.message).toBe(
        'Request timed out. The AI is taking too long to respond. Please try again with a simpler question.'
      );
      done();
    }
  }, 100000);

  it('should clear the timeout if the request completes successfully', async () => {
    const clearTimeoutSpy = vi.spyOn(global, 'clearTimeout');
    const mockResponse = { status: 'ok', ai_answer: '42' };
    mockFetch.mockResolvedValue({
      ok: true,
      json: () => Promise.resolve(mockResponse),
    });

    await askChatbot(workspaceId, question);

    // The timeout is set and then cleared upon successful fetch.
    expect(clearTimeoutSpy).toHaveBeenCalledTimes(1);
    clearTimeoutSpy.mockRestore();
  });
});


