import { describe, test, expect } from 'vitest';
import { parseMentions, renderMessageWithMentions } from '@/utils/mentions';

describe('mentions utilities comprehensive coverage', () => {
  describe('parseMentions', () => {
    test('should parse single mention', () => {
      const text = 'Hello @john';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].username).toBe('john');
      expect(mentions[0].start).toBe(6);
      expect(mentions[0].end).toBe(11);
      expect(mentions[0].fullMatch).toBe('@john');
    });

    test('should parse multiple mentions', () => {
      const text = 'Hey @john and @jane';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(2);
      expect(mentions[0].username).toBe('john');
      expect(mentions[1].username).toBe('jane');
    });

    test('should handle mentions with underscores', () => {
      const text = 'Message for @user_name';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].username).toBe('user_name');
    });

    test('should handle mentions with numbers', () => {
      const text = '@user123 hello';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].username).toBe('user123');
    });

    test('should return empty array for no mentions', () => {
      const text = 'Hello world';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(0);
    });

    test('should handle @ without valid username', () => {
      const text = 'Email: test@example.com';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].username).toBe('example');
    });

    test('should handle mentions at start of string', () => {
      const text = '@admin please review';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].start).toBe(0);
    });

    test('should handle mentions at end of string', () => {
      const text = 'Thanks @helper';
      const mentions = parseMentions(text);
      
      expect(mentions).toHaveLength(1);
      expect(mentions[0].end).toBe(14);
    });
  });

  describe('renderMessageWithMentions', () => {
    test('should return plain string when no mentions', () => {
      const text = 'Hello world';
      const result = renderMessageWithMentions(text);
      
      expect(result).toBe('Hello world');
      expect(typeof result).toBe('string');
    });

    test('should render mention with styled span', () => {
      const text = 'Hello @john';
      const result = renderMessageWithMentions(text);
      
      expect(Array.isArray(result)).toBe(true);
      expect(result).toHaveLength(2);
      expect(result[0]).toBe('Hello ');
    });

    test('should render multiple mentions', () => {
      const text = '@john and @jane here';
      const result = renderMessageWithMentions(text);
      
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(2);
    });

    test('should handle text before mention', () => {
      const text = 'Hey @user';
      const result = renderMessageWithMentions(text);
      
      expect(result[0]).toBe('Hey ');
    });

    test('should handle text after mention', () => {
      const text = '@user hello';
      const result = renderMessageWithMentions(text);
      
      expect(result[result.length - 1]).toBe(' hello');
    });

    test('should handle consecutive mentions', () => {
      const text = '@user1@user2';
      const result = renderMessageWithMentions(text);
      
      expect(Array.isArray(result)).toBe(true);
    });

    test('should handle mention in middle of text', () => {
      const text = 'Hello @user welcome';
      const result = renderMessageWithMentions(text);
      
      expect(result[0]).toBe('Hello ');
      expect(result[result.length - 1]).toBe(' welcome');
    });
  });
});
