import { vi } from 'vitest';
import React from 'react';

import { render, screen } from '@testing-library/react';

import '@testing-library/jest-dom';

import Navbar from '@/components/Navbar';

import { useAuth } from '@/context/AuthContext';

import { MemoryRouter } from 'wouter';


// Mock the useAuth hook
vi.mock('@/context/AuthContext', () => ({
  useAuth: vi.fn(),
}));

// Mock the NotificationBell component
vi.mock('@/components/NotificationBell', () => ({ default: () => <div data-testid="notification-bell"></div> }));

describe('Navbar component', () => {
  const renderWithRouter = (ui, { route = '/' } = {}) => {
    window.history.pushState({}, 'Test page', route);
    return render(ui, { wrapper: MemoryRouter });
  };

  test('renders logo and title', () => {
    useAuth.mockReturnValue({ isAuthenticated: false });
    renderWithRouter(<Navbar />);
    expect(screen.getByAltText('GenScholar Logo')).toBeInTheDocument();
    expect(screen.getByText('GenScholar')).toBeInTheDocument();
  });

  test('does not show authenticated links when user is not logged in', () => {
    useAuth.mockReturnValue({ isAuthenticated: false });
    renderWithRouter(<Navbar />);
    expect(screen.queryByTestId('link-dashboard')).not.toBeInTheDocument();
    expect(screen.queryByTestId('link-contact')).not.toBeInTheDocument();
    expect(screen.queryByTestId('notification-bell')).not.toBeInTheDocument();
    expect(screen.queryByTestId('link-logout')).not.toBeInTheDocument();
  });

  test('shows authenticated links when user is logged in', () => {
    useAuth.mockReturnValue({ isAuthenticated: true });
    renderWithRouter(<Navbar />);
    expect(screen.getByTestId('link-dashboard')).toBeInTheDocument();
    expect(screen.getByTestId('link-contact')).toBeInTheDocument();
    expect(screen.getByTestId('notification-bell')).toBeInTheDocument();
    expect(screen.getByTestId('link-logout')).toBeInTheDocument();
  });

  test('navigates to the correct pages when links are clicked', () => {
    useAuth.mockReturnValue({ isAuthenticated: true });
    renderWithRouter(<Navbar />);
    
    expect(screen.getByTestId('link-home')).toHaveAttribute('href', '/');
    expect(screen.getByTestId('link-dashboard')).toHaveAttribute('href', '/dashboard');
    expect(screen.getByTestId('link-contact')).toHaveAttribute('href', '/contact');
    expect(screen.getByTestId('link-logout')).toHaveAttribute('href', '/logout');
  });

  test('shows profile link when authenticated', () => {
    useAuth.mockReturnValue({ isAuthenticated: true });
    renderWithRouter(<Navbar />);
    expect(screen.getByTestId('link-profile')).toBeInTheDocument();
    expect(screen.getByTestId('link-profile')).toHaveAttribute('href', '/profile');
  });

  test('shows theme toggle button when authenticated', () => {
    useAuth.mockReturnValue({ isAuthenticated: true });
    renderWithRouter(<Navbar />);
    expect(screen.getByLabelText('Toggle theme')).toBeInTheDocument();
  });

  test('theme toggle button shows correct icon', () => {
    useAuth.mockReturnValue({ isAuthenticated: true });
    renderWithRouter(<Navbar />);
    const themeButton = screen.getByLabelText('Toggle theme');
    expect(themeButton).toBeInTheDocument();
  });
});


