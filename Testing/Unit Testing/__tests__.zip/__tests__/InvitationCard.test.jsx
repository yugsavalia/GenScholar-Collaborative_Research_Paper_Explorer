import React from 'react';
import { vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import InvitationCard from '@/components/InvitationCard';

describe('InvitationCard component', () => {
  const mockInvitation = {
    id: 1,
    workspace: { name: 'Quantum Physics Research' },
    invited_by: { username: 'einstein@example.com' },
    role: 'RESEARCHER',
  };

  const handleAccept = vi.fn();
  const handleDecline = vi.fn();

  beforeEach(() => {
    render(
      <InvitationCard
        invitation={mockInvitation}
        onAccept={handleAccept}
        onDecline={handleDecline}
      />
    );
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  test('renders invitation details correctly', () => {
    expect(screen.getByText('Quantum Physics Research')).toBeInTheDocument();
    expect(screen.getByText('Invited by', { exact: false })).toBeInTheDocument();
    expect(screen.getByText('einstein@example.com')).toBeInTheDocument();
    expect(screen.getByText('as', { exact: false })).toBeInTheDocument();
    expect(screen.getByText('Researcher')).toBeInTheDocument();
  });

  test('calls onAccept when the accept button is clicked', async () => {
    const acceptButton = screen.getByRole('button', { name: 'Accept' });
    fireEvent.click(acceptButton);

    // Check for loading state
    expect(screen.getByText('Processing...')).toBeInTheDocument();
    
    await waitFor(() => {
      expect(handleAccept).toHaveBeenCalledWith(mockInvitation.id);
    });

    // Check if loading state is removed
    await waitFor(() => {
        expect(screen.queryByText('Processing...')).not.toBeInTheDocument();
    });
  });

  test('calls onDecline when the decline button is clicked', async () => {
    const declineButton = screen.getByRole('button', { name: 'Decline' });
    fireEvent.click(declineButton);

    // Check for loading state on the accept button
    expect(screen.getByText('Processing...')).toBeInTheDocument();

    await waitFor(() => {
      expect(handleDecline).toHaveBeenCalledWith(mockInvitation.id);
    });
    
    // Check if loading state is removed
    await waitFor(() => {
        expect(screen.queryByText('Processing...')).not.toBeInTheDocument();
    });
  });

  test('displays an error message if an action fails', async () => {
    const errorMessage = 'Something went wrong';
    handleAccept.mockRejectedValueOnce(new Error(errorMessage));

    const acceptButton = screen.getByRole('button', { name: 'Accept' });
    fireEvent.click(acceptButton);

    await waitFor(() => {
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });
  });

  test('disables buttons during processing', async () => {
    const acceptButton = screen.getByRole('button', { name: 'Accept' });
    const declineButton = screen.getByRole('button', { name: 'Decline' });

    fireEvent.click(acceptButton);

    await waitFor(() => {
      expect(acceptButton).toBeDisabled();
      expect(declineButton).toBeDisabled();
    });
  });

  test('displays an error message if decline action fails', async () => {
    const errorMessage = 'Failed to decline';
    handleDecline.mockRejectedValueOnce(new Error(errorMessage));

    const declineButton = screen.getByRole('button', { name: 'Decline' });
    fireEvent.click(declineButton);

    await waitFor(() => {
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });
  });
});


