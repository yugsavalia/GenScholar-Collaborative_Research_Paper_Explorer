import { describe, it, expect, beforeEach } from 'vitest';
import { initTheme, toggleTheme, getTheme } from '@/utils/theme';

// Mock localStorage
const localStorageMock = (() => {
  let store = {};
  return {
    getItem: (key) => store[key] || null,
    setItem: (key, value) => {
      store[key] = value.toString();
    },
    clear: () => {
      store = {};
    },
  };
})();

Object.defineProperty(global, 'localStorage', {
  value: localStorageMock,
  writable: true,
});

describe('utils/theme', () => {
  beforeEach(() => {
    // Reset localStorage
    localStorageMock.clear();
    
    // Reset document theme class
    document.documentElement.classList.remove('light-mode');
  });

  describe('initTheme', () => {
    it('should initialize with dark theme by default', () => {
      const theme = initTheme();
      expect(theme).toBe('dark');
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
    });

    it('should initialize with light theme from localStorage', () => {
      localStorageMock.setItem('theme', 'light');
      const theme = initTheme();
      expect(theme).toBe('light');
      expect(document.documentElement.classList.contains('light-mode')).toBe(true);
    });

    it('should initialize with dark theme from localStorage', () => {
      localStorageMock.setItem('theme', 'dark');
      const theme = initTheme();
      expect(theme).toBe('dark');
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
    });
  });

  describe('getTheme', () => {
    it('should return light when light-mode class is present', () => {
      document.documentElement.classList.add('light-mode');
      expect(getTheme()).toBe('light');
    });

    it('should return dark when light-mode class is absent', () => {
      document.documentElement.classList.remove('light-mode');
      expect(getTheme()).toBe('dark');
    });
  });

  describe('toggleTheme', () => {
    it('should toggle from dark to light', () => {
      document.documentElement.classList.remove('light-mode');
      
      const newTheme = toggleTheme();
      
      expect(newTheme).toBe('light');
      expect(document.documentElement.classList.contains('light-mode')).toBe(true);
      expect(localStorageMock.getItem('theme')).toBe('light');
    });

    it('should toggle from light to dark', () => {
      document.documentElement.classList.add('light-mode');
      
      const newTheme = toggleTheme();
      
      expect(newTheme).toBe('dark');
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
      expect(localStorageMock.getItem('theme')).toBe('dark');
    });

    it('should store theme in localStorage when toggling', () => {
      toggleTheme(); // dark -> light
      expect(localStorageMock.getItem('theme')).toBe('light');
      
      toggleTheme(); // light -> dark
      expect(localStorageMock.getItem('theme')).toBe('dark');
    });
  });

  describe('initTheme - else block coverage', () => {
    // Kill mutant: BlockStatement else block removal
    it('should explicitly remove light-mode class when theme is dark', () => {
      // Set up light mode first
      document.documentElement.classList.add('light-mode');
      localStorageMock.setItem('theme', 'dark');
      
      // Initialize with dark theme
      const theme = initTheme();
      
      // Verify else block executed: classList.remove was called
      expect(theme).toBe('dark');
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
    });

    it('should remove light-mode class when no theme saved', () => {
      // Add light-mode class
      document.documentElement.classList.add('light-mode');
      
      // Clear localStorage (defaults to dark)
      localStorageMock.clear();
      
      const theme = initTheme();
      
      // Should execute else block and remove light-mode
      expect(theme).toBe('dark');
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
    });

    it('should handle transition from light to dark correctly', () => {
      // Start with light mode
      document.documentElement.classList.add('light-mode');
      
      // Change to dark
      localStorageMock.setItem('theme', 'dark');
      initTheme();
      
      // Verify else block removed the class
      expect(document.documentElement.classList.contains('light-mode')).toBe(false);
    });
  });
});
