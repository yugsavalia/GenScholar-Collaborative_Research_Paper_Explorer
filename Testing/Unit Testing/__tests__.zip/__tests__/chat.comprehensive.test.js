import { describe, it, expect, vi, beforeEach } from 'vitest';
import { getMessages, sendMessage } from '../api/chat';
import * as client from '../api/client';

vi.mock('../api/client', () => ({
  apiGet: vi.fn(),
  apiPost: vi.fn(),
}));

describe('api/chat - Comprehensive Coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(console, 'log').mockImplementation(() => {});
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  describe('getMessages', () => {
    it('should fetch messages for a workspace', async () => {
      const mockMessages = [
        { id: 1, workspace: 1, user: { id: 1, username: 'user1' }, message: 'Hello', timestamp: '2025-01-01' }
      ];
      vi.mocked(client.apiGet).mockResolvedValue(mockMessages);

      const result = await getMessages(1);

      expect(client.apiGet).toHaveBeenCalledWith('/api/messages/?workspace_id=1');
      expect(result).toEqual(mockMessages);
    });

    it('should handle array response directly', async () => {
      const mockMessages = [{ id: 1, message: 'test' }];
      vi.mocked(client.apiGet).mockResolvedValue(mockMessages);

      const result = await getMessages(1);

      expect(Array.isArray(result)).toBe(true);
      expect(result).toEqual(mockMessages);
    });

    it('should extract results from paginated response', async () => {
      const mockMessages = [{ id: 1, message: 'test' }];
      vi.mocked(client.apiGet).mockResolvedValue({
        count: 1,
        next: null,
        previous: null,
        results: mockMessages
      });

      const result = await getMessages(1);

      expect(result).toEqual(mockMessages);
    });

    it('should extract data array from custom format', async () => {
      const mockMessages = [{ id: 1, message: 'test' }];
      vi.mocked(client.apiGet).mockResolvedValue({
        success: true,
        data: mockMessages
      });

      const result = await getMessages(1);

      expect(result).toEqual(mockMessages);
    });

    it('should return empty array for unexpected response format', async () => {
      vi.mocked(client.apiGet).mockResolvedValue({ unexpected: 'format' });

      const result = await getMessages(1);

      expect(result).toEqual([]);
    });

    it('should handle string workspace ID', async () => {
      vi.mocked(client.apiGet).mockResolvedValue([]);

      await getMessages('123');

      expect(client.apiGet).toHaveBeenCalledWith('/api/messages/?workspace_id=123');
    });

    it('should handle numeric workspace ID', async () => {
      vi.mocked(client.apiGet).mockResolvedValue([]);

      await getMessages(456);

      expect(client.apiGet).toHaveBeenCalledWith('/api/messages/?workspace_id=456');
    });

    it('should throw error when API call fails', async () => {
      const error = new Error('Network error');
      vi.mocked(client.apiGet).mockRejectedValue(error);

      await expect(getMessages(1)).rejects.toThrow('Network error');
    });

    it('should log response when it is an array', async () => {
      const consoleSpy = vi.spyOn(console, 'log');
      vi.mocked(client.apiGet).mockResolvedValue([{ id: 1 }]);

      await getMessages(1);

      expect(consoleSpy).toHaveBeenCalledWith('[Chat API] Response is array, returning directly');
    });

    it('should log when response has results array', async () => {
      const consoleSpy = vi.spyOn(console, 'log');
      vi.mocked(client.apiGet).mockResolvedValue({ results: [{ id: 1 }] });

      await getMessages(1);

      expect(consoleSpy).toHaveBeenCalledWith('[Chat API] Response has results array, returning results');
    });

    it('should log when response has data array', async () => {
      const consoleSpy = vi.spyOn(console, 'log');
      vi.mocked(client.apiGet).mockResolvedValue({ data: [{ id: 1 }] });

      await getMessages(1);

      expect(consoleSpy).toHaveBeenCalledWith('[Chat API] Response has data array, returning data');
    });

    it('should warn on unexpected response format', async () => {
      const consoleWarnSpy = vi.spyOn(console, 'warn');
      const unexpectedResponse = { unexpected: 'format' };
      vi.mocked(client.apiGet).mockResolvedValue(unexpectedResponse);

      await getMessages(1);

      expect(consoleWarnSpy).toHaveBeenCalledWith('[Chat API] Unexpected response format:', unexpectedResponse);
    });

    it('should log error when fetch fails', async () => {
      const consoleErrorSpy = vi.spyOn(console, 'error');
      const error = new Error('Fetch failed');
      vi.mocked(client.apiGet).mockRejectedValue(error);

      await expect(getMessages(1)).rejects.toThrow();

      expect(consoleErrorSpy).toHaveBeenCalledWith('[Chat API] Error fetching messages:', error);
    });
  });

  describe('sendMessage', () => {
    it('should send a message to workspace', async () => {
      const mockResponse = { id: 1, workspace: 1, message: 'Hello', timestamp: '2025-01-01' };
      vi.mocked(client.apiPost).mockResolvedValue(mockResponse);

      const result = await sendMessage(1, 'Hello');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 1,
        message: 'Hello'
      });
      expect(result).toEqual(mockResponse);
    });

    it('should trim message before sending', async () => {
      const mockResponse = { id: 1, message: 'Hello' };
      vi.mocked(client.apiPost).mockResolvedValue(mockResponse);

      await sendMessage(1, '  Hello  ');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 1,
        message: 'Hello'
      });
    });

    it('should handle string workspace ID', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ id: 1 });

      await sendMessage('123', 'test');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: '123',
        message: 'test'
      });
    });

    it('should handle numeric workspace ID', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ id: 1 });

      await sendMessage(456, 'test');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 456,
        message: 'test'
      });
    });

    it('should return created message object from DRF', async () => {
      const created = { id: 5, workspace: 1, message: 'New', user: { id: 1 } };
      vi.mocked(client.apiPost).mockResolvedValue(created);

      const result = await sendMessage(1, 'New');

      expect(result).toEqual(created);
    });

    it('should throw error when API call fails', async () => {
      vi.mocked(client.apiPost).mockRejectedValue(new Error('Send failed'));

      await expect(sendMessage(1, 'test')).rejects.toThrow('Send failed');
    });

    it('should handle empty message after trim', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ id: 1 });

      await sendMessage(1, '   ');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 1,
        message: ''
      });
    });

    it('should handle multiline messages', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ id: 1 });

      await sendMessage(1, 'Line 1\nLine 2\nLine 3');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 1,
        message: 'Line 1\nLine 2\nLine 3'
      });
    });

    it('should handle special characters in message', async () => {
      vi.mocked(client.apiPost).mockResolvedValue({ id: 1 });

      await sendMessage(1, 'Test @mention #hashtag $special &chars');

      expect(client.apiPost).toHaveBeenCalledWith('/api/messages/', {
        workspace: 1,
        message: 'Test @mention #hashtag $special &chars'
      });
    });
  });
});
