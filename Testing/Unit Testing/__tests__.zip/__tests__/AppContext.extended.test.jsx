import { vi } from 'vitest';
import { render, screen, act } from '@testing-library/react';

import { AppProvider, AppContext } from '@/context/AppContext';

import * as workspaceApi from '@/api/workspaces';

import * as pdfApi from '@/api/pdfs';

import * as threadApi from '@/api/threads';


vi.mock('@/api/workspaces', () => ({
  getWorkspaces: vi.fn(),
  createWorkspace: vi.fn(),
  deleteWorkspace: vi.fn().mockResolvedValue({}),
  getWorkspaceMembers: vi.fn(),
  inviteUserToWorkspace: vi.fn(),
  updateMemberRole: vi.fn(),
  getPendingInvitations: vi.fn(),
  acceptInvitation: vi.fn(),
  declineInvitation: vi.fn(),
  getNotifications: vi.fn(),
  markNotificationRead: vi.fn(),
}));

vi.mock('@/api/pdfs', () => ({
  getPdfs: vi.fn(),
  uploadPdf: vi.fn(),
  getPdfUrl: vi.fn(),
}));

vi.mock('@/api/threads', () => ({
  getThreads: vi.fn(),
  createThread: vi.fn(),
}));

const mockWorkspaces = [
  { id: 1, name: 'Workspace 1', created_at: new Date().toISOString() },
  { id: 2, name: 'Workspace 2', created_at: new Date().toISOString() },
];

describe('AppContext Extended', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    workspaceApi.getWorkspaces.mockResolvedValue(mockWorkspaces);
    workspaceApi.getPendingInvitations.mockResolvedValue([]);
    workspaceApi.getNotifications.mockResolvedValue({ notifications: [], unread_count: 0 });
  });

  it('should delete a workspace from state', async () => {
    let contextValue;
    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await act(async () => {
      await new Promise(resolve => setTimeout(resolve, 0)); // Wait for state updates
    });

    expect(contextValue.workspaces.length).toBe(2);

    await act(async () => {
      await contextValue.deleteWorkspace('1');
    });

    expect(contextValue.workspaces.length).toBe(1);
    expect(contextValue.workspaces[0].id).toBe('2');
  });

  it('should handle error when creating a workspace', async () => {
    const error = new Error('Failed to create');
    workspaceApi.createWorkspace.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.createWorkspace('New WS')).rejects.toThrow('Failed to create');
  });

  it('should handle error when fetching PDFs', async () => {
    const error = new Error('PDF fetch failed');
    pdfApi.getPdfs.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    const pdfs = await contextValue.getPdfs('1');
    expect(pdfs).toEqual([]);
  });

  it('should handle error when adding a PDF', async () => {
    const error = new Error('Upload failed');
    pdfApi.uploadPdf.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.addPdf('1', new File([], 'test.pdf'))).rejects.toThrow('Upload failed');
  });

  it('should handle error when loading workspace members', async () => {
    const error = new Error('Members load failed');
    workspaceApi.getWorkspaceMembers.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.loadWorkspaceMembers('1', 'user1')).rejects.toThrow('Members load failed');
  });

  it('should handle error when inviting a user', async () => {
    const error = new Error('Invite failed');
    workspaceApi.inviteUserToWorkspace.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.inviteUser('1', 'user2', 'viewer')).rejects.toThrow('Invite failed');
  });

  it('should handle error when changing member role', async () => {
    const error = new Error('Role change failed');
    workspaceApi.updateMemberRole.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.changeMemberRole('1', 'mem1', 'editor')).rejects.toThrow('Role change failed');
  });

  it('should handle error when loading invitations', async () => {
    const error = new Error('Invitations load failed');
    workspaceApi.getPendingInvitations.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.loadInvitations()).rejects.toThrow('Invitations load failed');
  });

  it('should handle error when accepting an invitation', async () => {
    const error = new Error('Accept failed');
    workspaceApi.acceptInvitation.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.handleAcceptInvitation('inv1')).rejects.toThrow('Accept failed');
  });

  it('should handle error when declining an invitation', async () => {
    const error = new Error('Decline failed');
    workspaceApi.declineInvitation.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.handleDeclineInvitation('inv1')).rejects.toThrow('Decline failed');
  });

  it('should handle error when loading notifications', async () => {
    const error = new Error('Notifications load failed');
    workspaceApi.getNotifications.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.loadNotifications()).rejects.toThrow('Notifications load failed');
  });

  it('should handle error when marking notification as read', async () => {
    const error = new Error('Mark read failed');
    workspaceApi.markNotificationRead.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.handleMarkNotificationRead('notif1')).rejects.toThrow('Mark read failed');
  });

  it('should handle error when fetching threads', async () => {
    const error = new Error('Threads fetch failed');
    threadApi.getThreads.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    const threads = await contextValue.getThreads('1', 'pdf1');
    expect(threads).toEqual([]);
  });

  it('should handle error when creating a thread', async () => {
    const error = new Error('Thread create failed');
    threadApi.createThread.mockRejectedValue(error);
    let contextValue;

    render(
      <AppProvider>
        <AppContext.Consumer>
          {(value) => {
            contextValue = value;
            return null;
          }}
        </AppContext.Consumer>
      </AppProvider>
    );

    await expect(contextValue.createThread('1', 'pdf1', {})).rejects.toThrow('Thread create failed');
  });
});


