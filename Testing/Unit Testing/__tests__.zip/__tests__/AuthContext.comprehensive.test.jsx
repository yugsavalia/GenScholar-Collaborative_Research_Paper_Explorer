import { describe, test, expect, vi, beforeEach } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import React from 'react';

// Mock storage
vi.mock('@/utils/storage', () => ({
  storage: {
    get: vi.fn(),
    set: vi.fn(),
    remove: vi.fn()
  }
}));

// Mock auth API
vi.mock('@/api/auth', () => ({
  login: vi.fn(),
  logout: vi.fn(),
  signup: vi.fn(),
  getCurrentUser: vi.fn()
}));

import { storage } from '@/utils/storage';
import * as authAPI from '@/api/auth';

describe('AuthContext comprehensive coverage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    storage.get.mockReturnValue(null);
  });

  test('should provide auth context', () => {
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    expect(result.current).toBeDefined();
    expect(result.current).toHaveProperty('user');
    expect(result.current).toHaveProperty('login');
    expect(result.current).toHaveProperty('logout');
    expect(result.current).toHaveProperty('signup');
  });

  test('should throw error when useAuth used outside provider', () => {
    // Suppress console.error for this test
    const consoleError = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    expect(() => {
      renderHook(() => useAuth());
    }).toThrow('useAuth must be used within AuthProvider');
    
    consoleError.mockRestore();
  });

  test('should initialize with null user when no stored token', async () => {
    storage.get.mockReturnValue(null);
    authAPI.getCurrentUser.mockRejectedValue(new Error('Not authenticated'));
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
    
    expect(result.current.user).toBeNull();
  });

  test('should load user from token on mount', async () => {
    const mockUser = { id: 1, username: 'testuser' };
    storage.get.mockReturnValue('mock-token');
    authAPI.getCurrentUser.mockResolvedValue(mockUser);
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.user).toEqual(mockUser);
    });
  });

  test('should handle login success', async () => {
    const mockUser = { id: 1, username: 'testuser' };
    authAPI.getCurrentUser.mockRejectedValue(new Error('Not authenticated'));
    authAPI.login.mockResolvedValue(mockUser);
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
    
    await act(async () => {
      await result.current.login('testuser', 'password');
    });
    
    expect(authAPI.login).toHaveBeenCalledWith('testuser', 'password');
    expect(result.current.user).toEqual(mockUser);
  });

  test('should handle login failure', async () => {
    authAPI.login.mockRejectedValue(new Error('Invalid credentials'));
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await expect(async () => {
      await act(async () => {
        await result.current.login('testuser', 'wrongpassword');
      });
    }).rejects.toThrow('Invalid credentials');
  });

  test('should handle logout', async () => {
    const mockUser = { id: 1, username: 'testuser' };
    authAPI.getCurrentUser.mockResolvedValue(mockUser);
    authAPI.logout.mockResolvedValue({});
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.user).toEqual(mockUser);
    });
    
    await act(async () => {
      await result.current.logout();
    });
    
    expect(authAPI.logout).toHaveBeenCalled();
    expect(result.current.user).toBeNull();
  });

  test('should handle signup success', async () => {
    const mockUser = { id: 1, username: 'newuser' };
    authAPI.signup.mockResolvedValue(mockUser);
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
    
    await act(async () => {
      await result.current.signup('newuser', 'email@test.com', 'password', 'password', 'token123');
    });
    
    expect(authAPI.signup).toHaveBeenCalledWith('newuser', 'email@test.com', 'password', 'password', 'token123');
  });

  test('should handle signup failure', async () => {
    authAPI.signup.mockRejectedValue(new Error('Username already exists'));
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
    
    await expect(async () => {
      await act(async () => {
        await result.current.signup('existinguser', 'email@test.com', 'password', 'password', 'token');
      });
    }).rejects.toThrow('Username already exists');
  });

  test('should set loading to false after initialization', async () => {
    authAPI.getCurrentUser.mockRejectedValue(new Error('Not authenticated'));
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    const { result } = renderHook(() => useAuth(), { wrapper });
    
    // Initially loading
    expect(result.current.loading).toBe(true);
    
    // Should become false after auth check
    await waitFor(() => {
      expect(result.current.loading).toBe(false);
    });
  });

  test('should handle token refresh on mount', async () => {
    const mockUser = { id: 1, username: 'testuser' };
    storage.get.mockReturnValue('existing-token');
    authAPI.getCurrentUser.mockResolvedValue(mockUser);
    
    const wrapper = ({ children }) => <AuthProvider>{children}</AuthProvider>;
    renderHook(() => useAuth(), { wrapper });
    
    await waitFor(() => {
      expect(authAPI.getCurrentUser).toHaveBeenCalled();
    });
  });
});
