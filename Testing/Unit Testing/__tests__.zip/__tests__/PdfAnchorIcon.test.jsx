import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import '@testing-library/jest-dom';

import PdfAnchorIcon from '@/components/PdfAnchorIcon';


// Mock the Icon component
vi.mock('../Icon', () => ({ name, size, className }) => (
  <i data-testid={`icon-${name}`} className={className} style={{ fontSize: size }} />
));

describe('PdfAnchorIcon', () => {
  const mockOnClick = vi.fn();
  const defaultProps = {
    threadId: 123,
    pageNumber: 1,
    anchorRect: { x: 0.5, y: 0.5, width: 0.1, height: 0.1 },
    pageViewportSize: { width: 1000, height: 1000 },
    scale: 1,
    onClick: mockOnClick,
  };

  beforeEach(() => {
    mockOnClick.mockClear();
  });

  it('should not render if anchorRect is not provided', () => {
    render(<PdfAnchorIcon {...defaultProps} anchorRect={null} />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('should not render if pageViewportSize width is not provided', () => {
    render(<PdfAnchorIcon {...defaultProps} pageViewportSize={{ width: 0, height: 1000 }} />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('should render the icon and calculate position for anchorSide="right" (default)', () => {
    render(<PdfAnchorIcon {...defaultProps} />);

    const button = screen.getByRole('button', { name: 'Open thread' });
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute('data-testid', 'anchor-icon-thread-123');

    // Calculation for right side:
    // left = (anchorRect.x + anchorRect.width) * pageWidth + 10
    // left = (0.5 + 0.1) * 1000 * 1 + 10 = 610
    // top = anchorRect.y * pageHeight + (anchorRect.height * pageHeight) / 2
    // top = 0.5 * 1000 * 1 + (0.1 * 1000 * 1) / 2 = 500 + 50 = 550
    expect(button).toHaveStyle('left: 610px');
    expect(button).toHaveStyle('top: 550px');
  });

  it('should calculate position correctly when anchorSide is "left"', () => {
    render(<PdfAnchorIcon {...defaultProps} anchorSide="left" />);

    const button = screen.getByRole('button');
    // Calculation for left side:
    // left = anchorRect.x * pageWidth - 10
    // left = 0.5 * 1000 * 1 - 10 = 490
    // top remains the same: 550
    expect(button).toHaveStyle('left: 490px');
    expect(button).toHaveStyle('top: 550px');
  });

  it('should calculate position correctly with a different scale', () => {
    render(<PdfAnchorIcon {...defaultProps} scale={1.5} />);

    const button = screen.getByRole('button');
    // Calculation with scale:
    // pageWidth = 1000 * 1.5 = 1500
    // pageHeight = 1000 * 1.5 = 1500
    // left = (0.5 + 0.1) * 1500 + 10 = 0.6 * 1500 + 10 = 910
    // top = 0.5 * 1500 + (0.1 * 1500) / 2 = 750 + 75 = 825
    expect(button).toHaveStyle('left: 910px');
    expect(button).toHaveStyle('top: 825px');
  });

  it('should call the onClick handler when the button is clicked', () => {
    render(<PdfAnchorIcon {...defaultProps} />);
    const button = screen.getByRole('button');
    fireEvent.click(button);
    expect(mockOnClick).toHaveBeenCalledTimes(1);
  });

  it('should have correct accessibility attributes', () => {
    render(<PdfAnchorIcon {...defaultProps} />);
    const button = screen.getByRole('button');
    expect(button).toHaveAttribute('aria-label', 'Open thread');
    expect(button).toHaveAttribute('title', 'Open thread');
  });
});


