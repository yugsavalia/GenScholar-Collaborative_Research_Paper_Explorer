import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent } from '@testing-library/react';

import '@testing-library/jest-dom';

import PdfSidebar from '@/components/PdfSidebar';


// Mock child components
vi.mock('@/components/MainChat', () => ({ default: ({ workspaceId }) => <div data-testid="main-chat">Main Chat for {workspaceId}</div> }));
vi.mock('@/components/ThreadedDiscussions', () => ({ default: ({ workspaceId, pdfId, selectedThreadId, onThreadSelect }) => (
  <div data-testid="threaded-discussions">Threaded Discussions for {workspaceId}</div>
) }));
vi.mock('@/components/ChatbotPanel', () => ({ default: ({ workspaceId }) => <div data-testid="chatbot-panel">Chatbot Panel for {workspaceId}</div> }));

describe('PdfSidebar', () => {
  const defaultProps = {
    workspaceId: 'ws1',
    pdfId: 'pdf1',
    selectedAnnotation: null,
    userRole: 'RESEARCHER',
    selectedThreadId: null,
    onThreadSelect: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render Main Chat by default for a non-reviewer', () => {
    render(<PdfSidebar {...defaultProps} />);
    expect(screen.getByTestId('main-chat')).toBeInTheDocument();
    expect(screen.queryByTestId('threaded-discussions')).not.toBeInTheDocument();
    expect(screen.queryByTestId('chatbot-panel')).not.toBeInTheDocument();
    const mainTab = screen.getByTestId('button-tab-main');
    expect(mainTab).toBeInTheDocument();
  });

  it('should render all three tabs for a non-reviewer', () => {
    render(<PdfSidebar {...defaultProps} />);
    expect(screen.getByTestId('button-tab-main')).toBeInTheDocument();
    expect(screen.getByTestId('button-tab-threads')).toBeInTheDocument();
    expect(screen.getByTestId('button-tab-bot')).toBeInTheDocument();
  });

  it('should switch to the Threaded Discussions tab when clicked', () => {
    render(<PdfSidebar {...defaultProps} />);
    const threadsTabButton = screen.getByTestId('button-tab-threads');
    fireEvent.click(threadsTabButton);

    expect(screen.queryByTestId('main-chat')).not.toBeInTheDocument();
    expect(screen.getByTestId('threaded-discussions')).toBeInTheDocument();
    expect(threadsTabButton).toBeInTheDocument();
  });

  it('should switch to the AI ChatBot tab when clicked', () => {
    render(<PdfSidebar {...defaultProps} />);
    const botTabButton = screen.getByTestId('button-tab-bot');
    fireEvent.click(botTabButton);

    expect(screen.queryByTestId('main-chat')).not.toBeInTheDocument();
    expect(screen.getByTestId('chatbot-panel')).toBeInTheDocument();
    expect(botTabButton).toBeInTheDocument();
  });

  it('should automatically switch to the threads tab when a thread is selected', () => {
    const { rerender } = render(<PdfSidebar {...defaultProps} />);
    expect(screen.getByTestId('main-chat')).toBeInTheDocument();

    // Simulate selecting a thread
    rerender(<PdfSidebar {...defaultProps} selectedThreadId="thread1" />);

    expect(screen.queryByTestId('main-chat')).not.toBeInTheDocument();
    expect(screen.getByTestId('threaded-discussions')).toBeInTheDocument();
    expect(screen.getByTestId('button-tab-threads')).toBeInTheDocument();
  });

  describe('for REVIEWER role', () => {
    const reviewerProps = { ...defaultProps, userRole: 'REVIEWER' };

    it('should only render the Main Chat tab and content', () => {
      render(<PdfSidebar {...reviewerProps} />);
      expect(screen.getByTestId('button-tab-main')).toBeInTheDocument();
      expect(screen.queryByTestId('button-tab-threads')).not.toBeInTheDocument();
      expect(screen.queryByTestId('button-tab-bot')).not.toBeInTheDocument();
      expect(screen.getByTestId('main-chat')).toBeInTheDocument();
    });

    it('should display an info icon next to the Main Chat tab', () => {
      render(<PdfSidebar {...reviewerProps} />);
      expect(screen.getByTitle('Reviewers can only access Main Chat')).toBeInTheDocument();
    });

    it('should not switch to threads tab even if a thread ID is passed', () => {
      render(<PdfSidebar {...reviewerProps} selectedThreadId="thread1" />);
      // Should remain on main chat
      expect(screen.getByTestId('main-chat')).toBeInTheDocument();
      expect(screen.queryByTestId('threaded-discussions')).not.toBeInTheDocument();
    });

    it('should prevent switching away from main chat if somehow attempted', () => {
      const { rerender } = render(<PdfSidebar {...reviewerProps} />);
      
      // This state shouldn't be possible via the UI, but we test the logic's robustness
      // @ts-ignore - We are forcing an invalid state for testing
      rerender(<PdfSidebar {...reviewerProps} activeTab="threads" />);

      // The component should correct itself and only show the main chat
      expect(screen.getByTestId('main-chat')).toBeInTheDocument();
      expect(screen.queryByTestId('threaded-discussions')).not.toBeInTheDocument();
    });

    it('should ignore selectedThreadId for reviewers', () => {
      // Rerender with a thread selected, but reviewer shouldn't switch tabs
      render(<PdfSidebar {...reviewerProps} selectedThreadId="thread1" />);
      expect(screen.getByTestId('main-chat')).toBeInTheDocument();
      expect(screen.queryByTestId('threaded-discussions')).not.toBeInTheDocument();
    });
  });

  describe('tab switching interactions', () => {
    it('should not allow reviewers to click on non-existent restricted tabs', () => {
      const reviewerProps = { ...defaultProps, userRole: 'REVIEWER' };
      render(<PdfSidebar {...reviewerProps} />);
      
      // Verify only main tab exists
      expect(screen.getByTestId('button-tab-main')).toBeInTheDocument();
      expect(screen.queryByTestId('button-tab-threads')).not.toBeInTheDocument();
      expect(screen.queryByTestId('button-tab-bot')).not.toBeInTheDocument();
    });

    it('should maintain selected tab when non-reviewer switches tabs', () => {
      render(<PdfSidebar {...defaultProps} />);
      
      // Switch to bot
      fireEvent.click(screen.getByTestId('button-tab-bot'));
      expect(screen.getByTestId('chatbot-panel')).toBeInTheDocument();
      
      // Switch back to main
      fireEvent.click(screen.getByTestId('button-tab-main'));
      expect(screen.getByTestId('main-chat')).toBeInTheDocument();
    });
  });
});


