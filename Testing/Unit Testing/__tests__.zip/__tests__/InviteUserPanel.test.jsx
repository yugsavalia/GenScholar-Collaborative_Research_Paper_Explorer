import { vi } from 'vitest';
import React from 'react';

import { render, screen, fireEvent, waitFor } from '@testing-library/react';

import { act } from 'react-dom/test-utils';

import '@testing-library/jest-dom';

import InviteUserPanel from '@/components/InviteUserPanel';

import { inviteUserToWorkspace } from '@/api/workspaces';


// Mock the API function
vi.mock('@/api/workspaces', () => ({
  inviteUserToWorkspace: vi.fn(),
}));

// Mock child components
vi.mock('@/components/Button', () => ({
  default: ({ children, onClick, disabled }) => (
    <button onClick={onClick} disabled={disabled}>
      {children}
    </button>
  )
}));

vi.mock('@/components/Input', () => ({
  default: ({ value, onChange, onKeyPress, placeholder, disabled }) => (
    <input
      value={value}
      onChange={onChange}
      onKeyPress={onKeyPress}
      placeholder={placeholder}
      disabled={disabled}
    />
  )
}));

describe('InviteUserPanel', () => {
  const mockOnInviteSuccess = vi.fn();
  const workspaceId = 'ws1';

  beforeEach(() => {
    // Clear all mocks before each test
    vi.clearAllMocks();
  });

  it('should render the invite form for users with CREATOR role', () => {
    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );
    expect(screen.getByText('Invite User')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Enter username...')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Invite' })).toBeInTheDocument();
  });

  it('should render the invite form for users with RESEARCHER role', () => {
    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="RESEARCHER"
      />
    );
    expect(screen.getByText('Invite User')).toBeInTheDocument();
  });

  it('should not render the invite form for users with GUEST role', () => {
    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="GUEST"
      />
    );
    expect(screen.queryByText('Invite User')).not.toBeInTheDocument();
    expect(screen.getByText('Only researchers can invite users')).toBeInTheDocument();
  });

  it('should show an error if username is empty on invite attempt', async () => {
    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );
    // The button is disabled until a username is entered
    const inviteButton = screen.getByRole('button', { name: 'Invite' });
    expect(inviteButton).toBeDisabled();

    // Simulate typing and then clearing the input to trigger validation
    const input = screen.getByPlaceholderText('Enter username...');
    fireEvent.change(input, { target: { value: 'a' } });
    fireEvent.change(input, { target: { value: '' } });

    const form = inviteButton.closest('form');
    fireEvent.submit(form);

    expect(await screen.findByText('Please enter a username')).toBeInTheDocument();
    expect(inviteUserToWorkspace).not.toHaveBeenCalled();
  });

  it('should show an error if the user already exists in the workspace', async () => {
    inviteUserToWorkspace.mockRejectedValue(new Error('User is already in the workspace.'));
    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );
    const input = screen.getByPlaceholderText('Enter username...');
    const inviteButton = screen.getByRole('button', { name: 'Invite' });

    fireEvent.change(input, { target: { value: 'existinguser' } });
    await act(async () => {
      fireEvent.click(inviteButton);
    });
    expect(await screen.findByText('User is already in the workspace.')).toBeInTheDocument();
  });

  it('should call inviteUserToWorkspace and show success message on successful invite', async () => {
    // Mock the API to resolve successfully
    inviteUserToWorkspace.mockResolvedValue(undefined);

    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );

    const input = screen.getByPlaceholderText('Enter username...');
    const inviteButton = screen.getByRole('button', { name: 'Invite' });

    fireEvent.change(input, { target: { value: 'testuser' } });
    fireEvent.click(inviteButton);

    // Wait for the async operations to complete
    await waitFor(() => {
      expect(inviteUserToWorkspace).toHaveBeenCalledWith(workspaceId, 'testuser', 'RESEARCHER');
    });

    expect(await screen.findByText('Invitation sent')).toBeInTheDocument();
    expect(mockOnInviteSuccess).toHaveBeenCalledTimes(1);
    // Input should be cleared on success
    expect(input.value).toBe('');
  });

  it('should handle API errors and display a specific error message', async () => {
    // Mock the API to reject with a specific error
    inviteUserToWorkspace.mockRejectedValue(new Error('User does not exist'));

    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );

    const input = screen.getByPlaceholderText('Enter username...');
    const inviteButton = screen.getByRole('button', { name: 'Invite' });

    fireEvent.change(input, { target: { value: 'nonexistent' } });
    fireEvent.click(inviteButton);

    expect(await screen.findByText('User not found')).toBeInTheDocument();
    expect(mockOnInviteSuccess).not.toHaveBeenCalled();
  });

  it('should handle "already a member" error', async () => {
    inviteUserToWorkspace.mockRejectedValue(new Error('already a member'));

    render(
      <InviteUserPanel
        workspaceId={workspaceId}
        onInviteSuccess={mockOnInviteSuccess}
        currentUserRole="CREATOR"
      />
    );

    const input = screen.getByPlaceholderText('Enter username...');
    const inviteButton = screen.getByRole('button', { name: 'Invite' });

    await act(async () => {
      fireEvent.change(input, { target: { value: 'existinguser' } });
      fireEvent.click(inviteButton);
    });

    expect(await screen.findByText('User already a member')).toBeInTheDocument();
  });

  it('should disable the form while an invitation is being sent', async () => {
    // Create a promise that we can resolve manually
    let resolvePromise;
    const promise = new Promise(resolve => {
      resolvePromise = resolve;
    });
    inviteUserToWorkspace.mockReturnValue(promise);

    const { getByPlaceholderText, getByRole } = render(
      <InviteUserPanel workspaceId="ws1" onInviteSuccess={vi.fn()} currentUserRole="CREATOR" />
    );

    const input = getByPlaceholderText('Enter username...');
    const inviteButton = getByRole('button', { name: 'Invite' });

    await act(async () => {
      fireEvent.change(input, { target: { value: 'testuser' } });
      fireEvent.click(inviteButton);
    });

    expect(input).toBeDisabled();
    expect(inviteButton).toBeDisabled();

    // Resolve the promise to simulate the API call finishing
    await act(async () => {
      resolvePromise();
      await new Promise(process.nextTick); // Allow state updates to process
    });

    expect(input).not.toBeDisabled();
    // The button is disabled again after success because the input is cleared
    expect(inviteButton).toBeDisabled();
  });
});


