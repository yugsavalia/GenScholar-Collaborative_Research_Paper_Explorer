import { describe, it, expect } from 'vitest';
import { 
  normalizeRectsToPage, 
  denormalizeQuad, 
  rectsIntersect, 
  hexToRgba 
} from '../utils/annotations';

describe('annotations utils', () => {
  describe('normalizeRectsToPage', () => {
    it('should return empty array when pageRect is null', () => {
      const rects = [{ left: 10, top: 20, right: 30, bottom: 40 }];
      const result = normalizeRectsToPage(rects, null);
      expect(result).toEqual([]);
    });

    it('should return empty array when pageRect is undefined', () => {
      const rects = [{ left: 10, top: 20, right: 30, bottom: 40 }];
      const result = normalizeRectsToPage(rects, undefined);
      expect(result).toEqual([]);
    });

    it('should return empty array when pageRect has no width', () => {
      const rects = [{ left: 10, top: 20, right: 30, bottom: 40 }];
      const pageRect = { width: 0, height: 100, left: 0, top: 0 };
      const result = normalizeRectsToPage(rects, pageRect);
      expect(result).toEqual([]);
    });

    it('should return empty array when pageRect has no height', () => {
      const rects = [{ left: 10, top: 20, right: 30, bottom: 40 }];
      const pageRect = { width: 100, height: 0, left: 0, top: 0 };
      const result = normalizeRectsToPage(rects, pageRect);
      expect(result).toEqual([]);
    });

    it('should normalize a single rect', () => {
      const rects = [{ left: 50, top: 100, right: 150, bottom: 200 }];
      const pageRect = { width: 200, height: 400, left: 0, top: 0 };
      
      const result = normalizeRectsToPage(rects, pageRect);
      
      expect(result).toHaveLength(1);
      expect(result[0].x0).toBe(0.25);  // (50 - 0) / 200
      expect(result[0].y0).toBe(0.25);  // (100 - 0) / 400
      expect(result[0].x1).toBe(0.75);  // (150 - 0) / 200
      expect(result[0].y1).toBe(0.5);   // (200 - 0) / 400
    });

    it('should normalize with non-zero page offset', () => {
      const rects = [{ left: 150, top: 200, right: 250, bottom: 300 }];
      const pageRect = { width: 200, height: 400, left: 100, top: 100 };
      
      const result = normalizeRectsToPage(rects, pageRect);
      
      expect(result).toHaveLength(1);
      expect(result[0].x0).toBe(0.25);  // (150 - 100) / 200
      expect(result[0].y0).toBe(0.25);  // (200 - 100) / 400
      expect(result[0].x1).toBe(0.75);  // (250 - 100) / 200
      expect(result[0].y1).toBe(0.5);   // (300 - 100) / 400
    });

    it('should normalize multiple rects', () => {
      const rects = [
        { left: 0, top: 0, right: 100, bottom: 100 },
        { left: 100, top: 100, right: 200, bottom: 200 }
      ];
      const pageRect = { width: 200, height: 200, left: 0, top: 0 };
      
      const result = normalizeRectsToPage(rects, pageRect);
      
      expect(result).toHaveLength(2);
      expect(result[0]).toEqual({ x0: 0, y0: 0, x1: 0.5, y1: 0.5 });
      expect(result[1]).toEqual({ x0: 0.5, y0: 0.5, x1: 1, y1: 1 });
    });

    it('should handle empty rects array', () => {
      const rects = [];
      const pageRect = { width: 200, height: 400, left: 0, top: 0 };
      
      const result = normalizeRectsToPage(rects, pageRect);
      
      expect(result).toEqual([]);
    });

    it('should handle array-like objects', () => {
      const rects = { 0: { left: 10, top: 20, right: 30, bottom: 40 }, length: 1 };
      const pageRect = { width: 100, height: 100, left: 0, top: 0 };
      
      const result = normalizeRectsToPage(rects, pageRect);
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual({ x0: 0.1, y0: 0.2, x1: 0.3, y1: 0.4 });
    });
  });

  describe('denormalizeQuad', () => {
    it('should denormalize a quad to pixel coordinates', () => {
      const quad = { x0: 0.25, y0: 0.25, x1: 0.75, y1: 0.75 };
      const pagePixelSize = { width: 400, height: 600 };
      
      const result = denormalizeQuad(quad, pagePixelSize);
      
      expect(result.left).toBe(100);   // 0.25 * 400
      expect(result.top).toBe(150);    // 0.25 * 600
      expect(result.width).toBe(200);  // (0.75 * 400) - (0.25 * 400)
      expect(result.height).toBe(300); // (0.75 * 600) - (0.25 * 600)
    });

    it('should handle quad at origin', () => {
      const quad = { x0: 0, y0: 0, x1: 0.5, y1: 0.5 };
      const pagePixelSize = { width: 200, height: 200 };
      
      const result = denormalizeQuad(quad, pagePixelSize);
      
      expect(result.left).toBe(0);
      expect(result.top).toBe(0);
      expect(result.width).toBe(100);
      expect(result.height).toBe(100);
    });

    it('should handle full-page quad', () => {
      const quad = { x0: 0, y0: 0, x1: 1, y1: 1 };
      const pagePixelSize = { width: 800, height: 1200 };
      
      const result = denormalizeQuad(quad, pagePixelSize);
      
      expect(result.left).toBe(0);
      expect(result.top).toBe(0);
      expect(result.width).toBe(800);
      expect(result.height).toBe(1200);
    });

    it('should handle small quad', () => {
      const quad = { x0: 0.1, y0: 0.1, x1: 0.2, y1: 0.2 };
      const pagePixelSize = { width: 1000, height: 1000 };
      
      const result = denormalizeQuad(quad, pagePixelSize);
      
      expect(result.left).toBe(100);
      expect(result.top).toBe(100);
      expect(result.width).toBe(100);
      expect(result.height).toBe(100);
    });

    it('should handle fractional pixel values', () => {
      const quad = { x0: 0.333, y0: 0.333, x1: 0.666, y1: 0.666 };
      const pagePixelSize = { width: 300, height: 300 };
      
      const result = denormalizeQuad(quad, pagePixelSize);
      
      expect(result.left).toBeCloseTo(99.9, 1);
      expect(result.top).toBeCloseTo(99.9, 1);
      expect(result.width).toBeCloseTo(99.9, 1);
      expect(result.height).toBeCloseTo(99.9, 1);
    });
  });

  describe('rectsIntersect', () => {
    it('should return true for overlapping rects', () => {
      const a = { left: 0, top: 0, width: 100, height: 100 };
      const b = { left: 50, top: 50, width: 100, height: 100 };
      
      expect(rectsIntersect(a, b)).toBe(true);
    });

    it('should return true when one rect contains another', () => {
      const a = { left: 0, top: 0, width: 200, height: 200 };
      const b = { left: 50, top: 50, width: 50, height: 50 };
      
      expect(rectsIntersect(a, b)).toBe(true);
    });

    it('should return true when second rect contains first', () => {
      const a = { left: 50, top: 50, width: 50, height: 50 };
      const b = { left: 0, top: 0, width: 200, height: 200 };
      
      expect(rectsIntersect(a, b)).toBe(true);
    });

    it('should return false for non-overlapping rects', () => {
      const a = { left: 0, top: 0, width: 50, height: 50 };
      const b = { left: 100, top: 100, width: 50, height: 50 };
      
      expect(rectsIntersect(a, b)).toBe(false);
    });

    it('should return false for horizontally separated rects', () => {
      const a = { left: 0, top: 0, width: 50, height: 100 };
      const b = { left: 100, top: 0, width: 50, height: 100 };
      
      expect(rectsIntersect(a, b)).toBe(false);
    });

    it('should return false for vertically separated rects', () => {
      const a = { left: 0, top: 0, width: 100, height: 50 };
      const b = { left: 0, top: 100, width: 100, height: 50 };
      
      expect(rectsIntersect(a, b)).toBe(false);
    });

    it('should return false for touching but not overlapping rects', () => {
      const a = { left: 0, top: 0, width: 50, height: 50 };
      const b = { left: 50, top: 0, width: 50, height: 50 };
      
      expect(rectsIntersect(a, b)).toBe(false);
    });

    it('should return true for barely overlapping rects', () => {
      const a = { left: 0, top: 0, width: 51, height: 51 };
      const b = { left: 50, top: 50, width: 50, height: 50 };
      
      expect(rectsIntersect(a, b)).toBe(true);
    });

    it('should handle rects with same dimensions', () => {
      const a = { left: 10, top: 10, width: 100, height: 100 };
      const b = { left: 10, top: 10, width: 100, height: 100 };
      
      expect(rectsIntersect(a, b)).toBe(true);
    });

    // Kill mutant: EqualityOperator ax1 < bx2 → ax1 <= bx2
    it('should return false when rectangles touch exactly at right edge', () => {
      // a.right (50) === b.left (50), should NOT intersect
      const a = { left: 0, top: 0, width: 50, height: 50 };
      const b = { left: 50, top: 0, width: 50, height: 50 };
      
      // ax1 (0) < bx2 (100) = true ✓
      // But ax2 (50) > bx1 (50) = false ✗ (they only touch)
      expect(rectsIntersect(a, b)).toBe(false);
    });

    // Kill mutant: EqualityOperator ay1 < by2 → ay1 <= by2
    it('should return false when rectangles touch exactly at bottom edge', () => {
      // a.bottom (50) === b.top (50), should NOT intersect
      const a = { left: 0, top: 0, width: 50, height: 50 };
      const b = { left: 0, top: 50, width: 50, height: 50 };
      
      // ay1 (0) < by2 (100) = true ✓
      // But ay2 (50) > by1 (50) = false ✗ (they only touch)
      expect(rectsIntersect(a, b)).toBe(false);
    });

    // Kill mutant: EqualityOperator ay2 > by1 → ay2 >= by1
    it('should return false when rectangles touch exactly at top edge', () => {
      // b.bottom (50) === a.top (50), should NOT intersect
      const a = { left: 0, top: 50, width: 50, height: 50 };
      const b = { left: 0, top: 0, width: 50, height: 50 };
      
      // ay2 (100) > by1 (0) = true ✓
      // But ay1 (50) < by2 (50) = false ✗ (they only touch)
      expect(rectsIntersect(a, b)).toBe(false);
    });

    // Kill mutant: ConditionalExpression ax1 < bx2 → true
    it('should verify all conditions are checked not just first', () => {
      // Test case where ax1 < bx2 is true but other conditions fail
      const a = { left: 0, top: 0, width: 10, height: 10 };
      const b = { left: 20, top: 20, width: 10, height: 10 };
      
      // ax1 (0) < bx2 (30) = true
      // But ax2 (10) > bx1 (20) = false (separated)
      expect(rectsIntersect(a, b)).toBe(false);
    });

    // Kill mutant: ConditionalExpression ay1 < by2 → true
    it('should verify vertical overlap condition is checked', () => {
      // Test case where ay1 < by2 is true but other conditions fail
      const a = { left: 0, top: 0, width: 10, height: 10 };
      const b = { left: 0, top: 20, width: 10, height: 10 };
      
      // ay1 (0) < by2 (30) = true
      // But ay2 (10) > by1 (20) = false (separated vertically)
      expect(rectsIntersect(a, b)).toBe(false);
    });

    // Kill mutant: OptionalChaining pageRect?.height → pageRect.height
    it('should handle null pageRect in normalizeRectsToPage', () => {
      const rects = [{ left: 10, top: 20, right: 30, bottom: 40 }];
      const result = normalizeRectsToPage(rects, null);
      
      // Should safely handle null without throwing
      expect(result).toEqual([]);
    });
  });

  describe('hexToRgba', () => {
    it('should convert 6-digit hex to rgba with default alpha', () => {
      const result = hexToRgba('#ff5733');
      expect(result).toBe('rgba(255, 87, 51, 1)');
    });

    it('should convert hex without # prefix', () => {
      const result = hexToRgba('ff5733');
      expect(result).toBe('rgba(255, 87, 51, 1)');
    });

    it('should handle custom alpha value', () => {
      const result = hexToRgba('#ff5733', 0.5);
      expect(result).toBe('rgba(255, 87, 51, 0.5)');
    });

    it('should handle alpha of 0', () => {
      const result = hexToRgba('#ff5733', 0);
      expect(result).toBe('rgba(255, 87, 51, 0)');
    });

    it('should handle black color', () => {
      const result = hexToRgba('#000000');
      expect(result).toBe('rgba(0, 0, 0, 1)');
    });

    it('should handle white color', () => {
      const result = hexToRgba('#ffffff');
      expect(result).toBe('rgba(255, 255, 255, 1)');
    });

    it('should handle lowercase hex', () => {
      const result = hexToRgba('#abc123');
      expect(result).toBe('rgba(171, 193, 35, 1)');
    });

    it('should handle uppercase hex', () => {
      const result = hexToRgba('#ABC123');
      expect(result).toBe('rgba(171, 193, 35, 1)');
    });

    it('should handle mixed case hex', () => {
      const result = hexToRgba('#AbC123');
      expect(result).toBe('rgba(171, 193, 35, 1)');
    });

    it('should return default yellow for invalid hex', () => {
      const result = hexToRgba('invalid');
      expect(result).toBe('rgba(255, 235, 59, 1)');
    });

    it('should return default yellow for short hex', () => {
      const result = hexToRgba('#abc');
      expect(result).toBe('rgba(255, 235, 59, 1)');
    });

    it('should return default yellow for long hex', () => {
      const result = hexToRgba('#abcdef12');
      expect(result).toBe('rgba(255, 235, 59, 1)');
    });

    it('should return default yellow for empty string', () => {
      const result = hexToRgba('');
      expect(result).toBe('rgba(255, 235, 59, 1)');
    });

    it('should handle alpha with decimal precision', () => {
      const result = hexToRgba('#ff5733', 0.123);
      expect(result).toBe('rgba(255, 87, 51, 0.123)');
    });

    it('should use custom alpha even for invalid hex', () => {
      const result = hexToRgba('invalid', 0.75);
      expect(result).toBe('rgba(255, 235, 59, 0.75)');
    });
  });
});
