import { STORAGE_KEYS, ANNOTATION_TYPES } from '@/utils/constants';

describe('utils/constants', () => {
  describe('STORAGE_KEYS', () => {
    it('should have AUTH key', () => {
      expect(STORAGE_KEYS.AUTH).toBe('gs_auth');
    });

    it('should have WORKSPACES key', () => {
      expect(STORAGE_KEYS.WORKSPACES).toBe('gs_workspaces');
    });

    it('should generate PDFS key with workspaceId', () => {
      const workspaceId = '123';
      expect(STORAGE_KEYS.PDFS(workspaceId)).toBe(`gs_pdfs::${workspaceId}`);
    });

    it('should generate ANNOTATIONS key with workspaceId and pdfId', () => {
      const workspaceId = '123';
      const pdfId = '456';
      expect(STORAGE_KEYS.ANNOTATIONS(workspaceId, pdfId)).toBe(
        `gs_annotations::${workspaceId}::${pdfId}`
      );
    });

    it('should generate THREADS key with workspaceId, pdfId, and selectionId', () => {
      const workspaceId = '123';
      const pdfId = '456';
      const selectionId = '789';
      expect(STORAGE_KEYS.THREADS(workspaceId, pdfId, selectionId)).toBe(
        `gs_threads::${workspaceId}::${pdfId}::${selectionId}`
      );
    });

    it('should generate BOT key with workspaceId', () => {
      const workspaceId = '123';
      expect(STORAGE_KEYS.BOT(workspaceId)).toBe(`gs_bot::${workspaceId}`);
    });

    it('should generate MAIN_CHAT key with workspaceId', () => {
      const workspaceId = '123';
      expect(STORAGE_KEYS.MAIN_CHAT(workspaceId)).toBe(`gs_mainchat::${workspaceId}`);
    });
  });

  describe('ANNOTATION_TYPES', () => {
    it('should have HIGHLIGHT type', () => {
      expect(ANNOTATION_TYPES.HIGHLIGHT).toBe('highlight');
    });

    it('should have UNDERLINE type', () => {
      expect(ANNOTATION_TYPES.UNDERLINE).toBe('underline');
    });

    it('should have TEXTBOX type', () => {
      expect(ANNOTATION_TYPES.TEXTBOX).toBe('textbox');
    });

    it('should have SELECT type', () => {
      expect(ANNOTATION_TYPES.SELECT).toBe('select');
    });
  });

  // Mutation testing: Verify exact key formats
  describe('Key format validation', () => {
    it('should use correct prefix for AUTH key', () => {
      expect(STORAGE_KEYS.AUTH).toMatch(/^gs_/);
      expect(STORAGE_KEYS.AUTH).toBe('gs_auth');
    });

    it('should use double colon delimiter in PDFS key', () => {
      const key = STORAGE_KEYS.PDFS('workspace-123');
      
      expect(key).toContain('::');
      expect(key.split('::').length).toBe(2);
      expect(key).toBe('gs_pdfs::workspace-123');
    });

    it('should use correct delimiter count in ANNOTATIONS key', () => {
      const key = STORAGE_KEYS.ANNOTATIONS('ws1', 'pdf1');
      
      expect(key.split('::').length).toBe(3);
      expect(key).toBe('gs_annotations::ws1::pdf1');
    });

    it('should use correct delimiter count in THREADS key', () => {
      const key = STORAGE_KEYS.THREADS('ws1', 'pdf1', 'sel1');
      
      expect(key.split('::').length).toBe(4);
      expect(key).toBe('gs_threads::ws1::pdf1::sel1');
    });

    it('should maintain correct parameter order in multi-param keys', () => {
      const workspaceId = 'WORKSPACE';
      const pdfId = 'PDF';
      const selectionId = 'SELECTION';
      
      const key = STORAGE_KEYS.THREADS(workspaceId, pdfId, selectionId);
      const parts = key.split('::');
      
      expect(parts[1]).toBe(workspaceId);
      expect(parts[2]).toBe(pdfId);
      expect(parts[3]).toBe(selectionId);
    });
  });

  // Mutation testing: Verify annotation types are unique
  describe('Annotation type uniqueness', () => {
    it('should have all unique annotation type values', () => {
      const values = Object.values(ANNOTATION_TYPES);
      const uniqueValues = new Set(values);
      
      expect(uniqueValues.size).toBe(values.length);
    });

    it('should not have swapped type values', () => {
      expect(ANNOTATION_TYPES.HIGHLIGHT).not.toBe('underline');
      expect(ANNOTATION_TYPES.HIGHLIGHT).not.toBe('textbox');
      expect(ANNOTATION_TYPES.UNDERLINE).not.toBe('highlight');
    });
  });
});

